// placeholder
window.isWebApp = true;