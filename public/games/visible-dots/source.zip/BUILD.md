# 视线谜阵

Upstream: https://github.com/Techdojo/0hn0
Pinned commit: a207bafd92608eec7c112f31992050aad8de4c27
License: MIT; Apache-2.0 launcher, see runtime/games/visible-dots/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/visible-dots/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:
fonts/JosefinSans-Bold.ttf
fonts/Molle-Regular.ttf
fonts/fonts.css
