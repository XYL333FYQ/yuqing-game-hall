import type { CompactMappingY, Mapping } from '../../../model/types';
import {
	cleanImportLayout,
	cleanNameCapitalized,
	compactMapping,
	compactY,
	convert3400Matrix,
	convertKmahjongg,
	convertKmahjonggLines,
	convertKyodai,
	convertMatrix,
	decodeImportText,
	importLayouts,
	readFile,
	sortMapping
} from './import';
import { describe, it, expect } from 'vitest';

describe('sortMapping', () => {
	it('should sort by z first', () => {
		const mapping: Mapping = [[1, 0, 0], [0, 0, 0]];
		const result = sortMapping(mapping);
		expect(result[0][0]).toBe(0);
		expect(result[1][0]).toBe(1);
	});

	it('should sort by x when z is equal', () => {
		const mapping: Mapping = [[0, 4, 0], [0, 2, 0]];
		const result = sortMapping(mapping);
		expect(result[0][1]).toBe(2);
		expect(result[1][1]).toBe(4);
	});

	it('should sort by y when z and x are equal', () => {
		const mapping: Mapping = [[0, 0, 3], [0, 0, 1]];
		const result = sortMapping(mapping);
		expect(result[0][2]).toBe(1);
		expect(result[1][2]).toBe(3);
	});

	it('should return same element when mapping has one entry', () => {
		const mapping: Mapping = [[2, 3, 4]];
		const result = sortMapping(mapping);
		expect(result).toHaveLength(1);
		expect(result[0]).toEqual([2, 3, 4]);
	});

	it('should handle equal elements', () => {
		const mapping: Mapping = [[0, 0, 0], [0, 0, 0]];
		const result = sortMapping(mapping);
		expect(result).toHaveLength(2);
	});
});

describe('convertMatrix', () => {
	it('should reject when the matrix length does not match dimensions', async () => {
		await expect(convertMatrix(5, 20, 34, 'Test', 'short')).rejects.toThrow('Invalid Matrix Pattern length');
	});

	it('should parse cells with value 1 into mapping entries', async () => {
		const kyodai = `1${'0'.repeat(5 * 20 * 34 - 1)}`;
		const result = await convertMatrix(5, 20, 34, 'Test', kyodai);
		expect(result.mapping).toHaveLength(1);
		expect(result.mapping[0]).toEqual([0, 0, 0]);
	});

	it('should set the name on the layout', async () => {
		const kyodai = '0'.repeat(5 * 20 * 34);
		const result = await convertMatrix(5, 20, 34, 'MyName', kyodai);
		expect(result.name).toBe('MyName');
	});

	it('should set cat to Kyodai', async () => {
		const kyodai = '0'.repeat(5 * 20 * 34);
		const result = await convertMatrix(5, 20, 34, 'Test', kyodai);
		expect(result.cat).toBe('Kyodai');
	});

	it('should map a cell in level 1 correctly', async () => {
		const cellsPerMatrix = 20 * 34;
		const kyodai = `${'0'.repeat(cellsPerMatrix)}1${'0'.repeat(cellsPerMatrix * 4 - 1)}`;
		const result = await convertMatrix(5, 20, 34, 'Test', kyodai);
		const isFound = result.mapping.some(place => place[0] === 1 && place[1] === 0 && place[2] === 0);
		expect(isFound).toBe(true);
	});
});

describe('convert3400Matrix', () => {
	it('should reject when the matrix length is not 3400', async () => {
		await expect(convert3400Matrix('Test', '0'.repeat(100))).rejects.toThrow();
	});

	it('should parse a 3400-char matrix', async () => {
		const kyodai = '0'.repeat(3400);
		const result = await convert3400Matrix('Test', kyodai);
		expect(result.mapping).toHaveLength(0);
	});
});

describe('convertKmahjonggLines', () => {
	it('should parse lines into mapping entries for char 1', async () => {
		const lines = ['1000', '0100'];
		const result = await convertKmahjonggLines(lines, 2);
		expect(result).toHaveLength(2);
		expect(result).toContainEqual([0, 0, 0]);
		expect(result).toContainEqual([0, 1, 1]);
	});

	it('should produce correct z index from height grouping', async () => {
		const lines = ['0000', '0000', '1000', '0000'];
		const result = await convertKmahjonggLines(lines, 2);
		const level1Entry = result.find(place => place[0] === 1);
		expect(level1Entry).toBeDefined();
		expect(level1Entry?.[2]).toBe(0);
	});

	it('should return empty mapping for lines with no 1 chars', async () => {
		const lines = ['0000', '0000'];
		const result = await convertKmahjonggLines(lines, 2);
		expect(result).toHaveLength(0);
	});
});

describe('convertKmahjongg', () => {
	it('should parse v1.0 format', async () => {
		const data = 'kmahjongg-layout-v1.0\n1000\n0100\n';
		const result = await convertKmahjongg(data, 'test.layout');
		expect(result.mapping.length).toBeGreaterThan(0);
		expect(result.by).toBe('KDE Games team');
	});

	it('should parse v1.1 format and extract name', async () => {
		const data = [
			'kmahjongg-layout-v1.1',
			'# name: MyLayout',
			'# by: TestAuthor',
			'w5',
			'h4',
			'd1',
			'1000',
			'0100'
		].join('\n');
		const result = await convertKmahjongg(data, 'test.layout');
		expect(result.name).toBe('MyLayout');
	});

	it('should parse v1.1 format and extract by', async () => {
		const data = [
			'kmahjongg-layout-v1.1',
			'# name: MyLayout',
			'# by: TestAuthor',
			'w5',
			'h4',
			'd1',
			'1000'
		].join('\n');
		const result = await convertKmahjongg(data, 'test.layout');
		expect(result.by).toBe('TestAuthor');
	});

	it('should use filename as name when v1.1 name is empty', async () => {
		const data = [
			'kmahjongg-layout-v1.1',
			'# name: ',
			'w5',
			'h4',
			'd1',
			'1000'
		].join('\n');
		const result = await convertKmahjongg(data, 'fallback.layout');
		expect(result.name).toBe('fallback');
	});

	it('should keep the cleaned up filename when the v1.1 header carries no name', async () => {
		const data = [
			'kmahjongg-layout-v1.1',
			'w5',
			'h4',
			'd1',
			'1000'
		].join('\n');
		const result = await convertKmahjongg(data, 'my_cool_layout.layout');
		expect(result.name).toBe('my cool layout');
	});

	// a v1.1 file is a stack of levels, each one h rows tall
	function kmahjonggV11(header: Array<string>, rows: Array<string>): string {
		return ['kmahjongg-layout-v1.1', '# name: Probe', ...header, ...rows].join('\n');
	}

	// one tile on the first row of level 0 and one on the first row of level 1, for a 16 row level
	function twoLevelRows(): Array<string> {
		return Array.from({ length: 17 }, (_value, index) => (index === 0 || index === 16 ? '1...' : '....'));
	}

	it('splits the rows into levels at the height the h header declares', async () => {
		const rows = ['1...', '....', '..1.', '....', '.1..', '....'];
		const result = await convertKmahjongg(kmahjonggV11(['w4', 'h3', 'd2'], rows), 'test.layout');
		expect(result.mapping).toEqual([[0, 0, 0], [0, 2, 2], [1, 1, 1]]);
	});

	it('falls back to 16 rows per level when the h header is missing', async () => {
		const result = await convertKmahjongg(kmahjonggV11(['w4', 'd2'], twoLevelRows()), 'test.layout');
		expect(result.mapping).toEqual([[0, 0, 0], [1, 0, 0]]);
	});

	it('falls back rather than splitting the rows at a zero height', async () => {
		const result = await convertKmahjongg(kmahjonggV11(['w4', 'h0', 'd2'], twoLevelRows()), 'test.layout');
		expect(result.mapping).toEqual([[0, 0, 0], [1, 0, 0]]);
	});

	// the layouts in the wild and this app's own exporter write the header without the leading k
	it('accepts the v1.1 header without the leading k', async () => {
		const data = ['mahjongg-layout-v1.1', '# name: Probe', 'w4', 'h2', 'd1', '1...', '..1.'].join('\n');

		const result = await convertKmahjongg(data, 'test.layout');

		expect(result.name).toBe('Probe');
		expect(result.mapping).toEqual([[0, 0, 0], [0, 2, 1]]);
	});

	it('still accepts the v1.1 header KDE writes', async () => {
		const data = ['kmahjongg-layout-v1.1', '# name: Probe', 'w4', 'h2', 'd1', '1...', '..1.'].join('\n');

		const result = await convertKmahjongg(data, 'test.layout');

		expect(result.mapping).toEqual([[0, 0, 0], [0, 2, 1]]);
	});

	it('should reject unknown version', async () => {
		await expect(convertKmahjongg('unknown-version-v9.9\n1000', 'test.layout')).rejects.toThrow('Unknown .layout format');
	});

	it('should handle Windows CRLF line endings in v1.0', async () => {
		const data = 'kmahjongg-layout-v1.0\r\n1000\r\n0100\r\n';
		const result = await convertKmahjongg(data, 'test.layout');
		expect(result.mapping.length).toBeGreaterThan(0);
	});
});

describe('convertKyodai', () => {
	function make3400Kyodai(overrides: Record<number, string> = {}): string {
		const chars = Array.from({ length: 3400 }, () => '0');
		for (const [index, value] of Object.entries(overrides)) {
			chars[Number(index)] = value;
		}
		return chars.join('');
	}

	it('should parse Kyodai 6.0 format', async () => {
		const kyodai = make3400Kyodai();
		const data = `Kyodai 6.0\nTestName\n${kyodai}\n`;
		const result = await convertKyodai(data, 'test.lay');
		expect(result.name).toBe('TestName');
	});

	it('should parse Kyodai 3.0 format', async () => {
		const kyodai = make3400Kyodai();
		const data = `Kyodai 3.0\nTestName\n${kyodai}\n`;
		const result = await convertKyodai(data, 'test.lay');
		expect(result.name).toBe('TestName');
	});

	it('should extract category from name line', async () => {
		const kyodai = make3400Kyodai();
		const data = `Kyodai 6.0\nName :: MyCat\n${kyodai}\n`;
		const result = await convertKyodai(data, 'test.lay');
		expect(result.cat).toBe(' MyCat');
	});

	it('should reject unknown version', async () => {
		const kyodai = make3400Kyodai();
		await expect(convertKyodai(`Unknown 1.0\nName\n${kyodai}\n`, 'test.lay')).rejects.toThrow('Unknown .lay format');
	});

	it('should use filename when name line is empty', async () => {
		const kyodai = make3400Kyodai();
		const data = `Kyodai 6.0\n\n${kyodai}\n`;
		const result = await convertKyodai(data, 'fallback.lay');
		expect(result.name).toBe('fallback');
	});
});

describe('compactY', () => {
	it('should return a single x value directly when there is one tile', () => {
		const layout = { 0: { 0: [4] } };
		const result: CompactMappingY = compactY(0, 0, layout);
		expect(result[0]).toBe(0);
		expect(result[1]).toBe(4);
	});

	it('should run-length encode consecutive x values stepping by 2', () => {
		const layout = { 0: { 0: [0, 2, 4] } };
		const result: CompactMappingY = compactY(0, 0, layout);
		expect(result[0]).toBe(0);
		expect(result[1]).toEqual([[0, 3]]);
	});

	it('should return array of values for non-consecutive x values', () => {
		const layout = { 0: { 0: [0, 6] } };
		const result: CompactMappingY = compactY(0, 0, layout);
		expect(result[0]).toBe(0);
		expect(result[1]).toEqual([0, 6]);
	});

	it('should handle multiple runs', () => {
		const layout = { 0: { 0: [0, 2, 10, 12] } };
		const result: CompactMappingY = compactY(0, 0, layout);
		expect(Array.isArray(result[1])).toBe(true);
	});
});

describe('compactMapping', () => {
	it('should return an empty array for an empty mapping', () => {
		const result = compactMapping([]);
		expect(result).toHaveLength(0);
	});

	it('should return a compact structure for a simple mapping', () => {
		const mapping: Mapping = [[0, 0, 0]];
		const result = compactMapping(mapping);
		expect(result).toHaveLength(1);
		expect(result[0][0]).toBe(0);
	});

	it('should group tiles by z level', () => {
		const mapping: Mapping = [[0, 0, 0], [1, 0, 0]];
		const result = compactMapping(mapping);
		expect(result).toHaveLength(2);
	});
});

describe('cleanNameCapitalized', () => {
	it('should capitalize each word', () => {
		expect(cleanNameCapitalized('hello world')).toBe('Hello World');
	});

	it('should remove surrounding single quotes', () => {
		expect(cleanNameCapitalized('\'hello\'')).toBe('hello');
	});

	it('should remove double quotes', () => {
		expect(cleanNameCapitalized('"hello"')).toBe('hello');
	});

	it('should trim surrounding whitespace', () => {
		expect(cleanNameCapitalized('  hello  ')).toBe('Hello');
	});

	it('should handle single word', () => {
		expect(cleanNameCapitalized('dragon')).toBe('Dragon');
	});
});

describe('cleanImportLayout', () => {
	it('should split name by by and assign author', () => {
		const result = cleanImportLayout({
			name: 'MyLayout by Some Author',
			cat: 'test',
			mapping: []
		});
		expect(result.name).toBe('MyLayout');
		expect(result.by).toBe('Some Author');
	});

	it('should capitalize the name', () => {
		const result = cleanImportLayout({
			name: 'my layout',
			cat: 'test',
			mapping: []
		});
		expect(result.name).toBe('My Layout');
	});

	it('should trim the cat field', () => {
		const result = cleanImportLayout({
			name: 'test',
			cat: '  Misc  ',
			mapping: []
		});
		expect(result.cat).toBe('Misc');
	});

	it('should produce an id', () => {
		const result = cleanImportLayout({ name: 'Test', cat: 'cat', mapping: [[0, 0, 0]] });
		expect(typeof result.id).toBe('string');
		expect(result.id.length).toBeGreaterThan(0);
	});

	it('should include a compact map', () => {
		const result = cleanImportLayout({ name: 'Test', cat: 'cat', mapping: [[0, 0, 0]] });
		expect(Array.isArray(result.map)).toBe(true);
	});
});

describe('readFile', () => {
	it('should resolve with file content on success', async () => {
		const result = await readFile(new File(['file content'], 'test.txt'));
		expect(result).toBe('file content');
	});

	it('should reject with error message on read error', async () => {
		const unreadable = {
			arrayBuffer: async (): Promise<ArrayBuffer> => {
				throw new Error('read error');
			}
		} as unknown as File;
		await expect(readFile(unreadable)).rejects.toThrow('Reading File failed: read error');
	});

	it('reads an accented name back unchanged', async () => {
		const content = '# name: Grüne Mauer 龍';
		const result = await readFile(new File([content], 'test.layout'));
		expect(result).toBe(content);
	});
});

describe('decodeImportText', () => {
	function bytes(...values: Array<number>): ArrayBuffer {
		return new Uint8Array(values).buffer;
	}

	it('decodes UTF-8, which is what this app and KDE write', () => {
		// 'ü' as UTF-8
		expect(decodeImportText(bytes(0xC3, 0xBC))).toBe('ü');
	});

	it('strips a UTF-8 byte order mark', () => {
		expect(decodeImportText(bytes(0xEF, 0xBB, 0xBF, 0x4B, 0x79))).toBe('Ky');
	});

	it('falls back to windows-1252 for a legacy Kyodai file', () => {
		// 'ü' as windows-1252, which is not valid UTF-8
		expect(decodeImportText(bytes(0xFC))).toBe('ü');
	});

	it('leaves plain ASCII alone either way', () => {
		expect(decodeImportText(new TextEncoder().encode('Kyodai 6.0').buffer as ArrayBuffer)).toBe('Kyodai 6.0');
	});
});

describe('importLayouts', () => {
	function makeFile(content: string, name: string): File {
		return new File([content], name, { type: 'text/plain' });
	}

	it('should reject files larger than 10 MB', async () => {
		const big = new File([new ArrayBuffer(11 * 1024 * 1024)], 'big.mah');
		await expect(importLayouts(big)).rejects.toThrow('File too large');
	});

	it('should parse a valid .mah JSON file', async () => {
		const payload = JSON.stringify({
			mah: '1.0',
			boards: [{ id: 'abc', name: 'Test', map: [] }]
		});
		const file = makeFile(payload, 'boards.mah');
		const result = await importLayouts(file);
		expect(result).toHaveLength(1);
		expect(result[0].name).toBe('Test');
	});

	it('should reject invalid JSON for .mah file', async () => {
		const content = 'not json{{';
		const file = makeFile(content, 'boards.mah');
		await expect(importLayouts(file)).rejects.toThrow('Import failed: Invalid JSON format');
	});

	it('should reject valid JSON that is not a mah format', async () => {
		const content = JSON.stringify({ not: 'mah' });
		const file = makeFile(content, 'boards.mah');
		await expect(importLayouts(file)).rejects.toThrow('Import failed: Invalid or unsupported MAH format version');
	});

	it('should accept a .mah layout without an id', async () => {
		const payload = JSON.stringify({ mah: '1.0', boards: [{ name: 'Test', map: [] }] });
		const result = await importLayouts(makeFile(payload, 'boards.mah'));
		expect(result).toHaveLength(1);
		expect(result[0].name).toBe('Test');
	});

	it('should parse a .layout (kmahjongg v1.1) file', async () => {
		const data = [
			'kmahjongg-layout-v1.1',
			'# name: Dragon',
			'# by: Author',
			'w5',
			'h2',
			'd1',
			'10',
			'01'
		].join('\n');
		const file = makeFile(data, 'dragon.layout');
		const result = await importLayouts(file);
		expect(result).toHaveLength(1);
	});

	it('should parse a .lay (Kyodai 6.0) file', async () => {
		const kyodai = '0'.repeat(3400);
		const data = `Kyodai 6.0\nDragon\n${kyodai}\n`;
		const file = makeFile(data, 'dragon.lay');
		const result = await importLayouts(file);
		expect(result).toHaveLength(1);
	});

	it('should reject an unknown .layout format', async () => {
		const content = 'unknown-v99\n';
		const file = makeFile(content, 'test.layout');
		await expect(importLayouts(file)).rejects.toThrow('Unknown .layout format');
	});
});

// the real FileReader, so these cover the whole bytes -> text -> layout chain
describe('importLayouts encoding', () => {
	it('keeps a non-ASCII name and author in a UTF-8 kmahjongg file', async () => {
		const data = [
			'kmahjongg-layout-v1.1',
			'# name: Grüne Mauer',
			'# by: Jörg',
			'w2',
			'h2',
			'd1',
			'10',
			'01'
		].join('\n');
		const result = await importLayouts(new File([data], 'gruene.layout', { type: 'text/plain' }));
		expect(result[0].name).toBe('Grüne Mauer');
		expect(result[0].by).toBe('Jörg');
	});

	it('round-trips a non-ASCII name through the app own .mah format', async () => {
		const payload = JSON.stringify({ mah: '1.0', boards: [{ id: 'abc', name: 'Drachenmauer für Anfänger 龍', map: [] }] });
		const result = await importLayouts(new File([payload], 'boards.mah', { type: 'application/json' }));
		expect(result[0].name).toBe('Drachenmauer für Anfänger 龍');
	});

	it('still reads a legacy windows-1252 Kyodai file', async () => {
		const head = new TextEncoder().encode('Kyodai 6.0\nGr');
		// the windows-1252 byte for u-umlaut, which is not valid UTF-8
		const umlaut = new Uint8Array([0xFC]);
		const tail = new TextEncoder().encode(`ne\n${'0'.repeat(3400)}\n`);
		const result = await importLayouts(new File([head, umlaut, tail], 'gruene.lay', { type: 'text/plain' }));
		expect(result[0].name).toBe('Grüne');
	});
});
