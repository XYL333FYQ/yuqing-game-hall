import type { CompactMapping, CompactMappingX, CompactMappingY, ImportLayout, LoadLayout, Mapping, Place } from '../../../model/types';
import { mappingToID } from '../../../model/mapping';
import { parseMahFormat } from '../../../model/mah-reader';
import { optimizeMapping } from './optimize';

const MAX_IMPORT_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

export function sortMapping(mapping: Mapping): Mapping {
	return mapping.sort((a: Place, b: Place): number => {
		if (a[0] < b[0]) {
			return -1;
		}
		if (a[0] > b[0]) {
			return 1;
		}
		if (a[1] < b[1]) {
			return -1;
		}
		if (a[1] > b[1]) {
			return 1;
		}
		if (a[2] < b[2]) {
			return -1;
		}
		if (a[2] > b[2]) {
			return 1;
		}
		return 0;
	});
}

export async function convertMatrix(
	matrixCount: number, rowCount: number, cellCount: number,
	name: string, kyodai: string): Promise<ImportLayout> {
	const matrixLength: number = rowCount * cellCount;
	const totalLength: number = matrixLength * matrixCount;
	if (kyodai.length !== totalLength) {
		return Promise.reject(new Error('Invalid Matrix Pattern length'));
	}
	const layout: ImportLayout = { name, cat: 'Kyodai', mapping: [] };
	for (let z = 0; z < matrixCount; z++) {
		const matrix = kyodai.slice(z * matrixLength, (z + 1) * matrixLength);
		for (let y = 0; y < rowCount; y++) {
			const row = matrix.slice(y * cellCount, (y + 1) * cellCount);
			const cells = [...row];
			for (const [x, cell] of cells.entries()) {
				if (cell === '1') {
					layout.mapping.push([z, x, y]);
				}
			}
		}
	}
	return layout;
}

export async function convert3400Matrix(name: string, kyodai: string): Promise<ImportLayout> {
	return convertMatrix(5, 20, 34, name, kyodai);
}

export async function convertKmahjonggLines(lines: Array<string>, height: number): Promise<Mapping> {
	const result: Mapping = [];
	for (const [index, line] of lines.entries()) {
		const z = Math.floor(index / height);
		const y = (index % height);
		for (const [x, c] of [...line].entries()) {
			if (c === '1') {
				result.push([z, x, y]);
			}
		}
	}
	return result;
}

export async function convertKmahjongg(data: string, filename: string): Promise<ImportLayout> {
	let lines = data.replace(/\r\n/g, '\n').split('\n');
	const names = filename.split('.');
	names.pop();
	const version = lines.shift() ?? '';
	const layout: ImportLayout = {
		name: names.join('.').replace(/_/g, ' '),
		cat: 'uncategorized',
		mapping: []
	};
	if (['kmahjongg-layout-v1.0'].includes(version)) {
		layout.by = 'KDE Games team';
		layout.mapping = await convertKmahjonggLines(lines.filter(line => !line.startsWith('#')), 16);
		return layout;
	}
	if (['kmahjongg-layout-v1.1', 'mahjongg-layout-v1.1'].includes(version)) {
		const headerHeight = Number(lines.find(line => line.startsWith('h'))?.slice(1) ?? '');
		const height = headerHeight > 0 ? headerHeight : 16;
		const name = (lines.find(line => line.startsWith('# name:')) ?? '').slice(7).trim();
		layout.name = name || layout.name;
		layout.name = layout.name.length === 0 ? filename.split('.', 1)[0] : layout.name;
		const by = (lines.find(line => line.startsWith('# by:')) ?? '').slice(5).trim();
		layout.by = by || layout.by;
		lines = lines.filter(line => !line.startsWith('h') && !line.startsWith('w') && !line.startsWith('d') && !line.startsWith('#'));
		layout.mapping = await convertKmahjonggLines(lines, height);
		return layout;
	}
	const info = JSON.stringify((version ?? '').slice(0, 50));
	return Promise.reject(new Error(`Unknown .layout format ${info}`));
}

export async function convertKyodai(data: string, filename: string): Promise<ImportLayout> {
	// unify line endings
	const lines = data.replace(/\r\n/g, '\n').split('\n');
	const version = lines[0] || '';
	if (['Kyodai 3.0', 'Kyodai 6.0'].includes(version)) {
		const nameCat = (lines[1] || '').split('::');
		const name = nameCat[0] || filename.split('.', 1)[0];
		const cat = nameCat[1] || 'uncategorized';
		const layout = await convert3400Matrix(name, lines[2] || '');
		layout.cat = cat || layout.cat;
		return layout;
	}
	const versionPreview = JSON.stringify((version || '').slice(0, 50));
	return Promise.reject(new Error(`Unknown .lay format ${versionPreview}`));
}

interface MappingLayout {
	[key: number]: { [key: number]: Array<number> };
}

function createCompactMappingLayout(mapping: Mapping): MappingLayout {
	const layout: MappingLayout = {};
	const list = sortMapping(mapping);
	for (const m of list) {
		layout[m[0]] ||= {};
		layout[m[0]][m[2]] ||= [];
		layout[m[0]][m[2]].push(m[1]);
	}
	return layout;
}

export function compactY(z: number, y: number, layout: MappingLayout): CompactMappingY {
	const a: Array<number> = layout[z][y];
	const entries: Array<{ start: number; current: number; count: number }> = [];
	let entry = { start: -1, current: -1, count: 0 };
	for (const x of a) {
		if (x === entry.current) {
			entry.current += 2;
			entry.count++;
		} else {
			entry = { start: x, current: x + 2, count: 1 };
			entries.push(entry);
		}
	}
	const cells: CompactMappingX = entries.map(mappingEntry => {
		if (mappingEntry.count === 1) {
			return mappingEntry.start;
		}
		return [mappingEntry.start, mappingEntry.count];
	});
	return [y, (cells.length === 1 && !Array.isArray(cells[0])) ? cells[0] : cells];
}

export function compactMapping(mapping: Mapping): CompactMapping {
	const layout = createCompactMappingLayout(mapping);
	const result: CompactMapping = [];
	for (const z of Object.keys(layout)) {
		const rows: Array<CompactMappingY> =
			Array.from(Object.keys(layout[Number(z)]), y => compactY(Number(z), Number(y), layout));
		result.push([Number(z), rows]);
	}
	return result;
}

export function cleanNameCapitalized(s: string): string {
	return s.trim().split(' ').filter(Boolean).map(s => s.at(0)!.toUpperCase() + s.slice(1)).join(' ')
		.replace(/"/g, '')
		.replace(/(^'|'$)/gm, '');
}

export function cleanImportLayout(layout: ImportLayout): LoadLayout {
	// split author
	const sl = layout.name.split(' by ');
	if (sl.length > 1) {
		layout.name = sl[0].trim();
		layout.by = sl[1].trim();
	}
	// Capitalize
	layout.name = cleanNameCapitalized(layout.name || '');
	layout.by = layout.by ? cleanNameCapitalized(layout.by) : undefined;
	const map = optimizeMapping(layout.mapping);
	return {
		id: mappingToID(map),
		name: layout.name.trim(),
		cat: layout.cat.trim(),
		by: layout.by,
		map: compactMapping(map)
	};
}

export function decodeImportText(buffer: ArrayBuffer): string {
	try {
		return new TextDecoder('utf-8', { fatal: true }).decode(buffer);
	} catch {
		return new TextDecoder('windows-1252').decode(buffer);
	}
}

export async function readFile(file: File): Promise<string> {
	try {
		return decodeImportText(await file.arrayBuffer());
	} catch (error) {
		throw new Error(`Reading File failed: ${error instanceof Error ? error.message : 'unknown error'}`, { cause: error });
	}
}

export async function importLayouts(file: File): Promise<Array<LoadLayout>> {
	if (file.size > MAX_IMPORT_FILE_SIZE) {
		return Promise.reject(new Error('File too large (max 10 MB)'));
	}
	const data = await readFile(file);
	const extension = (file.name.split('.').pop() ?? '').toLowerCase();
	let layout: LoadLayout;
	if (extension === 'lay') {
		layout = cleanImportLayout(await convertKyodai(data, file.name));
	} else if (extension === 'layout') {
		layout = cleanImportLayout(await convertKmahjongg(data, file.name));
	} else {
		return parseMahFormat(data).boards;
	}
	return [layout];
}
