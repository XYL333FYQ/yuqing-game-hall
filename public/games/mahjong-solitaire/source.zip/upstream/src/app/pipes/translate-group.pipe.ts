import { inject, Pipe, type PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Pipe({
	name: 'translateGroup'
})
export class TranslateGroupPipe implements PipeTransform {
	readonly translate = inject(TranslateService);

	transform(value: string, _lang: string | null): string {
		const key = `CAT_${value.toUpperCase()}`;
		const translation = this.translate.instant(key);
		return translation === key ? value : translation;
	}
}
