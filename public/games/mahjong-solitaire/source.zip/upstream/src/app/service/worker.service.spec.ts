import { TestBed } from '@angular/core/testing';
import { WorkerService } from './worker.service';
import * as workerFactorySolve from '../worker/create-solve.worker';
import * as workerFactoryStats from '../worker/create-stats-solve.worker';
import * as tasks from '../model/tasks';
import type { StonePosition } from '../model/stone';
import type { Mapping } from '../model/types';
import { type Mock, describe, beforeEach, afterEach, it, expect, vi } from 'vitest';

const mockTasks = {
	solveGame: vi.spyOn(tasks, 'solveGame'),
	statsSolveMapping: vi.spyOn(tasks, 'statsSolveMapping')
};
const mockFactories = {
	createSolveWorker: vi.spyOn(workerFactorySolve, 'createSolveWorker') as unknown as Mock,
	createStatsSolveWorker: vi.spyOn(workerFactoryStats, 'createStatsSolveWorker') as unknown as Mock
};

class FakeWorker {
}

class MockWorker extends EventTarget {
	postMessage = vi.fn();
	terminate = vi.fn();
}

describe('WorkerService', () => {
	let service: WorkerService;
	let originalWorker: typeof Worker;

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [WorkerService]
		});
		service = TestBed.inject(WorkerService);
		originalWorker = global.Worker;
	});

	afterEach(() => {
		global.Worker = originalWorker;
	});

	describe('solveGame', () => {
		it('should create service', () => {
			expect(service).toBeTruthy();
		});

		it('should call fallback when Worker is not available', () => {
			const stones: Array<StonePosition> = [
				{ x: 0, y: 0, z: 0, v: 1, groupNr: 1 }
			];
			const finish = vi.fn();

			// @ts-expect-error - Mocking Worker
			global.Worker = undefined;

			const result = service.solveGame(stones, finish);

			expect(result).toBeUndefined();
			expect(mockTasks.solveGame).toHaveBeenCalledWith(stones, finish);
		});

		it('should return undefined and call fallback when worker creation fails', () => {
			const stones: Array<StonePosition> = [
				{ x: 0, y: 0, z: 0, v: 1, groupNr: 1 }
			];
			const finish = vi.fn();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createSolveWorker.mockReturnValue(null);

			const result = service.solveGame(stones, finish);

			expect(result).toBeUndefined();
			expect(mockTasks.solveGame).toHaveBeenCalledWith(stones, finish);
		});

		it('should return worker and call finish when result message is received', () => {
			const stones: Array<StonePosition> = [
				{ x: 0, y: 0, z: 0, v: 1, groupNr: 1 }
			];
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createSolveWorker.mockReturnValue(mockWorker);

			const result = service.solveGame(stones, finish);

			expect(result).toBe(mockWorker);
			expect(mockWorker.postMessage).toHaveBeenCalledWith({ stones });

			const solveResult = { result: 1, order: [] };
			mockWorker.dispatchEvent(new MessageEvent('message', { data: { result: solveResult } }));

			expect(finish).toHaveBeenCalledWith(solveResult);
			expect(mockWorker.terminate).toHaveBeenCalled();
		});

		it('should ignore messages without result', () => {
			const stones: Array<StonePosition> = [
				{ x: 0, y: 0, z: 0, v: 1, groupNr: 1 }
			];
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createSolveWorker.mockReturnValue(mockWorker);

			service.solveGame(stones, finish);

			mockWorker.dispatchEvent(new MessageEvent('message', { data: {} }));

			expect(finish).not.toHaveBeenCalled();
			expect(mockWorker.terminate).not.toHaveBeenCalled();
		});

		// re-running the solver on the main thread would just throw again, so a worker
		// failure reports an empty solution instead of falling back
		it('should terminate and report an empty solution on worker error', () => {
			const stones: Array<StonePosition> = [
				{ x: 0, y: 0, z: 0, v: 1, groupNr: 1 }
			];
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createSolveWorker.mockReturnValue(mockWorker);

			service.solveGame(stones, finish);
			mockTasks.solveGame.mockClear();

			mockWorker.dispatchEvent(new Event('error'));

			expect(mockWorker.terminate).toHaveBeenCalled();
			expect(mockTasks.solveGame).not.toHaveBeenCalled();
			expect(finish).toHaveBeenCalledWith({ result: stones.length, order: [] });
		});

		it('should terminate and report an empty solution when the worker posts an error', () => {
			const stones: Array<StonePosition> = [
				{ x: 0, y: 0, z: 0, v: 1, groupNr: 1 }
			];
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createSolveWorker.mockReturnValue(mockWorker);

			service.solveGame(stones, finish);
			mockTasks.solveGame.mockClear();

			mockWorker.dispatchEvent(new MessageEvent('message', { data: { error: 'boom' } }));

			expect(mockWorker.terminate).toHaveBeenCalled();
			expect(mockTasks.solveGame).not.toHaveBeenCalled();
			expect(finish).toHaveBeenCalledWith({ result: stones.length, order: [] });
		});

		it('should report only the first outcome when an error follows the result', () => {
			const stones: Array<StonePosition> = [
				{ x: 0, y: 0, z: 0, v: 1, groupNr: 1 }
			];
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createSolveWorker.mockReturnValue(mockWorker);

			service.solveGame(stones, finish);

			const solveResult = { result: 1, order: [] };
			mockWorker.dispatchEvent(new MessageEvent('message', { data: { result: solveResult } }));
			mockWorker.dispatchEvent(new MessageEvent('message', { data: { error: 'boom' } }));
			mockWorker.dispatchEvent(new Event('error'));

			expect(finish).toHaveBeenCalledTimes(1);
			expect(finish).toHaveBeenCalledWith(solveResult);
		});

		it('should report only the first outcome when an error event follows an error message', () => {
			const stones: Array<StonePosition> = [
				{ x: 0, y: 0, z: 0, v: 1, groupNr: 1 }
			];
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createSolveWorker.mockReturnValue(mockWorker);

			service.solveGame(stones, finish);

			mockWorker.dispatchEvent(new MessageEvent('message', { data: { error: 'boom' } }));
			mockWorker.dispatchEvent(new Event('error'));

			expect(finish).toHaveBeenCalledTimes(1);
		});
	});

	describe('solve', () => {
		it('should call fallback when Worker is not available', () => {
			const mapping: Mapping = [[0, 0, 0], [2, 2, 2]];
			const rounds = 10;
			const callback = vi.fn();
			const finish = vi.fn();

			// @ts-expect-error - Mocking Worker
			global.Worker = undefined;

			const result = service.solve(mapping, rounds, callback, finish);

			expect(result).toBeUndefined();
			expect(mockTasks.statsSolveMapping).toHaveBeenCalledWith(mapping, rounds, callback, finish);
		});

		it('should return undefined and call fallback when worker creation fails', () => {
			const mapping: Mapping = [[0, 0, 0], [2, 2, 2]];
			const rounds = 10;
			const callback = vi.fn();
			const finish = vi.fn();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createStatsSolveWorker.mockReturnValue(null);

			const result = service.solve(mapping, rounds, callback, finish);

			expect(result).toBeUndefined();
			expect(mockTasks.statsSolveMapping).toHaveBeenCalledWith(mapping, rounds, callback, finish);
		});

		it('should return worker, call callback on progress, and call finish when result is received', () => {
			const mapping: Mapping = [[0, 0, 0], [2, 2, 2]];
			const rounds = 10;
			const callback = vi.fn();
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createStatsSolveWorker.mockReturnValue(mockWorker);

			const result = service.solve(mapping, rounds, callback, finish);

			expect(result).toBe(mockWorker);
			expect(mockWorker.postMessage).toHaveBeenCalledWith({ mapping, rounds });

			const progress = [1, 2, 3];
			mockWorker.dispatchEvent(new MessageEvent('message', { data: { progress } }));

			expect(callback).toHaveBeenCalledWith(progress);
			expect(finish).not.toHaveBeenCalled();

			const solveResult = [10, 20, 30];
			mockWorker.dispatchEvent(new MessageEvent('message', { data: { result: solveResult } }));

			expect(finish).toHaveBeenCalledWith(solveResult);
			expect(mockWorker.terminate).toHaveBeenCalled();
		});

		it('should stop receiving progress after result is received', () => {
			const mapping: Mapping = [[0, 0, 0]];
			const rounds = 5;
			const callback = vi.fn();
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createStatsSolveWorker.mockReturnValue(mockWorker);

			service.solve(mapping, rounds, callback, finish);

			mockWorker.dispatchEvent(new MessageEvent('message', { data: { result: [1, 2] } }));

			expect(finish).toHaveBeenCalledTimes(1);

			mockWorker.dispatchEvent(new MessageEvent('message', { data: { progress: [3, 4] } }));

			expect(callback).not.toHaveBeenCalled();
		});

		it('should terminate and report no rounds on worker error', () => {
			const mapping: Mapping = [[0, 0, 0], [2, 2, 2]];
			const rounds = 10;
			const callback = vi.fn();
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createStatsSolveWorker.mockReturnValue(mockWorker);

			service.solve(mapping, rounds, callback, finish);
			mockTasks.statsSolveMapping.mockClear();

			mockWorker.dispatchEvent(new Event('error'));

			expect(mockWorker.terminate).toHaveBeenCalled();
			expect(mockTasks.statsSolveMapping).not.toHaveBeenCalled();
			expect(finish).toHaveBeenCalledWith([0, 0]);
		});

		it('should terminate and report no rounds when the worker posts an error', () => {
			const mapping: Mapping = [[0, 0, 0], [2, 2, 2]];
			const rounds = 10;
			const callback = vi.fn();
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createStatsSolveWorker.mockReturnValue(mockWorker);

			service.solve(mapping, rounds, callback, finish);
			mockTasks.statsSolveMapping.mockClear();

			mockWorker.dispatchEvent(new MessageEvent('message', { data: { error: 'boom' } }));

			expect(mockWorker.terminate).toHaveBeenCalled();
			expect(mockTasks.statsSolveMapping).not.toHaveBeenCalled();
			expect(finish).toHaveBeenCalledWith([0, 0]);
		});

		// the layout tester chains the next run off finish, so a second call used to start a
		// parallel chain and overwrite the numbers it had just reported with [0, 0]
		it('should report only the first outcome when an error follows the result', () => {
			const mapping: Mapping = [[0, 0, 0], [2, 2, 2]];
			const callback = vi.fn();
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createStatsSolveWorker.mockReturnValue(mockWorker);

			service.solve(mapping, 10, callback, finish);

			const solveResult = [7, 3];
			mockWorker.dispatchEvent(new MessageEvent('message', { data: { result: solveResult } }));
			mockWorker.dispatchEvent(new MessageEvent('message', { data: { error: 'boom' } }));
			mockWorker.dispatchEvent(new Event('error'));

			expect(finish).toHaveBeenCalledTimes(1);
			expect(finish).toHaveBeenCalledWith(solveResult);
		});

		it('should report only the first outcome when an error event follows an error message', () => {
			const mapping: Mapping = [[0, 0, 0], [2, 2, 2]];
			const callback = vi.fn();
			const finish = vi.fn();
			const mockWorker = new MockWorker();

			// @ts-expect-error - Mocking Worker
			global.Worker = FakeWorker;
			mockFactories.createStatsSolveWorker.mockReturnValue(mockWorker);

			service.solve(mapping, 10, callback, finish);

			mockWorker.dispatchEvent(new MessageEvent('message', { data: { error: 'boom' } }));
			mockWorker.dispatchEvent(new Event('error'));

			expect(finish).toHaveBeenCalledTimes(1);
			expect(finish).toHaveBeenCalledWith([0, 0]);
		});
	});
});
