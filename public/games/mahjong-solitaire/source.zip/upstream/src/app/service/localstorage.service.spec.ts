import { TestBed } from '@angular/core/testing';
import { LocalstorageService } from './localstorage.service';
import { log } from '../model/log';
import { Game } from '../model/game';
import { Settings } from '../model/settings';
import { GAME_MODE_STANDARD, ImageSetDefault, LangDefault, STATES } from '../model/consts';
import type { GameStateStore, Layout, LayoutScoreStore, LoadLayout, SettingsStore } from '../model/types';
import { type Mock, type MockInstance, describe, beforeEach, afterEach, it, expect, vi } from 'vitest';

describe('LocalstorageService', () => {
	let service: LocalstorageService;
	let localStorageMock: {
		getItem: Mock;
		setItem: Mock;
		removeItem: Mock;
	};
	let originalLocalStorage: Storage;
	let logWarnSpy: MockInstance;

	beforeEach(() => {
		// Save original localStorage
		originalLocalStorage = global.localStorage;

		// Create localStorage mock
		localStorageMock = {
			getItem: vi.fn(),
			setItem: vi.fn(),
			removeItem: vi.fn()
		};

		// Replace localStorage with mock
		Object.defineProperty(window, 'localStorage', {
			value: localStorageMock,
			writable: true
		});

		// Configure TestBed
		TestBed.configureTestingModule({
			providers: [LocalstorageService]
		});

		service = TestBed.inject(LocalstorageService);
		vi.clearAllMocks(); // clear calls accumulated during service construction
		logWarnSpy = vi.spyOn(log, 'warn').mockReturnValue(undefined);
	});

	afterEach(() => {
		Object.defineProperty(window, 'localStorage', {
			value: originalLocalStorage,
			writable: true
		});
	});

	describe('initialization', () => {
		it('should be created', () => {
			expect(service).toBeTruthy();
		});

		it('should call updateData during initialization', () => {
			// Create a new instance to verify constructor behavior
			const updateDataSpy = vi.spyOn(LocalstorageService.prototype as unknown as HackLocalstorgageService, 'updateData');
			let newService!: LocalstorageService;
			TestBed.runInInjectionContext(() => {
				newService = new LocalstorageService();
			});

			expect(newService).toBeTruthy();

			expect(updateDataSpy).toHaveBeenCalled();
		});
	});

	describe('getScore', () => {
		it('should get score for a layout', () => {
			const mockScore: LayoutScoreStore = { winCount: 5, loseCount: 1, playTime: 100, bestTime: 1000 };
			localStorageMock.getItem.mockReturnValue(JSON.stringify(mockScore));

			const result = service.getScore('test-layout');

			expect(result).toEqual(mockScore);
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.score.test-layout');
		});

		it('should return undefined if no score exists', () => {
			localStorageMock.getItem.mockReturnValue(null);

			const result = service.getScore('test-layout');

			expect(result).toBeUndefined();
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.score.test-layout');
		});

		it('should handle localStorage errors', () => {
			localStorageMock.getItem.mockImplementation(() => {
				throw new Error('Test error');
			});

			const result = service.getScore('test-layout');

			expect(result).toBeUndefined();
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.score.test-layout');
		});
	});

	describe('getScores', () => {
		it('should collect all stored scores in one key scan', () => {
			const entries: Record<string, string> = {
				'mah.score.layout-a': JSON.stringify({ winCount: 1 }),
				'mah.settings': JSON.stringify({}),
				'mah.score.layout-b': JSON.stringify({ bestTime: 500 }),
				'unrelated': 'x'
			};
			const keys = Object.keys(entries);
			Object.defineProperty(window, 'localStorage', {
				value: {
					getItem: vi.fn((key: string) => entries[key] ?? null),
					setItem: vi.fn(),
					removeItem: vi.fn(),
					key: vi.fn((index: number) => keys[index] ?? null),
					length: keys.length
				},
				writable: true
			});

			const scores = service.getScores();

			expect(scores.size).toBe(2);
			expect(scores.get('layout-a')).toEqual({ winCount: 1 });
			expect(scores.get('layout-b')).toEqual({ bestTime: 500 });
		});
	});

	describe('getSettings', () => {
		it('should get settings', () => {
			const mockSettings: SettingsStore = {
				lang: 'en',
				sounds: true,
				music: false,
				contrast: false,
				dark: false,
				tileset: 'default',
				theme: 'light',
				background: ''
			};
			localStorageMock.getItem.mockReturnValue(JSON.stringify(mockSettings));

			const result = service.getSettings();

			expect(result).toEqual(mockSettings);
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.settings');
		});

		it('should return undefined if no settings exist', () => {
			localStorageMock.getItem.mockReturnValue(null);

			const result = service.getSettings();

			expect(result).toBeUndefined();
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.settings');
		});
	});

	describe('getState', () => {
		it('should get game state', () => {
			const mockState: GameStateStore = {
				elapsed: 1000,
				state: 1,
				layout: 'test-layout',
				gameMode: 'GAME_MODE_STANDARD',
				undo: [[0, 0, 0]],
				stones: [[0, 0, 0, 1]]
			};
			localStorageMock.getItem.mockReturnValue(JSON.stringify(mockState));

			const result = service.getState();

			expect(result).toEqual(mockState);
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.state');
		});

		it('should return undefined if no state exists', () => {
			localStorageMock.getItem.mockReturnValue(null);

			const result = service.getState();

			expect(result).toBeUndefined();
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.state');
		});
	});

	describe('getCustomLayouts', () => {
		it('should get custom layouts', () => {
			const mockLayouts: Array<LoadLayout> = [
				{ id: 'custom1', name: 'Custom 1', cat: 'Test', map: [] }
			];
			localStorageMock.getItem.mockReturnValue(JSON.stringify(mockLayouts));

			const result = service.getCustomLayouts();

			expect(result).toEqual(mockLayouts);
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.boards');
		});

		it('should return undefined if no custom layouts exist', () => {
			localStorageMock.getItem.mockReturnValue(null);

			const result = service.getCustomLayouts();

			expect(result).toBeUndefined();
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.boards');
		});
	});

	describe('getLastPlayed', () => {
		it('should get last played layout ID', () => {
			localStorageMock.getItem.mockReturnValue('test-layout');

			const result = service.getLastPlayed();

			expect(result).toBe('test-layout');
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.last');
		});

		it('should return undefined if no last played layout exists', () => {
			localStorageMock.getItem.mockReturnValue(null);

			const result = service.getLastPlayed();

			expect(result).toBeUndefined();
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.last');
		});

		it('should handle localStorage errors', () => {
			localStorageMock.getItem.mockImplementation(() => {
				throw new Error('Test error');
			});

			const result = service.getLastPlayed();

			expect(result).toBeUndefined();
			expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.last');
			expect(logWarnSpy).toHaveBeenCalled();
		});

		it('should handle missing localStorage', () => {
			// Temporarily remove localStorage
			Object.defineProperty(window, 'localStorage', {
				value: undefined,
				writable: true
			});

			const result = service.getLastPlayed();

			expect(result).toBeUndefined();
			expect(localStorageMock.getItem).not.toHaveBeenCalled();

			// Restore localStorage mock
			Object.defineProperty(window, 'localStorage', {
				value: localStorageMock,
				writable: true
			});
		});
	});

	describe('storeLastPlayed', () => {
		it('should store last played layout ID', () => {
			service.storeLastPlayed('test-layout');

			expect(localStorageMock.setItem).toHaveBeenCalledWith('mah.last', 'test-layout');
		});

		it('should remove last played layout ID if empty', () => {
			service.storeLastPlayed('');

			expect(localStorageMock.removeItem).toHaveBeenCalledWith('mah.last');
			expect(localStorageMock.setItem).not.toHaveBeenCalled();
		});

		it('should handle localStorage errors', () => {
			localStorageMock.setItem.mockImplementation(() => {
				throw new Error('Test error');
			});

			service.storeLastPlayed('test-layout');

			expect(localStorageMock.setItem).toHaveBeenCalledWith('mah.last', 'test-layout');
			expect(logWarnSpy).toHaveBeenCalled();
		});

		it('should handle missing localStorage', () => {
			// Temporarily remove localStorage
			Object.defineProperty(window, 'localStorage', {
				value: undefined,
				writable: true
			});

			service.storeLastPlayed('test-layout');

			expect(localStorageMock.setItem).not.toHaveBeenCalled();

			// Restore localStorage mock
			Object.defineProperty(window, 'localStorage', {
				value: localStorageMock,
				writable: true
			});
		});
	});

	describe('storeScore', () => {
		it('should store score for a layout', () => {
			const mockScore: LayoutScoreStore = { winCount: 5, loseCount: 1, playTime: 100, bestTime: 1000 };

			service.storeScore('test-layout', mockScore);

			expect(localStorageMock.setItem).toHaveBeenCalledWith(
				'mah.score.test-layout',
				JSON.stringify(mockScore)
			);
		});

		it('should remove score if undefined', () => {
			service.storeScore('test-layout', undefined);

			expect(localStorageMock.removeItem).toHaveBeenCalledWith('mah.score.test-layout');
			expect(localStorageMock.setItem).not.toHaveBeenCalled();
		});
	});

	describe('clearScore', () => {
		it('should clear score for a layout', () => {
			service.clearScore('test-layout');

			expect(localStorageMock.removeItem).toHaveBeenCalledWith('mah.score.test-layout');
		});
	});

	describe('storeSettings', () => {
		it('should store settings', () => {
			const mockSettings: SettingsStore = {
				lang: 'en',
				sounds: true,
				music: false,
				contrast: false,
				dark: false,
				tileset: 'default',
				theme: 'light',
				background: ''
			};

			service.storeSettings(mockSettings);

			expect(localStorageMock.setItem).toHaveBeenCalledWith(
				'mah.settings',
				JSON.stringify(mockSettings)
			);
		});

		it('should remove settings if undefined', () => {
			service.storeSettings(undefined);

			expect(localStorageMock.removeItem).toHaveBeenCalledWith('mah.settings');
			expect(localStorageMock.setItem).not.toHaveBeenCalled();
		});
	});

	describe('storeState', () => {
		it('should store game state', () => {
			const mockState: GameStateStore = {
				elapsed: 1000,
				state: 1,
				layout: 'test-layout',
				gameMode: 'GAME_MODE_STANDARD',
				undo: [[0, 0, 0]],
				stones: [[0, 0, 0, 1]]
			};

			service.storeState(mockState);

			expect(localStorageMock.setItem).toHaveBeenCalledWith(
				'mah.state',
				JSON.stringify(mockState)
			);
		});

		it('should remove state if undefined', () => {
			service.storeState(undefined);

			expect(localStorageMock.removeItem).toHaveBeenCalledWith('mah.state');
			expect(localStorageMock.setItem).not.toHaveBeenCalled();
		});
	});

	describe('storeCustomLayouts', () => {
		it('should store custom layouts', () => {
			const mockLayouts: Array<LoadLayout> = [
				{ id: 'custom1', name: 'Custom 1', cat: 'Test', map: [] }
			];

			service.storeCustomLayouts(mockLayouts);

			expect(localStorageMock.setItem).toHaveBeenCalledWith(
				'mah.boards',
				JSON.stringify(mockLayouts)
			);
		});

		it('should remove custom layouts if undefined', () => {
			service.storeCustomLayouts(undefined);

			expect(localStorageMock.removeItem).toHaveBeenCalledWith('mah.boards');
			expect(localStorageMock.setItem).not.toHaveBeenCalled();
		});
	});

	interface HackLocalstorgageService {
		get<T>(key: string): T | undefined;

		set<T>(key: string, data?: T): void;

		updateData(): void;
	}

	describe('private methods', () => {
		describe('get', () => {
			it('should get data from localStorage with prefix', () => {
				localStorageMock.getItem.mockReturnValue(JSON.stringify({ test: 'data' }));

				const result =
					(service as unknown as HackLocalstorgageService)
						.get('test-key');

				expect(result).toEqual({ test: 'data' });
				expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.test-key');
			});

			it('should return undefined if data does not exist', () => {
				localStorageMock.getItem.mockReturnValue(null);

				const result =
					(service as unknown as HackLocalstorgageService).get('test-key');

				expect(result).toBeUndefined();
				expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.test-key');
			});

			it('should handle JSON parse errors', () => {
				localStorageMock.getItem.mockReturnValue('invalid-json');

				const result =
					(service as unknown as HackLocalstorgageService).get('test-key');

				expect(result).toBeUndefined();
				expect(localStorageMock.getItem).toHaveBeenCalledWith('mah.test-key');
			});

			it('should handle missing localStorage', () => {
				// Temporarily remove localStorage
				Object.defineProperty(window, 'localStorage', {
					value: undefined,
					writable: true
				});

				const result =
					(service as unknown as HackLocalstorgageService)
						.get('test-key');

				expect(result).toBeUndefined();
				expect(localStorageMock.getItem).not.toHaveBeenCalled();

				// Restore localStorage mock
				Object.defineProperty(window, 'localStorage', {
					value: localStorageMock,
					writable: true
				});
			});
		});

		describe('set', () => {
			it('should set data in localStorage with prefix', () => {
				const data = { test: 'data' };

				(service as unknown as HackLocalstorgageService)
					.set('test-key', data);

				expect(localStorageMock.setItem).toHaveBeenCalledWith(
					'mah.test-key',
					JSON.stringify(data)
				);
			});

			it('should remove data if undefined', () => {
				(service as unknown as HackLocalstorgageService)
					.set('test-key', undefined);

				expect(localStorageMock.removeItem).toHaveBeenCalledWith('mah.test-key');
				expect(localStorageMock.setItem).not.toHaveBeenCalled();
			});

			it('should handle missing localStorage', () => {
				// Temporarily remove localStorage
				Object.defineProperty(window, 'localStorage', {
					value: undefined,
					writable: true
				});

				(service as unknown as HackLocalstorgageService)
					.set('test-key', { test: 'data' });

				expect(localStorageMock.setItem).not.toHaveBeenCalled();
				expect(localStorageMock.removeItem).not.toHaveBeenCalled();

				// Restore localStorage mock
				Object.defineProperty(window, 'localStorage', {
					value: localStorageMock,
					writable: true
				});
			});
		});

		describe('updateData', () => {
			it('should migrate old data to new format', () => {
				// Setup old data
				localStorageMock.getItem.mockImplementation((key: string) => {
					if (key === 'state') {
						return JSON.stringify({ test: 'state' });
					}
					if (key === 'settings') {
						return JSON.stringify({ test: 'settings' });
					}
					return null;
				});

				// Call updateData
				(service as unknown as HackLocalstorgageService)
					.updateData();

				// Verify old data was removed
				expect(localStorageMock.removeItem).toHaveBeenCalledWith('state');
				expect(localStorageMock.removeItem).toHaveBeenCalledWith('settings');

				// Verify new data was set
				expect(localStorageMock.setItem).toHaveBeenCalledWith(
					'mah.state',
					JSON.stringify({ test: 'state' })
				);
				expect(localStorageMock.setItem).toHaveBeenCalledWith(
					'mah.settings',
					JSON.stringify({ test: 'settings' })
				);
			});

			it('should keep a newer prefixed entry and drop the old one', () => {
				localStorageMock.getItem.mockImplementation((key: string) => {
					if (key === 'state') {
						return JSON.stringify({ layout: 'ancient-save' });
					}
					if (key === 'mah.state') {
						return JSON.stringify({ layout: 'new-save' });
					}
					return null;
				});

				(service as unknown as HackLocalstorgageService)
					.updateData();

				expect(localStorageMock.setItem).not.toHaveBeenCalledWith('mah.state', expect.anything());
				expect(localStorageMock.removeItem).toHaveBeenCalledWith('state');
			});

			it('should handle missing old data', () => {
				localStorageMock.getItem.mockReturnValue(null);

				(service as unknown as HackLocalstorgageService)
					.updateData();

				expect(localStorageMock.removeItem).not.toHaveBeenCalled();
				expect(localStorageMock.setItem).not.toHaveBeenCalled();
			});

			it('should remove corrupted old data even when JSON.parse fails', () => {
				// Setup corrupted data that will fail JSON.parse
				localStorageMock.getItem.mockImplementation((key: string) => {
					if (key === 'state') {
						return '{invalid json';
					}
					if (key === 'settings') {
						return 'not json at all';
					}
					return null;
				});

				// Call updateData
				(service as unknown as HackLocalstorgageService)
					.updateData();

				// Verify old data was removed despite parse errors
				expect(localStorageMock.removeItem).toHaveBeenCalledWith('state');
				expect(localStorageMock.removeItem).toHaveBeenCalledWith('settings');

				// Verify warnings were logged
				expect(logWarnSpy).toHaveBeenCalledWith(
					'Failed to parse old state data, removing corrupted entry:',
					expect.any(Error)
				);
				expect(logWarnSpy).toHaveBeenCalledWith(
					'Failed to parse old settings data, removing corrupted entry:',
					expect.any(Error)
				);

				// Verify new data was NOT set (because parse failed)
				expect(localStorageMock.setItem).not.toHaveBeenCalledWith(
					'mah.state',
					expect.anything()
				);
				expect(localStorageMock.setItem).not.toHaveBeenCalledWith(
					'mah.settings',
					expect.anything()
				);
			});

			it('should handle localStorage errors', () => {
				localStorageMock.getItem.mockImplementation(() => {
					throw new Error('Test error');
				});

				(service as unknown as HackLocalstorgageService)
					.updateData();

				expect(logWarnSpy).toHaveBeenCalled();
			});

			it('should handle missing localStorage', () => {
				// Temporarily remove localStorage
				Object.defineProperty(window, 'localStorage', {
					value: undefined,
					writable: true
				});

				(service as unknown as HackLocalstorgageService)
					.updateData();

				expect(localStorageMock.getItem).not.toHaveBeenCalled();
				expect(localStorageMock.setItem).not.toHaveBeenCalled();
				expect(localStorageMock.removeItem).not.toHaveBeenCalled();

				// Restore localStorage mock
				Object.defineProperty(window, 'localStorage', {
					value: localStorageMock,
					writable: true
				});
			});
		});
	});
});

describe('LocalstorageService with denied storage access', () => {
	let originalLocalStorage: Storage;
	let service: LocalstorageService;

	beforeEach(() => {
		originalLocalStorage = global.localStorage;
		Object.defineProperty(window, 'localStorage', {
			get(): Storage {
				throw new DOMException('The operation is insecure.', 'SecurityError');
			},
			configurable: true
		});
		vi.spyOn(log, 'warn').mockReturnValue(undefined);
		TestBed.configureTestingModule({
			providers: [LocalstorageService]
		});
		service = TestBed.inject(LocalstorageService);
	});

	afterEach(() => {
		Object.defineProperty(window, 'localStorage', {
			value: originalLocalStorage,
			writable: true,
			configurable: true
		});
	});

	it('should be created and report missing persistence', () => {
		expect(service).toBeTruthy();
		expect(service.persistent()).toBe(false);
	});

	it('should report the denied access only once', () => {
		service.getSettings();
		service.getState();

		expect(log.warn).toHaveBeenCalledTimes(1);
	});

	it('should read nothing and never throw', () => {
		expect(service.getSettings()).toBeUndefined();
		expect(service.getState()).toBeUndefined();
		expect(service.getCustomLayouts()).toBeUndefined();
		expect(service.getLastPlayed()).toBeUndefined();
		expect(service.getScores().size).toBe(0);
		expect(service.getDailyMonthKeys()).toEqual([]);
		expect(service.getDailyMeta()).toBeUndefined();
	});

	it('should ignore writes without throwing', () => {
		service.storeState({ layout: 'test', gameMode: GAME_MODE_STANDARD, elapsed: 42 });
		service.storeLastPlayed('test');
		service.storeScore('test', { winCount: 1, loseCount: 0, playTime: 10, bestTime: 10 });
		service.storeDailyMonth('2026-09', { v: 1, days: {} });
		service.storeCustomLayouts([]);

		expect(service.getState()).toBeUndefined();
		expect(service.getLastPlayed()).toBeUndefined();
		expect(service.getScores().size).toBe(0);
	});

	it('should load default settings and survive saving them', () => {
		const settings = new Settings(service);

		expect(settings.load()).toBe(true);
		expect(settings.tileset()).toBe(ImageSetDefault);
		expect(settings.lang()).toBe(LangDefault);

		settings.dark.set(true);

		expect(settings.save()).toBe(true);
	});

	it('should allow a playable game session', () => {
		const game = new Game(service);
		const layout: Layout = { id: 'test', name: 'Test', category: 'Test', mapping: [[0, 0, 0], [0, 2, 0]] };

		game.start(layout, 'MODE_SOLVABLE', GAME_MODE_STANDARD);

		expect(game.state()).toBe(STATES.run);
		expect(game.board.count()).toBe(2);

		game.save();

		expect(game.load()).toBe(false);

		game.destroy();
	});
});
