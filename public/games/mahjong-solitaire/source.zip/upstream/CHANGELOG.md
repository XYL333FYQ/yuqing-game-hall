# Changelog

All notable changes to this project will be documented in this file. See [commit-and-tag-version](https://github.com/absolute-version/commit-and-tag-version) for commit guidelines.

## [2.1.1](https://github.com/ffalt/mah/compare/v2.1.0...v2.1.1) (2026-09-28)

### Features

* **tauri:** add zsync and metadata support for linux builds ([3154810](https://github.com/ffalt/mah/commit/3154810c8cbd8272ac02fdfc8974cbc5a96b10fb))

## [2.1.0](https://github.com/ffalt/mah/compare/v2.0.0...v2.1.0) (2026-09-28)

### Features

* **categories:** limit the categories nav bar to 1 line, show on all screen sizes, allow expanding/collapsing and panning/scrolling ([18c2528](https://github.com/ffalt/mah/commit/18c25284f66c6ac60a5b5a0c6fa76ec5c3186a59))
* **i18n:** add Icelandic language ([737669d](https://github.com/ffalt/mah/commit/737669d181abea8a84f8f9b555522e9a02bd279f))
* **i18n:** add Irish language ([1d6f7cc](https://github.com/ffalt/mah/commit/1d6f7ccf62079a30f793fac7073dc3d20260a790))
* **i18n:** add Mongolian language ([0ee80fc](https://github.com/ffalt/mah/commit/0ee80fc20044263e4ae45844ccd5ae12ab883afe))

### Bug Fixes

* **tauri:** update to fix AppImage issue https://github.com/tauri-apps/tauri/issues/16155 ([9f31b2b](https://github.com/ffalt/mah/commit/9f31b2b947c72efa8b7c64671958d18a6eec802f))

## [2.0.0](https://github.com/ffalt/mah/compare/v1.21.0...v2.0.0) (2026-09-12)

### Features

* **animations:** add animation settings in board and respect browser settings ([8338fc7](https://github.com/ffalt/mah/commit/8338fc7ca2f3cb1e6450da042b7abd38ac5385be))
* **confetti:** disable with prefers-reduced-motion browser setting ([abbe416](https://github.com/ffalt/mah/commit/abbe416c222c0c571bdd204f8b181679b5380628))
* **dependabot:** add support for vitest and eslint package group patterns ([d579cd7](https://github.com/ffalt/mah/commit/d579cd7c50f3cda2cfac80d3f17f4a12641aa0de))
* **editor:** add functionality to duplicate layers with no tiles ([e8457b3](https://github.com/ffalt/mah/commit/e8457b3810f4e5f23f31f43e192c666c61d5781b))
* **editor:** add layer above button ([513adb5](https://github.com/ffalt/mah/commit/513adb5b59d1be08f10edc9dc1e3f6ed5382fdcf))
* **editor:** better layout on small screens ([0cf5401](https://github.com/ffalt/mah/commit/0cf54012190a41393ee308a0490134da98b487eb))
* **editor:** move editor localization files out of the main files ([c7d05c5](https://github.com/ffalt/mah/commit/c7d05c5962643758ba5ff0e522df1342b37f9f01))
* **game:** introduce daily challenges ([43c3174](https://github.com/ffalt/mah/commit/43c3174c41e1a4b40867f702542dc29375d96d68))
* **languages:** add RTL language support, update <html lang> ([09e8424](https://github.com/ffalt/mah/commit/09e8424d0395954206f18c67a7883be45c0b1d70))
* **settings:** add rotateBoard option ([b8f405a](https://github.com/ffalt/mah/commit/b8f405a71ca08e3da61fea1c5b2e6c4d164f6c72))
* **settings:** add zoomBoard option ([5396366](https://github.com/ffalt/mah/commit/5396366fbad9db1a9cf582015cf700807b652c46))
* **settings:** enable 3D tile setting by default ([98b0033](https://github.com/ffalt/mah/commit/98b00334db14cd54d7037641801ff942163406cc))
* **zen-mode:** add shortcut for the zen-mode ([2bf5b7e](https://github.com/ffalt/mah/commit/2bf5b7e8b17acbf36abb723f2f1defbd0ca48c60))

### Bug Fixes

* **app:** ensure splash screen is removed on startup failure ([d1b186c](https://github.com/ffalt/mah/commit/d1b186ca472426de350c3baf7298643262810351))
* **app:** remove unused Meta import from app.component.ts ([7d76232](https://github.com/ffalt/mah/commit/7d762325a0258246d69d2111c9333c66ca89ad19))
* **board:** add test for dropping gesture on new board ([0aded2e](https://github.com/ffalt/mah/commit/0aded2eaf32cc5909af58e23ddb20a5f3c1af750))
* **board:** cleanup wiggle timers ([7c812c0](https://github.com/ffalt/mah/commit/7c812c00b32417573faceb99e6a04a9d9ebd74ce))
* **board:** firefox does not properly repaint the blur on shadow layer, use tile blur instead ([0f0581a](https://github.com/ffalt/mah/commit/0f0581a9d09f5c7634a97768e0004102e0bc0143))
* **board:** focus css was not applied correctly ([78d79f6](https://github.com/ffalt/mah/commit/78d79f6d7d6e67314a9f6a86c81007adb3bd27a5))
* **board:** touch on the board can fire two separate tile-click ([4cfa38f](https://github.com/ffalt/mah/commit/4cfa38ff66f3220fe444e827c74f2dc32f549eee))
* **challenge:** allow disable/endable ([9c7893c](https://github.com/ffalt/mah/commit/9c7893c5ad3cd26f08a4b8c3211011247e4a831f))
* **confetti:** increase particle count ranges ([70d9f84](https://github.com/ffalt/mah/commit/70d9f846676c2eff05fb7f46871b1edd419fe2e4))
* **controls:** update role attribute for sound toggle button ([96e0682](https://github.com/ffalt/mah/commit/96e06826fc7f7d190b94dae06ebba865f42c8cc6))
* **css:** rework safe area padding on mobile devices (browsers vs native) ([f95b469](https://github.com/ffalt/mah/commit/f95b46988398c708aab668062981683d13697841))
* **defer-load:** leave no pending timers behind on destroy ([49cb679](https://github.com/ffalt/mah/commit/49cb679139674acc2bb1ea7f613382c4bfcdbf40))
* **editor:** add confirmation dialog before removing custom board ([a310cf3](https://github.com/ffalt/mah/commit/a310cf308d432cf3dfe7a1df98e6c00b8b167200))
* **editor:** alert and prevent saving if layout id matches built-in item ([15b97eb](https://github.com/ffalt/mah/commit/15b97eb231253999c49d4a03476bfc6b0890f0e8))
* **editor:** alert user when attempting to save a duplicate board ([2d6f32b](https://github.com/ffalt/mah/commit/2d6f32b0e8f1c0ebd0083d29935156c58c3d2a4b))
* **editor:** do not allow move a tile one cell past the board edge ([305b052](https://github.com/ffalt/mah/commit/305b052ea61d03079ab7898901e4452dfabf76c2))
* **editor:** new layer below was inserting the new layer above ([6576c8b](https://github.com/ffalt/mah/commit/6576c8b434e18db1733615b63e8de9e0faa069df))
* **editor:** no outer shortcuts while editor is open ([eefb91b](https://github.com/ffalt/mah/commit/eefb91be1200cb32cd051bd9f129bb26b497c8f8))
* **editor:** validate tile count for playable boards ([98c8f32](https://github.com/ffalt/mah/commit/98c8f326d2d3e8f237e038c6876fe8badc58ca54))
* **game:** click on backdrop permanently closes the shuffle prompt ([067262d](https://github.com/ffalt/mah/commit/067262d058a7d3dcadcdec730e5568cc48406a69))
* **game:** enforce minimum board tile count for game start ([6b9d4e5](https://github.com/ffalt/mah/commit/6b9d4e53dd9ed45d9af2791e5fcd05048ecd0919))
* **game:** handle rescue prompt and game state during shuffle in easy mode ([51cd58b](https://github.com/ffalt/mah/commit/51cd58bc2a3e9740e8784b7c68bd5e8023921c57))
* **game:** handle unplayable boards with appropriate messaging ([23be079](https://github.com/ffalt/mah/commit/23be079e786d7424e4cbfc26131f9802f974ae17))
* **game:** on request clear every stored record, also those from removed boards ([19748a7](https://github.com/ffalt/mah/commit/19748a7cf16f8bbfe508adba5b8d55f3891d0865))
* **game:** persist the rescue shuffle ([23ef2cc](https://github.com/ffalt/mah/commit/23ef2ccc0eb23cee3af12ffb33e80f9f5fa23009))
* **game:** prevent shuffle announcement if no message is present ([aa8f16e](https://github.com/ffalt/mah/commit/aa8f16edef03238d76374c3680340f8d6bf94493))
* **game:** space/p resumes an unplayable board ([0ff0a9c](https://github.com/ffalt/mah/commit/0ff0a9c390ef05c03ad406e16fc5f4a81040300c))
* **game:** undo and shuffle must auto-save ([45bc4c6](https://github.com/ffalt/mah/commit/45bc4c6508ba4686e6b1095e565b9cd0ba137f26))
* **game:** validate tile count for game start ([d4932a9](https://github.com/ffalt/mah/commit/d4932a9b48d6a58332c2aeb273535fd85596422d))
* **hash:** avoid negative hash values ([a74c416](https://github.com/ffalt/mah/commit/a74c4165e0b04a61e4d1c67ac16e740539fed91c))
* **help:** adjust max-height for help component table ([6c34de7](https://github.com/ffalt/mah/commit/6c34de7eebbde2a8b5e4466a72599ecc9b2fe6f5))
* **image-set-loader:** include extended tile IDs for placeholders ([053fd9b](https://github.com/ffalt/mah/commit/053fd9b15492b8b6419dc298509d9cdc1a0e727e))
* **import:** clear file input after importing files ([26ad6ac](https://github.com/ffalt/mah/commit/26ad6ac98475871c792272d1832040c0297632bb))
* **import:** ensure filename is retained when v1.1 header lacks a name ([ca1ab1c](https://github.com/ffalt/mah/commit/ca1ab1c56c9449d95eadf14000cf561aba91234f))
* **import:** update log messages to use translation ([55a2ad6](https://github.com/ffalt/mah/commit/55a2ad6c8c82b3ee386c6b039f644d892636080d))
* **keyboard:** do not allow space flickering on repeat events ([0bda360](https://github.com/ffalt/mah/commit/0bda360bfa38db93c76c1f5b0129db04e22743f9))
* **keyboard:** do not trap other keys then tab in dialog ([1562dfc](https://github.com/ffalt/mah/commit/1562dfc7708c87f55b99f4be69c43266341e6268))
* **keyboard:** move focus if tiles are removed with keyboard ([0ef6ed0](https://github.com/ffalt/mah/commit/0ef6ed0dcbec82ce47b38005cfe39cb9b1f301f3))
* **keyboard:** rework tab navigation, introduce arrow navigation where possible and adjust focus stlyings ([e221374](https://github.com/ffalt/mah/commit/e22137469d937bca3c14992aa2d0f36b6d004ecf))
* **lang:** save settings after language change immediately ([60d5650](https://github.com/ffalt/mah/commit/60d5650ae4cb986efb2de1ba5d6e33c87de478e7))
* **languages:** add language aliases for Norwegian and Filipino ([e8c59f4](https://github.com/ffalt/mah/commit/e8c59f4b0176baf47bfe13b90ae4d3d29b4a887c))
* **layout-list:** improve custom layout removal ([4f4cfed](https://github.com/ffalt/mah/commit/4f4cfed16469ac106d00d102a7ae2d97ea2e7ca9))
* **layout:** handle boards that cannot be expanded ([f8f0a25](https://github.com/ffalt/mah/commit/f8f0a25e99c26413b71962334f52a9c2b2f3e25d))
* **layout:** improve category fallback logic for layouts ([1f1b33c](https://github.com/ffalt/mah/commit/1f1b33c268cd9c3426f503a58dc6999efb889443))
* **localstorage:** handle denied storage access ([55e441c](https://github.com/ffalt/mah/commit/55e441c008460cfec70ab42d7a4f3aa726683291))
* **mapping:** clamp out-of-range repeated-cell count in expandMapping ([2634f94](https://github.com/ffalt/mah/commit/2634f94a4ebd37dd54fefcafa7759d95ad50a8ce))
* **pan-zoom:** lifting one finger mid-pinch permanently disables panning ([05dd361](https://github.com/ffalt/mah/commit/05dd361ac2f50edcefe83b078a613ecd39bcabfb))
* **pan-zoom:** update transform during touch move ([f2fcaed](https://github.com/ffalt/mah/commit/f2fcaeda6655a4b4b448b072d8c43ebcdf5f036f))
* **pattern:** rapid switching could leave a stale background applied ([e76526f](https://github.com/ffalt/mah/commit/e76526f65e1500b0681b22f8f2a572b1cc01f770))
* **random-board:** ensure silblings placements cannot overlap ([66653a1](https://github.com/ffalt/mah/commit/66653a1f0c7607abef03c7a3160146eae32985e5))
* **reload:** reshow the "shuffle?" dialog after reloading ([49dd248](https://github.com/ffalt/mah/commit/49dd24845535580b3079380f5dfc0e3b2c96f19d))
* **seed-input:** generate layout only on real text changes ([ffcf8a5](https://github.com/ffalt/mah/commit/ffcf8a57cb369b8b16209b2121e73e7786f7c946))
* **settings:** add gameMode and buildMode to the store ([affe60f](https://github.com/ffalt/mah/commit/affe60fadd64bb4ce6b0fedb1e4ddd3ba87fce76))
* **styles:** daily challenge layout adjustments on smaller screens ([9258f7b](https://github.com/ffalt/mah/commit/9258f7b9f0608de9b49655fab522a39b4ec0db81))
* **tileinfo:** allow a kyodai tileset to be applied when an image is set ([29a578b](https://github.com/ffalt/mah/commit/29a578b34567139aa53bb1fc9658d6d3d24fdc45))
* **tilesets:** throw error for missing kyodai image url ([cd4e354](https://github.com/ffalt/mah/commit/cd4e3547f20702904a75821d4b406e1dce6a8050))
* **tilesets:** update image path for kyodai-extra asset ([2f7f348](https://github.com/ffalt/mah/commit/2f7f34833b71d59db0c91bb07e1c7dc25f508fb2))
* **translate:** update group translation handling in dynamic language change ([4d09ea1](https://github.com/ffalt/mah/commit/4d09ea1e22060fe304dee16518cdcd077d31cf45))
* **translations:** remove &shy; ([91c758a](https://github.com/ffalt/mah/commit/91c758ab085a8a1eb516f90669a29826ee572fed))
* **tutorial:** cleanup on close ([c8118f7](https://github.com/ffalt/mah/commit/c8118f799db73a019c5c7f4bd8bfa4b03f888165))
* **tutorial:** cleanup wiggle timers ([6b9c04c](https://github.com/ffalt/mah/commit/6b9c04cbfd58f75f0e10047fdafa17cadc62f697))

## [1.21.0](https://github.com/ffalt/mah/compare/v1.20.0...v1.21.0) (2026-08-09)

### Features

* **board:** add optional tile shadows (default: true) ([f67b31a](https://github.com/ffalt/mah/commit/f67b31a851c54d143cc22b6b86d872d299f1ef46))
* **core:** add app initializer for language preloading ([916e568](https://github.com/ffalt/mah/commit/916e5680d573b60d1e87d2af58c992e461fcba41))
* **editor:** better UI ([57d5bc9](https://github.com/ffalt/mah/commit/57d5bc98ffd958830650eee86ec1169f6f086b1d))
* **game:** show a start game screen when no game or dialog is active ([b83b122](https://github.com/ffalt/mah/commit/b83b1220255df58e95abfe18083b54e133969b36))
* **style:** cherrypick some design improvements ([ff3482c](https://github.com/ffalt/mah/commit/ff3482c44ce5fe1d2f6be3ce831ed48a68bab5fd))

### Bug Fixes

* **board:** do not requests a nonexistent image ([7fc54eb](https://github.com/ffalt/mah/commit/7fc54eb92f36ffcdede199b32f1b22640a6fd7be))
* **dialogs:** make sure every dialog pauses the game ([849fc10](https://github.com/ffalt/mah/commit/849fc104afb51cdc287d8b724bc55946f2427631))
* **drawing:** with 3D sides, some times on the same level were overlapping ([2cd7ee5](https://github.com/ffalt/mah/commit/2cd7ee56788ef85782908e82513bfc38690ae4e7))
* **editor:** viewing a different layer marks the layout as modified ([f424c35](https://github.com/ffalt/mah/commit/f424c3506748d6797092a115842e6170b666e5ca))
* **export:** exporting a layout leaks an object URL ([0e8db36](https://github.com/ffalt/mah/commit/0e8db360aac4ab69bd3ea398f51e60fed7e35e29))
* **game:** add guard to pause() ([f5212b1](https://github.com/ffalt/mah/commit/f5212b1045bd332f4064d23e4654f379e364348a))
* **game:** do not continue an empty board ([8612d3f](https://github.com/ffalt/mah/commit/8612d3fe78493a382dd25911f9163e48065ab3fe))
* **game:** give up after 20 failed shuffle attempts and end the game ([f2031ff](https://github.com/ffalt/mah/commit/f2031ffff6065c1dde56955a9ddee22e952e7c44))
* **gesture indicators:** look up indicator by identity ([745dff9](https://github.com/ffalt/mah/commit/745dff937daeebf9c543ad1e442c8144262cdd22))
* **gesture:** window resize discards the player's pan and zoom ([c6f121f](https://github.com/ffalt/mah/commit/c6f121fc06b27db36dac2b070ac359b0177f04c5))
* **I18n:** add missing group translations ([7ee599f](https://github.com/ffalt/mah/commit/7ee599f82bc265ad4bcd0a15eafd96812ea726fb))
* **I18n:** change labels random cat on language change ([9267f96](https://github.com/ffalt/mah/commit/9267f967e3c4b461de8993ad41b93b36230a57e3))
* **i18n:** validate spellings ([950b4d3](https://github.com/ffalt/mah/commit/950b4d3b99e4084ae35768f87679338a442e6217))
* **image-placeholder:** ensure unique ids ([fabe2f8](https://github.com/ffalt/mah/commit/fabe2f83ac7e6af3120025acf9567de72fe78ecb))
* **import:** file reading and decoding with UTF-8 ([472d4b3](https://github.com/ffalt/mah/commit/472d4b394f03ff0f4397a63201017b5f7ce000f4))
* **import:** kmahjongg layout handling for version 1.1 ([ce88d09](https://github.com/ffalt/mah/commit/ce88d09eda3b06ba8faddb9bce0aee46aa88d7a1))
* **import:** Shared-import links mangle non-ASCII board names ([220195e](https://github.com/ffalt/mah/commit/220195e6d2a91a6aa1f31ec94378f4c3f0108caf))
* **keyboard:** focused buttons should not eat up unreleated shortcuts ([5e4ab44](https://github.com/ffalt/mah/commit/5e4ab44d5be9ee74b0fabf7a8ed935af94c642ff))
* **keys:** disable key shortcuts if dialogs are open ([a9e9109](https://github.com/ffalt/mah/commit/a9e9109f7dacb8fc5b5c7dcb9d3a84886f4be61c))
* **kmahjongg:** export/import the correct header ([0e41c0b](https://github.com/ffalt/mah/commit/0e41c0b8591598a6c040bb19a72b53757a172113))
* **kyodai:** add URL escaping and parameter handling in SVG generation ([cff86a0](https://github.com/ffalt/mah/commit/cff86a0eddb896c7fcb83e9ee5107ebb34e4b943))
* **localstorage:** ensure newer prefixed entry is retained and old one is removed ([82bc519](https://github.com/ffalt/mah/commit/82bc519b0989f7d91182207a6031d3296f1147fe))
* **random-layout:** final fill place could not place anything ([b3f5145](https://github.com/ffalt/mah/commit/b3f5145716dd5a69024a06519a51ef4b9e8e370a))
* **random-layout:** prevent checker removing edges ([5a72a59](https://github.com/ffalt/mah/commit/5a72a59a598fa5f373796511bbac097c237d9109))
* **random-layout:** prevent div by zero in diamond shape ([dfc57e2](https://github.com/ffalt/mah/commit/dfc57e208787adf1f8ccdfb0719cb64e68dbfcb5))
* **scss:** adjust broken css variable ([546548e](https://github.com/ffalt/mah/commit/546548e3410b14de46811858a7b29f9afbbe869a))
* **style:** button padding on small screens ([cdf2b63](https://github.com/ffalt/mah/commit/cdf2b6304b62355552829839aa6eb4b0580a9c1f))
* **tiles:** ensure tile IDs are drawable and reuse groups correctly ([45b347b](https://github.com/ffalt/mah/commit/45b347ba4777bb375c17e768bcde2ebcb168ee73))
* **tutorial:** prevent advance past last step ([3606705](https://github.com/ffalt/mah/commit/3606705aa3930692a1d311baed2b0af8d0b049b4))
* **zen-control:** on mobile ony one dragging must be followed ([8f7659a](https://github.com/ffalt/mah/commit/8f7659a99a828976b6bb1922747ba3543aa630bb))

## [1.20.0](https://github.com/ffalt/mah/compare/v1.19.3...v1.20.0) (2026-07-10)

### Features

* **performance:** enhance rendering and loading ([daf17dd](https://github.com/ffalt/mah/commit/daf17ddba1e4800685047b8165f03c9872e9960b))
* **performance:** remove zone.js ([b5d9a6f](https://github.com/ffalt/mah/commit/b5d9a6f58d2fe45095b1ddd42e6374889a6499a7))

### Bug Fixes

* **base-layer-checker:** adjust gap creation logic for larger block removals ([ba20795](https://github.com/ffalt/mah/commit/ba20795e0cdd8076bada3e80d6b8346abfeea367))
* **board:** detach mousemove listener on tile tap while zoomed ([5fc863d](https://github.com/ffalt/mah/commit/5fc863da9c5a70160349b476b8a04a789ddeaf26))
* **board:** remove duplicate click event om empty area ([8017dcc](https://github.com/ffalt/mah/commit/8017dcc3af855892eb582bf25516d6c42778dc68))
* **game:** savE immediately after game over (not delayed) ([595ce49](https://github.com/ffalt/mah/commit/595ce4952066586134381c7d24ce236ca910168d))
* **http-cache:** ensure data check is strict for cached items ([362419f](https://github.com/ffalt/mah/commit/362419fd0bafe462cf7a8158aa900ddcb8eb3704))
* **indicator:** check if indicator actually exists ([1bf17b1](https://github.com/ffalt/mah/commit/1bf17b1f6298834f6b0f506d9978083c00b2e993))
* **layout:** handle failed requests without caching as loaded ([41c43cf](https://github.com/ffalt/mah/commit/41c43cfc60401aa5f939ce7050241e4f926bf329))
* **pattern:** add space for safe concatenation ([31e559a](https://github.com/ffalt/mah/commit/31e559af9ee8a4d57d2f47da1ecf3a7a41a52c83))
* **pattern:** limit color counts to maximum allowed in SVG generation ([f45b515](https://github.com/ffalt/mah/commit/f45b515c567e4136eddacd4110f2038d06e98502))
* **random builder:** ensure even tile placement for matchable stones ([af1b6aa](https://github.com/ffalt/mah/commit/af1b6aa87fbb3291c7f090a5099e49c05e2b09e4))
* **settings:** validate stored theme setting ([4eb9259](https://github.com/ffalt/mah/commit/4eb925935f99e860df107c6cbc3c0162baaa70ec))
* **solver:** reset tileList before solving layout ([8c6a49d](https://github.com/ffalt/mah/commit/8c6a49d6932dfeb902fa37e75db1cf4a4e8a1cc6))
* **svg:** correct viewBox size calculation for stacked tile layouts ([88fbab8](https://github.com/ffalt/mah/commit/88fbab8f3b25b57c1ed5a068fb16ba19b9de082a))
* **theme:** set default theme color to ltgreen ([43218b7](https://github.com/ffalt/mah/commit/43218b717eba1cea6767424988ea16fd14fed5aa))
* **worker:** fallback to synchronous execution if workers are not supported ([b93e98c](https://github.com/ffalt/mah/commit/b93e98cd759cf882d801e4adfb4c1abca83aab16))
* **worker:** handle invalid mapping input in solve method ([67ef9b7](https://github.com/ffalt/mah/commit/67ef9b746c3cfa0a6085acbdf4204bf6fee82f67))
* **zen-controls:** adjust button text colors ([14d847f](https://github.com/ffalt/mah/commit/14d847f6f29cf6e9a82471d85fcb01e59d9adfcd))

## [1.19.3](https://github.com/ffalt/mah/compare/v1.19.2...v1.19.3) (2026-06-02)

### Bug Fixes

* **style:** overlay message element shows focus ring on tab navigation only ([45e2d2a](https://github.com/ffalt/mah/commit/45e2d2a62c9dd6263e973fb0ce48bd438c0069c8))

## [1.19.2](https://github.com/ffalt/mah/compare/v1.19.0...v1.19.2) (2026-06-02)

### Features

* **accessibility:** add hidden page title for screen readers ([3e5f3a5](https://github.com/ffalt/mah/commit/3e5f3a558392082e613d2f5d962f4c41e7f91b1e))
* **i18n:** add missing translations ([fcb1adb](https://github.com/ffalt/mah/commit/fcb1adbbf4212abff323f14961c199a159ffc79b))

### Bug Fixes

* **style:** remove focus ring from overlay message element ([df3922e](https://github.com/ffalt/mah/commit/df3922e3c3459b03482fb0b1bcdf651af17d9a7f))

## [1.19.1](https://github.com/ffalt/mah/compare/v1.19.0...v1.19.1) (2026-06-01)

### Features

* **i18n:** add missing translations ([9912bd2](https://github.com/ffalt/mah/commit/9912bd29109e75c218d2d49f545df2a374353508))

## [1.19.0](https://github.com/ffalt/mah/compare/v1.18.3...v1.19.0) (2026-05-24)

### Features

* **accessibility:** improve keyboard navigation, ARIA roles, accessibility announcements, and focus styles across components ([241d63a](https://github.com/ffalt/mah/commit/241d63af022185517e874d9564f5c11162b5020e))
* **game:** add "show matching tiles" feature for easy mode ([fc27e64](https://github.com/ffalt/mah/commit/fc27e647e8df8b38a4c41c2b3c965ba6f7945e2a))
* **game:** add optional confetti effect on game victory ([98b2bab](https://github.com/ffalt/mah/commit/98b2bab95c6f20d7dccc9ba6d270e032506ce2bd))
* **game:** zen mode for distraction-free gameplay ([2b4cc39](https://github.com/ffalt/mah/commit/2b4cc3999635bcc9d1a183d25a80f86b516ae825))
* **hint:** rework hints animation ([8807022](https://github.com/ffalt/mah/commit/880702228e3814cb5c8d642c93629cf8375fa924))
* **icons:** replace legacy font-based icons with svg components ([9596c6d](https://github.com/ffalt/mah/commit/9596c6d61fbc7a57827c7ac307a30fd69d5ea671))
* **import:** add validation for imported .mah files and file size limit ([390bd00](https://github.com/ffalt/mah/commit/390bd00c66f2e255a744c11122678ec1bb85d343))
* **layout-seed:** add seed-based layout generation and support for user-defined seeds ([ac35bc1](https://github.com/ffalt/mah/commit/ac35bc1239fba0ad9c741b82adfbed30433f681d))
* **random:** add more shapes to the random layout generator ([976862e](https://github.com/ffalt/mah/commit/976862e6061a4bb85b87609c35679046b81b4e8a))
* **selects:** Remove very long select items, add info overlay for better descriptions ([5215234](https://github.com/ffalt/mah/commit/52152347079ae49cae0d2c544ac8cd16c79f848a))
* **settings:** add "show game timer" option ([c7fec8c](https://github.com/ffalt/mah/commit/c7fec8ce98b15f987a2bba59618955a3fde26d69))
* **versioning:** use mjs custom updaters for Cargo.toml and Dockerfile ([5f37ee8](https://github.com/ffalt/mah/commit/5f37ee857046aa0e60c935fcbd709f629337392c))

### Bug Fixes

* **builder:** add retry mechanism to ensure valid random board generation ([43b8b14](https://github.com/ffalt/mah/commit/43b8b147f41a4978dcb2251c123bec7dfcaecc52))
* **i18n:** refine translation for solvable mode descriptions ([94c7b31](https://github.com/ffalt/mah/commit/94c7b3103763b7848575f3ba7719cf97610a5862))
* **i18n:** update translations for tile-related terms ([b13a4b6](https://github.com/ffalt/mah/commit/b13a4b62399458946334ccbe476c19158e6903dd))
* **image-set-loader:** sanitize prefix for SVG id attributes ([e4884a7](https://github.com/ffalt/mah/commit/e4884a7a18bd617b1a109b754a2832a9d8486823))
* **tiles-info:** use interpolation instead of innerHTML for translated tile text ([04b5050](https://github.com/ffalt/mah/commit/04b5050329dd8f7637301956bc817abe5d20992b))

## [1.18.3](https://github.com/ffalt/mah/compare/v1.18.2...v1.18.3) (2026-03-16)

### Bug Fixes

* **languages:** rename Japanese language key from 'jp' to 'ja' ([ab90116](https://github.com/ffalt/mah/commit/ab9011671d839f4f39bf5c538053d3c139563617))

## [1.18.2](https://github.com/ffalt/mah/compare/v1.18.1...v1.18.2) (2026-03-15)

### Features

* **settings:** add TilePreviewComponent for enhanced tile settings visualization ([408acb5](https://github.com/ffalt/mah/commit/408acb5b521a7e5b1db0787f156bf1b01d6c90b8))
* **stats:** store win/lose stats and display in help dialog ([5b79319](https://github.com/ffalt/mah/commit/5b793192f9bff8aaaa22d7dc6a2ff4e53147e0b8))
* **tiles:** introduce TilesetDefsComponent for shared SVG definitions and update tile component to utilize shared prefix ([55c3439](https://github.com/ffalt/mah/commit/55c34393e3199ddd62f45ed516cab4b1e1f5db93))

### Bug Fixes

* **help:** change lifecycle hook from ngAfterViewInit to ngOnInit for statsGroups initialization ([e9d23b6](https://github.com/ffalt/mah/commit/e9d23b6bcc1793cbc7e37bcd5ddd5483eb932eeb))
* **i18n:** update READ_MORE_WIKIPEDIA_URL for multiple languages to point to the correct Mahjong tiles page ([08f686c](https://github.com/ffalt/mah/commit/08f686c9eef05817a720184f8463ac95c607990b))
* **image-set-loader:** update spinner position based on image set type ([4f56f28](https://github.com/ffalt/mah/commit/4f56f28b6b12db7daad5ed11fd53201458b58f72))
* **settings:** checkboxes on small screens ([d6edf5e](https://github.com/ffalt/mah/commit/d6edf5efe813ab9b5b3ab56bcfd781270526b40a))
* **settings:** update language radios responsive mixin breakpoint from small-down to tiny-down ([ef663d8](https://github.com/ffalt/mah/commit/ef663d854c57999e69c18e2a9caeffbde95b323c))
* **svg:** refactor svg_spinner_icon to a function for dynamic color ([68fc030](https://github.com/ffalt/mah/commit/68fc0309d688ac9beef426774d2417105f2b1521))

## [1.18.1](https://github.com/ffalt/mah/compare/v1.18.0...v1.18.1) (2026-03-14)

### Features

* add game modes section to help component and enhance shortcut display ([f86e75c](https://github.com/ffalt/mah/commit/f86e75c44c4033efee076775be75d3459f980c5e))
* add statistics display to help component ([501fe1c](https://github.com/ffalt/mah/commit/501fe1c1076a3da87def3177cca0ec87c7ea8e2b))
* add statistics display to help component ([7bc91f5](https://github.com/ffalt/mah/commit/7bc91f56efbaa4624118b1431b477334f9b6ba46))
* add statistics display to help component ([8408ef2](https://github.com/ffalt/mah/commit/8408ef2d63a64481508e9bf17a0783de65b41450))
* enhance help component with game modes and external link support ([2259ef4](https://github.com/ffalt/mah/commit/2259ef44946d77e53956439b01360dae8386b90c))

### Bug Fixes

* **board:** hint border for 3D tiles not visible ([6dd954e](https://github.com/ffalt/mah/commit/6dd954e7e539f651ac01cd2242a13d8a4a0d9bb9))
* **help:** update feature tag styling and adjust layout direction ([997ebbc](https://github.com/ffalt/mah/commit/997ebbc9cce74eeda0c6e29791f07cb248f7d9c2))
* **layout:** adjust control game direction to column-reverse ([5d18cb1](https://github.com/ffalt/mah/commit/5d18cb1727b4b97ff732f9198d4c6625a6d61568))
* **layout:** horizontal - adjust board margins and control font size ([bf4f228](https://github.com/ffalt/mah/commit/bf4f228f98ca8f3269e3c9aba43f201c726d0129))
* **layout:** update expand/collapse icons to use SVG masks ([39bc4b7](https://github.com/ffalt/mah/commit/39bc4b762463bf55ec1cda75bd723cf49cf2bb93))
* refactor overlay styles and update dialog sizing logic ([4197440](https://github.com/ffalt/mah/commit/4197440bfb2daa381035b3e574f372e60dddaeb7))
* remove duplicate tutorial welcome benefits in bn.json ([fb30745](https://github.com/ffalt/mah/commit/fb307457b854d2cf5b14d2aa256fb18a185517ce))

## [1.18.0](https://github.com/ffalt/mah/compare/v1.17.0...v1.18.0) (2026-03-13)

### Features

* **solvable board generation:** enhance with retries and alternative strategies ([9d70190](https://github.com/ffalt/mah/commit/9d70190966cd8b17616ce25312fc795536d985ac))
* **tiles:** add an optional 3D effect to tiles ([be7cee0](https://github.com/ffalt/mah/commit/be7cee01507e3ebe85b3dd5b7cea51a7eae612b7))

### Bug Fixes

* add boundary checks in isTilePosBlocked method to prevent index errors ([f06f217](https://github.com/ffalt/mah/commit/f06f21734bdb7d319df86628e255876f386fac31))
* add defensive checks to random tile and place extraction in stone generation ([9a68655](https://github.com/ffalt/mah/commit/9a68655bef7a63a4401f9c89f089b51b6f619e23))
* add error logging for null or undefined mapping in board loading ([4ad0573](https://github.com/ffalt/mah/commit/4ad0573b8cad34d635c673f4971cc24b2aced4b9))
* add loading state management for editor visibility toggle ([7829fd4](https://github.com/ffalt/mah/commit/7829fd4d14cbeae3b132ec461f7341d4aa139efb))
* add null check for event target in handleKeyDownEvent method ([9988bc6](https://github.com/ffalt/mah/commit/9988bc6544d8398a1389fb2637f8a62708460ee8))
* add reset functionality to game component and mock board for testing ([267aac3](https://github.com/ffalt/mah/commit/267aac37916a8c017219a70e666076c2e06b7bd3))
* enhance fullscreen handling with improved error logging and vendor support ([549c2fe](https://github.com/ffalt/mah/commit/549c2fecddf34273a471f6404df437c212b7ac21))
* enhance import functionality with improved error handling and validation ([78159a6](https://github.com/ffalt/mah/commit/78159a612e885f3256a7e59fe9fbb963e8e703d3))
* enhance inBounds method to improve boundary checks for matrix levels ([a8da463](https://github.com/ffalt/mah/commit/a8da463f1a1ade22a6f015e6df638b95d6e208aa))
* enhance layout and matrix components with improved boundary checks and error handling ([8b18a8f](https://github.com/ffalt/mah/commit/8b18a8f6592d4fbe8d56a110e586726fb40d3c81))
* enhance layout and matrix components with improved boundary checks and error handling ([8e7cc1e](https://github.com/ffalt/mah/commit/8e7cc1ec6b074e40f427feebc15e7ca84a48f771))
* enhance localStorage handling with availability checks and improved error logging ([5a663d8](https://github.com/ffalt/mah/commit/5a663d870a852a2fe03d9c0d3ac53a11229adfef))
* enhance localStorage handling with availability checks and improved error logging ([d6b2283](https://github.com/ffalt/mah/commit/d6b22838a5879c0880108af15231deb962a600d3))
* enhance localStorage handling with availability checks and improved error logging ([337f18b](https://github.com/ffalt/mah/commit/337f18b329835b02c96cbd122072d963e77f1d10))
* enhance PatternService to manage caching and HTTP requests with error handling ([2a2d372](https://github.com/ffalt/mah/commit/2a2d372ef2c8c71abe27bff509fb72a0eb22b73b))
* ensure clearSaveTimer is called in pause, reset, and delayedSave methods ([f41e5d0](https://github.com/ffalt/mah/commit/f41e5d0c9354e98f5535dc1330834d717c28fd31))
* ensure clearSaveTimer is called in pause, reset, and delayedSave methods ([4c80ac7](https://github.com/ffalt/mah/commit/4c80ac78a3aace48b33d19edec9c8759089c0ab5))
* handle corrupted localStorage data gracefully by removing invalid entries ([206af2c](https://github.com/ffalt/mah/commit/206af2cc04a37b6b4079435cdc1b31ca7dfdb2a5))
* handle edge case for improperly sized container in pan calculations ([cc08e73](https://github.com/ffalt/mah/commit/cc08e7353f3c622fd75cba55ee97dfb651e2fc39))
* handle HTTP errors gracefully in board loading with fallback to custom layouts ([da7bc97](https://github.com/ffalt/mah/commit/da7bc974230c7b0ac325703d0cdd81283874c607))
* implement stuck counter and random direction fallback for snake movement ([db188ce](https://github.com/ffalt/mah/commit/db188ced8ecb932da03270a987121eb8771d78c1))
* improve caching and request handling in svgdef service to prevent race conditions and handle errors ([96b0be7](https://github.com/ffalt/mah/commit/96b0be7855e447d9b1cf5d904498c339f332e333))
* improve caching and request handling in svgdef service to prevent race conditions and handle errors ([ccc5567](https://github.com/ffalt/mah/commit/ccc55671eb73929b50202981c0618d4eea404e81))
* improve event target handling for keydown events in game and app components ([2074151](https://github.com/ffalt/mah/commit/20741516bc2c2d9022f632a177f4b98fada5d8f9))
* improve indicator hide and removal timing with cancellation of pending timers ([f9b6d2e](https://github.com/ffalt/mah/commit/f9b6d2ec66ece326be717c1d5a6c4d8e378f92a0))
* improve stone grouping logic to handle empty groups and ensure proper group number assignment ([a98d253](https://github.com/ffalt/mah/commit/a98d2534fb8b2f33f7250736458baf7f518deb40))
* improve wiggle effect handling by clearing existing timer in stone effects ([d8c8a15](https://github.com/ffalt/mah/commit/d8c8a15e0cde5f90f3cb0160245231c12fa83baa))
* prevent division by zero in pinch gesture scaling calculation ([bea3569](https://github.com/ffalt/mah/commit/bea35698b7e8b03f2ec2a1723346cfefd64fc8d6))
* prevent layout calculations from failing with non-positive container dimensions ([c76c9bc](https://github.com/ffalt/mah/commit/c76c9bc33790ff005890967a375e9cc998df2680))
* prevent random game selection from failing on empty layout items ([2bf296f](https://github.com/ffalt/mah/commit/2bf296fb8c70d7e956a308319398d2c7af998873))
* refactor color selection logic in multiStroke function for improved clarity ([b02b077](https://github.com/ffalt/mah/commit/b02b0779685e71253a0b67e2a3d35af7eeed47a9))
* rename dev-server to development-server and update related schema references ([2ee478e](https://github.com/ffalt/mah/commit/2ee478eb9ba47144ead410d8aa04996f09217eef))
* return undefined instead of implicit undefined in stone function ([1d62b9e](https://github.com/ffalt/mah/commit/1d62b9ed74f3282ecfa9e13e044410c84c4585a7))
* streamline SVG fetching in svgdef service by removing unnecessary timeout and improving error handling ([6be9d0f](https://github.com/ffalt/mah/commit/6be9d0f6fe82fb72a76738957c1fa56ffdaaa82c))
* update Angular and related dependencies to latest versions ([16af1be](https://github.com/ffalt/mah/commit/16af1be07471ad77f57df48a7727faa45e469a5c))
* update application name retrieval to use environment variable ([a2fadb5](https://github.com/ffalt/mah/commit/a2fadb5eac37869355a363a0fe77f0bd6581b4e4))
* update board ID selection logic to prioritize URL parameter over layout IDs ([4ade441](https://github.com/ffalt/mah/commit/4ade441f9a3af32d0907a8337691289ac2d1ec76))
* update checkbox selection logic in settings component tests ([978fb2d](https://github.com/ffalt/mah/commit/978fb2daac5362e5348640bf63138b34eef99a4e))
* update dependencies to latest versions in Cargo.lock and package.json [skip ci] ([43a8a0b](https://github.com/ffalt/mah/commit/43a8a0b0428160042097447412bbb532097c74b8))
* update return value in builder method to ensure consistent undefined return ([e8cc021](https://github.com/ffalt/mah/commit/e8cc021decdf775a8b6cb98dafda72f8f47f7b7d))
* update timer handling in Clock class to remove window reference ([7cfa2c6](https://github.com/ffalt/mah/commit/7cfa2c695715ee9be5666b4cb830c61117fa9cfc))
* update type definitions for randChoice and directions to use NonEmptyArray ([190c328](https://github.com/ffalt/mah/commit/190c32845111a922425ceb60bcf19fdca16e8523))
* use optional chaining and nullish coalescing for safer image assignment ([6b6e537](https://github.com/ffalt/mah/commit/6b6e5378ccdffb90fc1ede94b8b0c24e1c3206c6))
* validate suffix structure and types in pattern generation ([6f68a5e](https://github.com/ffalt/mah/commit/6f68a5e441696c4ccc4630bf918bf5dc71572d9e))

## [1.17.0](https://github.com/ffalt/mah/compare/v1.16.1...v1.17.0) (2026-02-21)

### Features

* **app:** add a starter tutorial ([b60e256](https://github.com/ffalt/mah/commit/b60e256937e042fe8dc20cbb3a8750b90b8a31a9))
* **languages:** add Malay, Filipino, Tamil, Swahili, Telugu, Thai, Bengali, Persian, Indonesian, Urdu, Swedish, Romanian, Turkish, Ukrainian, Vietnamese, Catalan, Czech, Danish, Finnish, Norwegian, Hindi, Greek, Arabic, Italian, Polish, Korean and Hungarian translations from Crowdin

## [1.16.1](https://github.com/ffalt/mah/compare/v1.16.0...v1.16.1) (2025-12-27)

### Bug Fixes

* **apps:** pause when the app is not focused ([7f01bcb](https://github.com/ffalt/mah/commit/7f01bcb065fdbca58899701056ed637dc020cf78))

## [1.16.0](https://github.com/ffalt/mah/compare/v1.15.1...v1.16.0) (2025-12-18)

### Features

* **board:** shuffle uses the remaining stones and does not create a new board ([d5e9a91](https://github.com/ffalt/mah/commit/d5e9a9144857318d58b7dc5439aaaa07241448dd))
* **sounds:** remove binary sounds, use ZzFX for sound generation, adjust jest mocks ([fbeaaac](https://github.com/ffalt/mah/commit/fbeaaac0b5096e89810a9471e3933af95932e0bf))

## [1.15.1](https://github.com/ffalt/mah/compare/v1.15.0...v1.15.1) (2025-12-14)

### Bug Fixes

* **pattern:** fix markdown link and formatting ([53f7b86](https://github.com/ffalt/mah/commit/53f7b86e27be428af65dfb6ebf45ad61687e389e))

## [1.15.0](https://github.com/ffalt/mah/compare/v1.14.1...v1.15.0) (2025-12-14)

### Features

* **background:** refresh images and add starry sky image ([68c492f](https://github.com/ffalt/mah/commit/68c492f5fb25b708fe657e6bc2ba2f89c3956945))
* **backgrounds:** use patterns from pattern monster ([f6b0d8f](https://github.com/ffalt/mah/commit/f6b0d8f610c03ba2308bab6c72ddfc5cf0235023))

## [1.14.1](https://github.com/ffalt/mah/compare/v1.14.0...v1.14.1) (2025-12-05)

### Bug Fixes

* **buttons:** hide feature buttons not enabled in game difficulty level ([0f72693](https://github.com/ffalt/mah/commit/0f7269389fcc7bc89cb79a29f4fd31a10b477533))

## [1.14.0](https://github.com/ffalt/mah/compare/v1.13.0...v1.14.0) (2025-12-05)

### Features

* **categories:** provide translations for layout cats ([7df1f62](https://github.com/ffalt/mah/commit/7df1f62e1ac089b5fea612b15b612e9e716e5a9a))
* **gameplay:** easy mode allows shuffle after no more moves ([a212697](https://github.com/ffalt/mah/commit/a212697e8b00cb376a8ae1d0438a2daf87f3253f))
* **game:** rework buttons ([9329b0a](https://github.com/ffalt/mah/commit/9329b0a46c931546e07b85161c390522023c87b3))
* **overlays:** rework buttons and selects ([f48d227](https://github.com/ffalt/mah/commit/f48d227d803c66393b9655af6d879a5380c1c089))
* **settings:** use tabs on medium to large screens ([191dfc4](https://github.com/ffalt/mah/commit/191dfc43d67d9a8971081957c4e2dd1cd60de1dd))
* **themes:** add color preview to settings options ([b750e28](https://github.com/ffalt/mah/commit/b750e28d263ef569f69dbff17a5a0d6990ff66bf))
* **themes:** rename color themes and add 7 more ([97bf28e](https://github.com/ffalt/mah/commit/97bf28ef34d1856ee8eec47463ac53654f37ca4f))

### Bug Fixes

* **gameplay:** easy mode allows shuffle after no more moves (but only if there are at least 2 free stones) ([1025161](https://github.com/ffalt/mah/commit/10251615c957ece30a335e186ec07f28066eb9be))
* **layout-chooser:** remove duplicate dom id ([ed2e46c](https://github.com/ffalt/mah/commit/ed2e46c6288424fbc8be618cfc2720398dc8c9f9))

## [1.13.0](https://github.com/ffalt/mah/compare/v1.12.1...v1.13.0) (2025-11-21)

### Features

* **layouts:** add layout categories; add new layouts to fill up categories ([a66d826](https://github.com/ffalt/mah/commit/a66d826ca42ff27f7976d4aee3bb2e3db6d8117f))

### Bug Fixes

* **css:** better component layout on small screens ([85fe6cd](https://github.com/ffalt/mah/commit/85fe6cd10610ad9736b71f1401f359338f5df313))
* **dark theme:** solve contrast issue on background hover ([57ebaa4](https://github.com/ffalt/mah/commit/57ebaa4d0ceb3198de18f869e23c4700dfd39c7a))
* **editor:** on saving, compact & expand to restore sorting for ID ([ece6372](https://github.com/ffalt/mah/commit/ece6372b38922841961b97ded49bfe5994ebb663))
* **layout-list:** better row layouting with css grid ([21841cb](https://github.com/ffalt/mah/commit/21841cbb7159cc50644f7b214ab38bb18a8a4a05))
* **layout-list:** use grid for anchors if available ([e589a50](https://github.com/ffalt/mah/commit/e589a5083a54f871025432d5c0f3832e1eee4923))
* **settings-dialog:** ensure background [none] is marked as selected ([030c7dd](https://github.com/ffalt/mah/commit/030c7ddd24910cc9f6689f08aed18ca5bb98d7f3))
* **settings-dialog:** gap on single column layout ([be8b573](https://github.com/ffalt/mah/commit/be8b573e104c2536db65c82712324224298e31e2))
* **settings-dialog:** more spacing; fix form structure ([d4b6127](https://github.com/ffalt/mah/commit/d4b61277aa8d5b7198cb6a543e8692372dc84efd))

## [1.12.1](https://github.com/ffalt/mah/compare/v1.12.0...v1.12.1) (2025-11-15)

### Bug Fixes

* **apps:** open external links in the default browser ([223bf25](https://github.com/ffalt/mah/commit/223bf25f3fe0be830b9985fe0698806f60b1e5cc))
* **board:** better viewport calculations ([f53e64a](https://github.com/ffalt/mah/commit/f53e64a826efb2e26fee3e87319e1a6776d2aa26))
* **hint-dialog:** icon colors on light theme ([8f7fde9](https://github.com/ffalt/mah/commit/8f7fde91730152d1b3c24dc4dc1e1f7c11a6665b))
* **new-game-dialog:** hide anchor-links on horizontal phones ([a9d83b0](https://github.com/ffalt/mah/commit/a9d83b02afa085e3bd3b236bf6f12981debbfc02))

## [1.12.0](https://github.com/ffalt/mah/compare/v1.11.0...v1.12.0) (2025-11-15)

### Features

* **languages:** add chinese ([325f95c](https://github.com/ffalt/mah/commit/325f95cf0b48bc76873a1d6fa666bdf1d2bacb24))
* **tiles-info:** allow setting the tileset in the tilesinfo-dialog ([3090f8e](https://github.com/ffalt/mah/commit/3090f8e994e29b4a33f571d5f3340ae9fe10da21))

### Bug Fixes

* **android:** remove internet permission [skip ci] ([4544c36](https://github.com/ffalt/mah/commit/4544c36d7a696249819ed51203cb66864aab713a))

## [1.11.0](https://github.com/ffalt/mah/compare/v1.10.0...v1.11.0) (2025-11-12)

### Features

* **svg:** add birds svgs ([3d20de7](https://github.com/ffalt/mah/commit/3d20de7c99961ebb389176da8ffb3ba29946a180))

### Bug Fixes

* **settings:** adjust hover color in light theme ([b94ba96](https://github.com/ffalt/mah/commit/b94ba96ed4eeebf8bb5963c80b8594640ddc457e))

## [1.10.0](https://github.com/ffalt/mah/compare/v1.9.0...v1.10.0) (2025-11-09)

### Features

* **svg:** add space svgs ([69ed442](https://github.com/ffalt/mah/commit/69ed442ea11e6ec538071929d98ad9b1cfd89dc5))
* **svg:** cleanup, remove low-resolution sets and support low-performance devices ([e78e981](https://github.com/ffalt/mah/commit/e78e9817f64bcfcf8ec07717c2c58a5df18ffe0a))

### Bug Fixes

* **mobile:** don't show pinch indicator on touch start ([494b7ab](https://github.com/ffalt/mah/commit/494b7ab45b072796cbb752bbee6a7e22d528fbb0))

## [1.9.0](https://github.com/ffalt/mah/compare/v1.8.2...v1.9.0) (2025-10-29)

### Features

* **mobile** support safe-area-padding

## [1.8.2](https://github.com/ffalt/mah/compare/v1.8.1...v1.8.2) (2025-09-29)

### Bug Fixes

* **board:** if zoomed, avoid unselecting stone on panning ([c45bdff](https://github.com/ffalt/mah/commit/c45bdff4a9189211d4c76161dc0b2b490f7af0a7))

## [1.8.1](https://github.com/ffalt/mah/compare/v1.8.0...v1.8.1) (2025-09-28)

### Bug Fixes

* **board:** proper reset of panning state ([5b7f23c](https://github.com/ffalt/mah/commit/5b7f23c33452370cff161464d9ba7633b314441a))

## [1.8.0](https://github.com/ffalt/mah/compare/v1.7.7...v1.8.0) (2025-09-28)

### Features

* **images:** add webp variants ([69848c6](https://github.com/ffalt/mah/commit/69848c60d749d374ac26868f3e34dfe1e56457bf))
* **imageset:** add animals ([8c67d37](https://github.com/ffalt/mah/commit/8c67d375564b0f39ad817366681135eaa3cd569a))
* **images:** reduce png files sizes ([ace93a6](https://github.com/ffalt/mah/commit/ace93a63d4347ce83ef3ce3921c9518aff3047d5))
* **layouts:** random layout generator ([a503275](https://github.com/ffalt/mah/commit/a5032752de0fa50c9b4f8ab1d3a5c10cb89bb53b))
* **locales:** load languages on demand instead of including in the build ([1d5d3a1](https://github.com/ffalt/mah/commit/1d5d3a18887f0960460a18c63704d4e08f0971eb))

### Bug Fixes

* **layout-list:** do not use elements.scrollIntoView() as it may scroll the parent page if embedded with iframe ([a087564](https://github.com/ffalt/mah/commit/a0875647ea9d649869762e1b5d813dcd587dbb45))

## [1.7.7](https://github.com/ffalt/mah/compare/v1.7.6...v1.7.7) (2025-02-22)

* **i18n**: add French
* **i18n**: add Japanese
* **dependencies:** update

## [1.7.6](https://github.com/ffalt/mah/compare/v1.7.5...v1.7.6) (2024-10-31)

* **i18n**: add Euskara (Basque) thanks to <https://crowdin.com/profile/mirenbz>

## [1.7.5](https://github.com/ffalt/mah/compare/v1.7.4...v1.7.5) (2024-10-02)

* **dependencies:** update

## [1.7.4](https://github.com/ffalt/mah/compare/v1.7.3...v1.7.4) (2024-03-25)

### Bug Fixes

* **layout-list:** delete custom board overlayed best time ([b37d61b](https://github.com/ffalt/mah/commit/b37d61bbd05e2359a4d89be25995c3dae8e67116))

## [1.7.3](https://github.com/ffalt/mah/compare/v1.7.2...v1.7.3) (2024-03-23)

### Features

* **layout-list:** allow deleting custom layouts in the layout-list ([74eaf0d](https://github.com/ffalt/mah/commit/74eaf0d7df1cf4db2b2cb1d866baabc90361aecb))

## [1.7.2](https://github.com/ffalt/mah/compare/v1.7.1...v1.7.2) (2024-02-18)

### Features

* **i18n:** update all translations

## [1.7.1](https://github.com/ffalt/mah/compare/v1.7.0...v1.7.1) (2024-02-18)

### Bug Fixes

* **mobile:** use full-height without browser bar to avoid scrolled UI ([d6a071b](https://github.com/ffalt/mah/commit/d6a071b774b7e8f460fd91afbab9e1433b7906af))

## [1.7.0](https://github.com/ffalt/mah/compare/v1.6.1...v1.7.0) (2024-02-18)

### Features

* **sets:** add better seasons and flowers to riichi ([a8ddead](https://github.com/ffalt/mah/commit/a8ddeada6a8675c2542280858fa9e48afea6edc4))
* **theme:** support dark mode in dialogs ([7527228](https://github.com/ffalt/mah/commit/7527228fb88ec8b529c2288ab12e0c5d7716420b))

### [1.6.1](https://github.com/ffalt/mah/compare/v1.6.0...v1.6.1) (2022-06-21)

### Bug Fixes

* **i18n:** Merge pull request [#438](https://github.com/ffalt/mah/issues/438) from carmenfdezb/main ([521039d](https://github.com/ffalt/mah/commit/521039dcab039e57f25d0fefec658e41344761cb))

## [1.6.0](https://github.com/ffalt/mah/compare/v1.5.1...v1.6.0) (2022-06-21)

### Features

* **i18n:** added Spanish, thanks Carmen! ([cb45093](https://github.com/ffalt/mah/commit/cb45093c0737983a3fb1ec18eff3065032892a37))

### Bug Fixes

* **settings-dialog:** more max width ([b860080](https://github.com/ffalt/mah/commit/b8600808c720d4d9116593f865ef5b6a57fb4b30))

### [1.5.1](https://github.com/ffalt/mah/compare/v1.5.0...v1.5.1) (2022-06-13)

### Bug Fixes

* **dialogs:** mobile portrait mode issues ([87be0e7](https://github.com/ffalt/mah/commit/87be0e7f703c8ca4206799d034c1f7e257de78db))

## [1.5.0](https://github.com/ffalt/mah/compare/v1.4.0...v1.5.0) (2022-06-13)

### Features

* **android:** pause if app is in background, integrate capacitor with dedicated build config ([a8f5e5a](https://github.com/ffalt/mah/commit/a8f5e5a06a44863424e9f6fbbded1c019ee134bc))
* **board:** pan bounds when zoomed in ([9612bde](https://github.com/ffalt/mah/commit/9612bde6cafa98f0b06828aed6955752bafda446))
* **boards:** replace duplicates ([1d45033](https://github.com/ffalt/mah/commit/1d45033033f6cc32fc6c82509af1256da68dd0ac))
* **board:** support basic zooming in with pinch/wheel, support pan if zoomed in ([0c79086](https://github.com/ffalt/mah/commit/0c79086d43c5d034e14984fd57b0f3dff4044ab1))
* **board:** zoom on svg element ([db09077](https://github.com/ffalt/mah/commit/db09077053515b90c6f05c1ffb7c6e927c9736be))
* **builder:** shuffle groups, too ([c237ab2](https://github.com/ffalt/mah/commit/c237ab2008698fd7bf0dd7415622d729b34acf1b))
* **game:** support boards with tile count > 144 ([0875ec8](https://github.com/ffalt/mah/commit/0875ec8bd043c4e31a532297848e13b4bef5986e))
* **help:** add all game function icons & shortcuts ([fa80296](https://github.com/ffalt/mah/commit/fa802969b406ee9f121e0727bbba1e51ab994dbd))
* **help:** add minimal how to ([7150020](https://github.com/ffalt/mah/commit/7150020b117aad0c009f6cb42a8d51dd669f66b6))
* **i18n:** update translations ([3dfd6a8](https://github.com/ffalt/mah/commit/3dfd6a84e0a31835fc37a0b0c8c21db491cd3ca0))
* **i18n:** update translations ([9d61ce7](https://github.com/ffalt/mah/commit/9d61ce7a2800be0aeaf59896a2f41cf20677ccfa))
* **images:** compact pngs ([b8da2c3](https://github.com/ffalt/mah/commit/b8da2c3824dd7f9d077ef9f6cda961a809051c67))
* **info-dialog:** add more generic tiles ([68d3995](https://github.com/ffalt/mah/commit/68d399588334a2f008e908883d57ea00b16b7185))
* **info-dialog:** larger tiles, add jokers ([aa20c0b](https://github.com/ffalt/mah/commit/aa20c0be25a4f4c3b1d9634acf79043e66cfc084))
* **info:** add extra tiles to info dialog ([dae5057](https://github.com/ffalt/mah/commit/dae5057f4bfb2ab06087d8793addbd363e8d9eaf))
* **loading:** use css animation instead of webfont rotation ([0933fd2](https://github.com/ffalt/mah/commit/0933fd23cd0c2b1e8ed05d5be11454ab69bd6ced))
* **mobile:** better margins in mobile horizontal ([c57ba66](https://github.com/ffalt/mah/commit/c57ba6656bc01265632e86ed6536832ee9957e14))
* **size:** remove FormsModule ([f8b2c0e](https://github.com/ffalt/mah/commit/f8b2c0ef2c21634766035c702d86a23a0fe42866))
* **svg:** add joker tiles ([3d9de07](https://github.com/ffalt/mah/commit/3d9de07796838f1db9e5b8d7b7ff5479f5f76823))
* **svg:** cleanup ([c70f211](https://github.com/ffalt/mah/commit/c70f21105f6bccacc84e67ff8bb4a84b8fec5b5b))
* **svg:** cleanup ([33969bf](https://github.com/ffalt/mah/commit/33969bff816122f0e304680aa4d41b2b8cc196c0))
* **theme:** basic theming ([baf6744](https://github.com/ffalt/mah/commit/baf67446e4736d11262737359e648d2854c03d5d))
* **theme:** basic theming ([78aa6f2](https://github.com/ffalt/mah/commit/78aa6f20fdbcbcb080a850ee7f3732a8b5b54312))
* **theme:** basic theming; dialog rework ([7d00804](https://github.com/ffalt/mah/commit/7d00804e5fc8452f4a01736f4ac5e75331eae59a))
* **tileset:** add riichi-black ([029fbf4](https://github.com/ffalt/mah/commit/029fbf4d28c73f5d446ba3cb7eb69d3496c921a5))
* **tileset:** make dark tiles an option ([0bcef97](https://github.com/ffalt/mah/commit/0bcef97c4810fbedc94f2bc220b40633455d651d))
* **toolbars:** attach toolbar left & right if screen.height < 600 ([4cb4b38](https://github.com/ffalt/mah/commit/4cb4b384d7d1adfbdd333e78121450793701ea93))

### Bug Fixes

* **board:** handle rotated board in pan ([bee3576](https://github.com/ffalt/mah/commit/bee3576587c2bc6309372032a9ceda181e183d75))
* **board:** show hinted tiles border on dark tiles ([fa749c2](https://github.com/ffalt/mah/commit/fa749c27413cfd80b9aef7e68718e06ab2a034a0))
* **builder:** for boards with < 144 tiles, invalid boards could have been randomly created ([782d64a](https://github.com/ffalt/mah/commit/782d64ab7118b1070c489e733931ff9705d0eb78))
* **builder:** refactor builder & add solver, circumvent blank tiles ([fb30822](https://github.com/ffalt/mah/commit/fb30822074fab01366f848e245804d249d3a22c4)), closes [#427](https://github.com/ffalt/mah/issues/427)
* **builder:** Remove bonkers linear board builder ([e69618b](https://github.com/ffalt/mah/commit/e69618b48a763f5eb018f2a0ea78dc6e1ea1d5f4)), closes [#428](https://github.com/ffalt/mah/issues/428)
* **choose-layout:** add missing padding ([53feebe](https://github.com/ffalt/mah/commit/53feebed3d7fdf605906b498f1de3cc2489f4c46))
* **dialog:** don't run change detection on hidden dialogs ([e031601](https://github.com/ffalt/mah/commit/e03160109b6e50ef5966474ac14afc93a27caf1e))
* **help:** layout columns ([7bff51c](https://github.com/ffalt/mah/commit/7bff51ca501db25a25092cdecd255bef957c8534))
* **loading:** update layout-list after lazy loaded ([c8273bc](https://github.com/ffalt/mah/commit/c8273bc0757d731de3c1b75415f163ccb39b0f53))
* **solver:** increase max groups ([548515b](https://github.com/ffalt/mah/commit/548515bcee18f47747297e4d97bb4f451753ba6d))
* **sound:** restore last setting ([bb8c9ed](https://github.com/ffalt/mah/commit/bb8c9ede8d6486fa85288fdb83f64d925e24be60))
* **svg:** center joker t_g13; remove deps workaround ([08ab5ec](https://github.com/ffalt/mah/commit/08ab5ecf2f1f718fe05b898f636234bb374cd516))
* **tileset:** class names & IDs must be unique ([63319bc](https://github.com/ffalt/mah/commit/63319bc42ed645671f2862dba6282dc259e08501))

## [1.4.0](https://github.com/ffalt/mah/compare/v1.3.1...v1.4.0) (2022-04-03)

### Features

* **boards:** add some more boards ([91144ba](https://github.com/ffalt/mah/commit/91144bab764f89ad72faf210563f0d46df21b522))
* **tiles:** settings for higher contrast (more thick border & darker shadow) ([1177488](https://github.com/ffalt/mah/commit/1177488fbc217fce693280851af5aa519a088cce))

## [1.3.1](https://github.com/ffalt/mah/compare/v1.3.0...v1.3.1) (2022-01-03)

### Features

* **i18n:** feat(i18n): nl translation by Vistaus

## [1.3.0](https://github.com/ffalt/mah/compare/v1.2.0...v1.3.0) (2021-10-27)

### ⚠ BREAKING CHANGES

* **deps:** No more IE11 support

### Features

* **board:** show tile name as svg title ([b111657](https://github.com/ffalt/mah/commit/b111657d6f0ab1a4ae17f1865be5c3fbee787531))
* **font:** switch to kulim park for better cyrillic support ([727d445](https://github.com/ffalt/mah/commit/727d44523cd57b5134f6a95e6e30fe6d4a051f31))
* **i18n:** refactor, add pt & ru, translate more strings ([b7e30fe](https://github.com/ffalt/mah/commit/b7e30fe8dd9d4e1c73f8723de8b5e70f17780ab1))
* **sound:** play tile sound on deselect too ([a91acf7](https://github.com/ffalt/mah/commit/a91acf7bc22218b3fe17b7d5c9dbad4cb1712ddb))

### Bug Fixes

* **css:** better paddings ([ef91056](https://github.com/ffalt/mah/commit/ef91056c71eb9a18e0a7764d843f0ed17fb25202))
* **css:** fix font sizes and layout on 4k display ([d2c375e](https://github.com/ffalt/mah/commit/d2c375e2d07cdd99a5b82acd81eafd09d0a7563a))

### build

* **deps:** update to angular 12.2.11 ([e54d412](https://github.com/ffalt/mah/commit/e54d412878dd355b25324eb086b699ffd54f8ab2))

## [1.2.0](https://github.com/ffalt/mah/compare/v1.1.9...v1.2.0) (2020-12-10)

### Features

* **best times:** remove for a board in layout chooser & remove all in settings ([60ad627](https://github.com/ffalt/mah/commit/60ad6272b1fc2d68e0c4dc78bde345403b6dded9))

## 1.1.9 (2020-09-24)

Start using standard-version changelog
