import { type ComponentFixture, TestBed } from '@angular/core/testing';
import { provideTranslateService } from '@ngx-translate/core';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { SvgdefService } from '../../service/svgdef.service';
import { TilePreviewComponent } from './tile-preview.component';
import { By } from '@angular/platform-browser';
import { describe, beforeEach, it, expect } from 'vitest';

describe('TilePreviewComponent', () => {
	let component: TilePreviewComponent;
	let fixture: ComponentFixture<TilePreviewComponent>;

	beforeEach(async () =>
		TestBed.configureTestingModule({
			imports: [TilePreviewComponent],
			providers: [provideTranslateService(), provideHttpClient(), provideHttpClientTesting(), SvgdefService]
		})
			.compileComponents());

	beforeEach(() => {
		fixture = TestBed.createComponent(TilePreviewComponent);
		component = fixture.componentInstance;
		TestBed.runInInjectionContext(() => {
			fixture.detectChanges();
		});
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should have default tile t_dr_red', () => {
		expect(component.tile()).toBe('t_dr_red');
	});

	it('should accept custom tile input', () => {
		fixture.componentRef.setInput('tile', 't_ba1');
		fixture.detectChanges();
		expect(component.tile()).toBe('t_ba1');
	});

	it('should render an SVG element', () => {
		const svg = fixture.debugElement.query(By.css('svg'));
		expect(svg).toBeTruthy();
	});

	it('should render the preview-stage group', () => {
		const stage = fixture.debugElement.query(By.css('g.preview-stage'));
		expect(stage).toBeTruthy();
	});

	it('should render a draw group with a tile group', () => {
		const tile = fixture.debugElement.query(By.css('g.draw g.tile'));
		expect(tile).toBeTruthy();
	});

	it('should render stone rect', () => {
		const stone = fixture.debugElement.query(By.css('rect.stone'));
		expect(stone).toBeTruthy();
	});

	it('should render shadow rect', () => {
		const shadow = fixture.debugElement.query(By.css('rect.shadow'));
		expect(shadow).toBeTruthy();
	});

	it('should not render shadow rect when shadows are disabled', () => {
		fixture.componentRef.setInput('shadows', false);
		fixture.detectChanges();
		const shadow = fixture.debugElement.query(By.css('rect.shadow'));
		expect(shadow).toBeFalsy();
	});

	it('should render side rect when tile3d is true', () => {
		fixture.componentRef.setInput('tile3d', true);
		fixture.detectChanges();
		const side = fixture.debugElement.query(By.css('rect.side'));
		expect(side).toBeTruthy();
	});

	it('should apply dark class when dark input is true', () => {
		fixture.componentRef.setInput('dark', true);
		fixture.detectChanges();
		const stage = fixture.debugElement.query(By.css('g.preview-stage'));
		expect(stage.nativeElement.classList.contains('dark')).toBe(true);
	});

	it('should apply contrast class when contrast input is true', () => {
		fixture.componentRef.setInput('contrast', true);
		fixture.detectChanges();
		const stage = fixture.debugElement.query(By.css('g.preview-stage'));
		expect(stage.nativeElement.classList.contains('contrast')).toBe(true);
	});

	it('should apply tile3d class when tile3d input is true', () => {
		fixture.componentRef.setInput('tile3d', true);
		fixture.detectChanges();
		const stage = fixture.debugElement.query(By.css('g.preview-stage'));
		expect(stage.nativeElement.classList.contains('tile3d')).toBe(true);
	});

	it('should remove the animations class when animations are disabled', () => {
		fixture.componentRef.setInput('animations', false);
		fixture.detectChanges();
		const stage = fixture.debugElement.query(By.css('g.preview-stage'));
		expect(stage.nativeElement.classList.contains('animations')).toBe(false);
	});

	it('should render bevel rect when tile3d is true', () => {
		fixture.componentRef.setInput('tile3d', true);
		fixture.detectChanges();
		const bevel = fixture.debugElement.query(By.css('rect.bevel'));
		expect(bevel).toBeTruthy();
	});

	it('should not render bevel rect when tile3d is false', () => {
		fixture.componentRef.setInput('tile3d', false);
		fixture.detectChanges();
		const bevel = fixture.debugElement.query(By.css('rect.bevel'));
		expect(bevel).toBeFalsy();
	});
});
