import { type ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient, HttpClient } from '@angular/common/http';
import { SvgdefService } from '../../service/svgdef.service';
import { ImageSetLoaderComponent } from './image-set-loader.component';
import type { ElementRef } from '@angular/core';
import { log } from '../../model/log';
import { TILES, TILES_EXT } from '../../model/consts';
import { type Mock, describe, beforeEach, afterEach, it, expect, vi } from 'vitest';

interface HackImageSetLoaderComponent {
	elementRef: ElementRef;

	getImageSet(): void;

	loadImageSet(): void;

	setError(): void;

	setLoading(): void;

	prepareDefs(svg: string): string;

	setImageSet(svg: string): void;
}

describe('ImageSetLoaderComponent', () => {
	let component: ImageSetLoaderComponent;
	let fixture: ComponentFixture<ImageSetLoaderComponent>;
	let httpClientSpy: { get: Mock };
	let SvgdefServiceSpy: { get: Mock };

	// zoneless whenStable() does not wait for setTimeout, so flush pending
	// macrotasks (loadImageSet timers, promise chains) explicitly
	async function flushAsync(): Promise<void> {
		await new Promise<void>(resolve => {
			setTimeout(resolve, 1);
		});
	}

	beforeEach(async () => {
		httpClientSpy = {
			get: vi.fn()
		};
		SvgdefServiceSpy = {
			get: vi.fn()
		};
		// input changes trigger an immediate load, so the mock needs a default response
		SvgdefServiceSpy.get.mockResolvedValue('<svg><defs></defs></svg>');

		await TestBed.configureTestingModule({
			providers: [
				provideHttpClient(),
				SvgdefService,
				{ provide: SvgdefService, useValue: SvgdefServiceSpy },
				{ provide: HttpClient, useValue: httpClientSpy }
			]
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(ImageSetLoaderComponent);
		component = fixture.componentInstance;
		TestBed.runInInjectionContext(() => {
			fixture.detectChanges();
		});
	});

	afterEach(async () => {
		// let stray loadImageSet timers run while the svgDef mock still returns
		// a value; otherwise they fire between tests after mocks are reset
		SvgdefServiceSpy.get.mockResolvedValue('<svg><defs></defs></svg>');
		await flushAsync();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	describe('Input properties', () => {
		it('should accept imageSet input', () => {
			const testImageSet = 'test-image-set';
			fixture.componentRef.setInput('imageSet', testImageSet);
			fixture.detectChanges();

			expect(component.imageSet()).toBe(testImageSet);
		});

		it('should accept kyodaiUrl input', () => {
			const testUrl = 'https://example.com/kyodai';
			fixture.componentRef.setInput('kyodaiUrl', testUrl);
			fixture.detectChanges();

			expect(component.kyodaiUrl()).toBe(testUrl);
		});

		it('should accept prefix input', () => {
			const testPrefix = 'test-prefix-';
			fixture.componentRef.setInput('prefix', testPrefix);
			fixture.detectChanges();

			expect(component.prefix()).toBe(testPrefix);
		});

		it('should have default value for dark input', () => {
			expect(component.dark()).toBe(false);
		});

		it('should accept dark input override', () => {
			fixture.componentRef.setInput('dark', true);
			fixture.detectChanges();

			expect(component.dark()).toBe(true);
		});
	});

	describe('ngOnChanges', () => {
		it('should call getImageSet when changes occur', () => {
			const getImageSetSpy = vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'getImageSet');
			component.ngOnChanges({});
			expect(getImageSetSpy).toHaveBeenCalled();
		});
	});

	describe('prepareDefs', () => {
		it('should extract and transform SVG defs content', () => {
			fixture.componentRef.setInput('prefix', 'test-prefix-');
			fixture.detectChanges();

			const testSvg = '<svg><defs><use id="t_do1" xlink:href="./test.svg"></use></defs></svg>';
			const result = (component as unknown as HackImageSetLoaderComponent).prepareDefs(testSvg);

			expect(result).toContain('id="test-prefix-t_do1"');
			expect(result).toContain('xlink:href="assets/svg/test.svg"');
		});
	});

	describe('Service interactions', () => {
		it('should call svgDef.get with correct parameters', async () => {
			const testImageSet = 'test-image-set';
			const testUrl = 'https://example.com/kyodai';
			const testSvg = '<svg><defs>Test SVG content</defs></svg>';

			fixture.componentRef.setInput('imageSet', testImageSet);
			fixture.componentRef.setInput('kyodaiUrl', testUrl);
			fixture.detectChanges();

			SvgdefServiceSpy.get.mockResolvedValue(testSvg);
			vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setImageSet');

			(component as unknown as HackImageSetLoaderComponent).loadImageSet();

			expect(SvgdefServiceSpy.get).toHaveBeenCalledWith(testImageSet, testUrl);

			// Wait for the promise to resolve
			await flushAsync();
			expect((component as unknown as HackImageSetLoaderComponent).setImageSet).toHaveBeenCalledWith(testSvg);
		});

		it('should call setError when svgDef.get fails', async () => {
			const testImageSet = 'test-image-set';

			fixture.componentRef.setInput('imageSet', testImageSet);
			fixture.detectChanges();

			SvgdefServiceSpy.get.mockRejectedValue('Error loading SVG');
			vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setError');
			vi.spyOn(log, 'error').mockImplementation(vi.fn());

			(component as unknown as HackImageSetLoaderComponent).loadImageSet();

			// Wait for the promise to reject
			await flushAsync();
			expect((component as unknown as HackImageSetLoaderComponent).setError).toHaveBeenCalled();
		});
	});

	describe('Dark mode handling', () => {
		it('should append -black to imageSet when dark mode is enabled', () => {
			const testImageSet = 'test-image-set';

			fixture.componentRef.setInput('imageSet', testImageSet);
			fixture.componentRef.setInput('dark', true);
			fixture.detectChanges();

			SvgdefServiceSpy.get.mockResolvedValue('<svg><defs></defs></svg>');

			(component as unknown as HackImageSetLoaderComponent).loadImageSet();

			expect(SvgdefServiceSpy.get).toHaveBeenCalledWith(`${testImageSet}-black`, undefined);
		});
	});

	describe('DOM manipulation', () => {
		it('should update innerHTML when setImageSet is called', () => {
			const testSvg = '<svg><defs><use id="test"></use></defs></svg>';
			const mockElementReference = {
				nativeElement: {
					innerHTML: ''
				}
			};

			vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'prepareDefs').mockReturnValue('<use id="test"></use>');
			(component as unknown as HackImageSetLoaderComponent).elementRef = mockElementReference as ElementRef;

			(component as unknown as HackImageSetLoaderComponent).setImageSet(testSvg);

			expect(mockElementReference.nativeElement.innerHTML).toBe('<use id="test"></use>');
		});

		it('should not rewrite the DOM when the prepared defs are unchanged', () => {
			const testSvg = '<svg><defs><use id="test"></use></defs></svg>';
			let writeCount = 0;
			const mockElementReference = {
				nativeElement: {
					set innerHTML(_value: string) {
						writeCount++;
					}
				}
			};

			(component as unknown as HackImageSetLoaderComponent).elementRef = mockElementReference as ElementRef;

			(component as unknown as HackImageSetLoaderComponent).setImageSet(testSvg);
			(component as unknown as HackImageSetLoaderComponent).setImageSet(testSvg);

			expect(writeCount).toBe(1);
		});
	});

	function placeholderIds(svg: string): Array<string> {
		return Array.from(svg.matchAll(/<svg id="([^"]+)"/g), match => match[1]);
	}

	describe('Loading state', () => {
		it('should set loading state with spinner icons', () => {
			const setImageSetSpy = vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setImageSet');

			(component as unknown as HackImageSetLoaderComponent).setLoading();

			expect(setImageSetSpy).toHaveBeenCalled();
			const svgContent = setImageSetSpy.mock.calls[0][0];
			expect(svgContent).toContain('mah-tile-spinner');
		});

		it('should emit one placeholder per distinct tile id', () => {
			const setImageSetSpy = vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setImageSet');

			(component as unknown as HackImageSetLoaderComponent).setLoading();

			const ids = placeholderIds(setImageSetSpy.mock.calls[0][0]);
			expect(ids.length).toBe(new Set(ids).size);
			expect(ids.filter(id => id.startsWith('t_'))).toEqual([...new Set([...TILES, ...TILES_EXT].flat())]);
		});

		it('should cover the extended tile ids', () => {
			const setImageSetSpy = vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setImageSet');

			(component as unknown as HackImageSetLoaderComponent).setLoading();

			const ids = placeholderIds(setImageSetSpy.mock.calls[0][0]);
			expect(ids).toContain('t_g1');
			expect(ids).toContain('t_e9');
			expect(ids.filter(id => id.startsWith('t_'))).toHaveLength(69);
		});
	});

	describe('Error state', () => {
		it('should set error state with error icons', () => {
			const setImageSetSpy = vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setImageSet');

			(component as unknown as HackImageSetLoaderComponent).setError();

			expect(setImageSetSpy).toHaveBeenCalled();
			const svgContent = setImageSetSpy.mock.calls[0][0];
			expect(svgContent).toContain('mah-error-icon');
		});

		it('should emit one placeholder per distinct tile id', () => {
			const setImageSetSpy = vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setImageSet');

			(component as unknown as HackImageSetLoaderComponent).setError();

			const ids = placeholderIds(setImageSetSpy.mock.calls[0][0]);
			expect(ids.length).toBe(new Set(ids).size);
			expect(ids.filter(id => id.startsWith('t_'))).toEqual([...new Set([...TILES, ...TILES_EXT].flat())]);
		});
	});

	describe('getImageSet', () => {
		it('should not proceed if imageSet is not set', () => {
			fixture.componentRef.setInput('imageSet', undefined);
			fixture.detectChanges();

			vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setLoading');

			(component as unknown as HackImageSetLoaderComponent).getImageSet();

			expect((component as unknown as HackImageSetLoaderComponent).setLoading).not.toHaveBeenCalled();
		});

		it('should load immediately and show the loading tiles only after a delay', () => {
			const testImageSet = 'test-image-set';

			fixture.componentRef.setInput('imageSet', testImageSet);
			fixture.detectChanges();

			vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setLoading');
			vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'loadImageSet');
			SvgdefServiceSpy.get.mockReturnValue(new Promise(() => undefined)); // keeps loading

			vi.useFakeTimers();

			(component as unknown as HackImageSetLoaderComponent).getImageSet();

			expect((component as unknown as HackImageSetLoaderComponent).loadImageSet).toHaveBeenCalled();
			expect((component as unknown as HackImageSetLoaderComponent).setLoading).not.toHaveBeenCalled();

			// the spinner tiles appear only when loading takes longer than the delay
			vi.advanceTimersByTime(100);

			expect((component as unknown as HackImageSetLoaderComponent).setLoading).toHaveBeenCalled();

			vi.useRealTimers();
		});

		it('should not show the loading tiles when the set resolves quickly', async () => {
			const testImageSet = 'test-image-set';
			SvgdefServiceSpy.get.mockResolvedValue('<svg><defs><use id="test"></use></defs></svg>');
			vi.spyOn(component as unknown as HackImageSetLoaderComponent, 'setLoading');

			fixture.componentRef.setInput('imageSet', testImageSet);
			fixture.detectChanges();
			await flushAsync();

			expect((component as unknown as HackImageSetLoaderComponent).setLoading).not.toHaveBeenCalled();
			expect((fixture.nativeElement as HTMLElement).innerHTML).toContain('id="test"');
		});
	});
});
