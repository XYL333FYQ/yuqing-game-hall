import { Component, DestroyRef, ElementRef, inject, signal, viewChild, type AfterViewInit } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { Backgrounds, ImageSetDefault, ImageSets, PATTERN_BACKGROUND, Themes } from '../../model/consts';
import { AppService } from '../../service/app.service';
import { LANGUAGES } from '../../model/languages';
import { KyodaiTileSets } from '../../model/tilesets';
import { environment } from '../../../environments/environment';
import { LicenseLinkComponent } from '../license-link/license-link.component';
import { TilePreviewComponent } from '../tile-preview/tile-preview.component';
import { generatePatternList } from '../../service/pattern.service';

const SETTINGS_TABS = [
	{ id: 'lang', name: 'LANG' },
	{ id: 'stones', name: 'TILESET' },
	{ id: 'theme', name: 'THEME' },
	{ id: 'background', name: 'BACKGROUND' },
	{ id: 'ui', name: 'UI' }
];

@Component({
	selector: 'app-settings',
	templateUrl: './settings.component.html',
	styleUrls: ['./settings.component.scss'],
	imports: [TranslatePipe, LicenseLinkComponent, TilePreviewComponent],
	host: {
		'(scroll)': 'onScroll($event)'
	}
})
export class SettingsComponent implements AfterViewInit {
	readonly kyodaiInput = viewChild<ElementRef<HTMLInputElement | HTMLTextAreaElement>>('kyodaiInput');
	readonly canKyodai = environment.kyodai;
	readonly canDaily = environment.daily;
	readonly kyodaiTileSets = KyodaiTileSets;
	readonly sets = ImageSets;
	readonly backs = Backgrounds;
	readonly themes = Themes;
	readonly PatternBackground = PATTERN_BACKGROUND;
	readonly languages = Object.entries(LANGUAGES).map(([key, value]) => ({ key, title: value }));
	readonly app = inject(AppService);
	readonly tabs = SETTINGS_TABS;
	readonly patterns = generatePatternList();
	readonly selectedTab = signal<string>(this.app.getCachedValue('settings.selectedTab') as string | undefined ?? SETTINGS_TABS[0].id);
	readonly reducedMotion = signal(false);

	private readonly element = inject(ElementRef);
	private readonly lifecycle = inject(DestroyRef);
	private readonly reducedMotionQuery = window.matchMedia?.('(prefers-reduced-motion: reduce)');

	constructor() {
		const query = this.reducedMotionQuery;
		if (!query) {
			return;
		}
		this.reducedMotion.set(query.matches);
		const update = (event: MediaQueryListEvent): void => this.reducedMotion.set(event.matches);
		query.addEventListener('change', update);
		this.lifecycle.onDestroy(() => query.removeEventListener('change', update));
	}

	ngAfterViewInit(): void {
		if (this.element?.nativeElement) {
			this.restoreScroll(this.element.nativeElement);
		}
	}

	setBackground(background: string) {
		this.app.settings.background.set(background);
		this.app.settings.save();
	}

	updateKyodaiUrl(event: Event): void {
		this.app.settings.kyodaiUrl.set((event.target as HTMLTextAreaElement | HTMLInputElement).value);
		this.app.settings.save();
	}

	clearKyodaiUrl(): void {
		this.app.settings.kyodaiUrl.set(undefined);
		this.app.settings.tileset.set(ImageSetDefault);
		this.app.settings.save();
	}

	setKyodaiUrl(event: Event): void {
		const kyodaiInput = this.kyodaiInput();
		if (!kyodaiInput?.nativeElement) {
			return;
		}
		event.preventDefault();
		event.stopPropagation();
		kyodaiInput.nativeElement.value = (event.target as HTMLSelectElement).value;
	}

	applyKyodaiUrl(): void {
		const kyodaiInput = this.kyodaiInput();
		if (!kyodaiInput?.nativeElement) {
			return;
		}
		this.app.settings.kyodaiUrl.set(kyodaiInput.nativeElement.value);
		this.app.settings.save();
	}

	setSelectedTab(tab: string): void {
		this.selectedTab.set(tab);
		this.app.cacheValue('settings.selectedTab', tab);
	}

	restoreScroll(container: HTMLElement): void {
		if (!container) {
			return;
		}
		const pos = this.app.getCachedValue('settings.scrollTop') as number | undefined;
		setTimeout(() => container.scrollTop = pos ?? 0, 0);
	}

	onScroll(event: Event): void {
		const top = (event.target as HTMLElement).scrollTop;
		this.app.cacheValue('settings.scrollTop', top);
	}
}
