import { Component, computed, input } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { ImageSetLoaderComponent } from '../image-set-loader/image-set-loader.component';
import { tileImagePos } from '../../model/tilesets';

@Component({
	selector: 'app-tile',
	templateUrl: './tile.component.html',
	styleUrls: ['./tile.component.scss'],
	imports: [ImageSetLoaderComponent, TranslatePipe]
})
export class TileComponent {
	readonly imageSet = input<string>();
	readonly kyodaiUrl = input<string>();
	readonly tile = input.required<string>();
	readonly index = input<number>();
	readonly isDark = input<boolean>(false);
	readonly sharedPrefix = input<string>();
	readonly imagePos = computed(() => tileImagePos(this.imageSet()));
}
