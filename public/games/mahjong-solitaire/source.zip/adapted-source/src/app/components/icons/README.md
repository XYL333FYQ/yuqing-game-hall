# Icons license info

## Entypo

Copyright (C) 2012 by Daniel Bruce

Author:    Daniel Bruce  
License:   SIL (<http://scripts.sil.org/OFL>)  
Homepage:  <http://www.entypo.com>

## Font Awesome

Copyright (C) 2016 by Dave Gandy

Author:    Dave Gandy  
License:   SIL (<http://scripts.sil.org/OFL>)  
Homepage:  <http://fortawesome.github.com/Font-Awesome/>

## Iconic

Copyright (C) 2012 by P.J. Onori

Author:    P.J. Onori  
License:   SIL (<http://scripts.sil.org/OFL>)  
Homepage:  <http://somerandomdude.com/work/iconic/>

## Fontelico

Copyright (C) 2012 by Fontello project

Author:    Crowdsourced, for Fontello project  
License:   SIL (<http://scripts.sil.org/OFL>)  
Homepage:  <http://fontello.com>

## Typicons

(c) Stephen Hutchings 2012

Author:    Stephen Hutchings  
License:   SIL (<http://scripts.sil.org/OFL>)  
Homepage:  <http://typicons.com/>
