import { provideHttpClientTesting } from '@angular/common/http/testing';
import { type ComponentFixture, TestBed } from '@angular/core/testing';
import { provideTranslateService } from '@ngx-translate/core';
import { provideHttpClient } from '@angular/common/http';
import { AppService } from '../../service/app.service';
import { LayoutService } from '../../service/layout.service';
import { SettingsComponent } from './settings.component';
import { By } from '@angular/platform-browser';
import { LocalstorageService } from '../../service/localstorage.service';
import { Backgrounds, ImageSets, Themes } from '../../model/consts';
import { KyodaiTileSets } from '../../model/tilesets';
import { environment } from '../../../environments/environment';
import type { ElementRef } from '@angular/core';
import { describe, beforeEach, it, expect, vi } from 'vitest';

describe('SettingsComponent', () => {
	let component: SettingsComponent;
	let fixture: ComponentFixture<SettingsComponent>;
	let appService: AppService;

	beforeEach(async () =>
		TestBed.configureTestingModule({
			imports: [SettingsComponent],
			providers: [provideTranslateService(), provideHttpClient(), provideHttpClientTesting(), AppService, LayoutService, LocalstorageService]
		})
			.compileComponents());

	beforeEach(() => {
		fixture = TestBed.createComponent(SettingsComponent);
		component = fixture.componentInstance;
		appService = TestBed.inject(AppService);
		fixture.detectChanges();
	});

	it('should create', async () => {
		expect(component).toBeTruthy();
	});

	it('should initialize with correct properties', () => {
		expect(component.canKyodai).toBe(environment.kyodai);
		expect(component.kyodaiTileSets).toBe(KyodaiTileSets);
		expect(component.sets).toBe(ImageSets);
		expect(component.backs).toBe(Backgrounds);
		expect(component.themes).toBe(Themes);
		expect(component.app).toBeDefined();
	});

	describe('Kyodai URL management', () => {
		it('should update Kyodai URL', () => {
			const saveSpy = vi.spyOn(appService.settings, 'save');
			const testUrl = 'https://example.com/tileset';
			const event = { target: { value: testUrl } } as unknown as Event;

			component.updateKyodaiUrl(event);

			expect(appService.settings.kyodaiUrl()).toBe(testUrl);
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should clear Kyodai URL', () => {
			const saveSpy = vi.spyOn(appService.settings, 'save');
			appService.settings.kyodaiUrl.set('https://example.com/tileset');

			component.clearKyodaiUrl();

			expect(appService.settings.kyodaiUrl()).toBeUndefined();
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should set Kyodai URL from dropdown', () => {
			// Mock the kyodaiInput viewChild
			const mockNativeElement = { value: '' };
			const mockElementReference = { nativeElement: mockNativeElement };
			vi.spyOn(component, 'kyodaiInput').mockReturnValue(mockElementReference as ElementRef<HTMLInputElement>);

			const testUrl = 'https://example.com/tileset';
			const event = {
				preventDefault: vi.fn(),
				stopPropagation: vi.fn(),
				target: { value: testUrl }
			} as unknown as Event;

			component.setKyodaiUrl(event);

			expect(mockNativeElement.value).toBe(testUrl);
			expect(event.preventDefault).toHaveBeenCalled();
			expect(event.stopPropagation).toHaveBeenCalled();
		});

		it('should apply Kyodai URL', () => {
			const saveSpy = vi.spyOn(appService.settings, 'save');
			const testUrl = 'https://example.com/tileset';

			// Mock the kyodaiInput viewChild
			const mockNativeElement = { value: testUrl };
			const mockElementReference = { nativeElement: mockNativeElement };
			vi.spyOn(component, 'kyodaiInput').mockReturnValue(mockElementReference as ElementRef<HTMLInputElement>);

			component.applyKyodaiUrl();

			expect(appService.settings.kyodaiUrl()).toBe(testUrl);
			expect(saveSpy).toHaveBeenCalled();
		});
	});

	describe('UI Elements', () => {
		it('should render language selection radio buttons', () => {
			const radioButtons = fixture.debugElement.queryAll(By.css('input[name="lang"]'));
			expect(radioButtons).toHaveLength(component.languages.length + 1); // +1 for auto option
		});

		it('should render background selection radio buttons', () => {
			const radioButtons = fixture.debugElement.queryAll(By.css('input[name="back"]'));
			expect(radioButtons).toHaveLength(component.backs.length);
		});

		it('should render theme selection radio buttons', () => {
			const radioButtons = fixture.debugElement.queryAll(By.css('input[name="color"]'));
			expect(radioButtons).toHaveLength(component.themes.length);
		});

		it('should render tileset selection radio buttons', () => {
			const radioButtons = fixture.debugElement.queryAll(By.css('input[name="imageset"]'));
			// Number of buttons should be sets.length + (canKyodai ? 1 : 0)
			const expectedCount = component.sets.length + (component.canKyodai ? 1 : 0);
			expect(radioButtons).toHaveLength(expectedCount);
		});

		it('should render shadows, contrast, dark mode, 3D, animations, confetti and show clock checkboxes', () => {
			const checkboxes = fixture.debugElement.queryAll(By.css('input[type="checkbox"]'));
			expect(checkboxes).toHaveLength(10 + (component.canDaily ? 2 : 0));
			expect(fixture.debugElement.query(By.css('fieldset.animations .animations-note'))).toBeTruthy();
		});
	});

	describe('Tab selection', () => {
		// OnPush: selecting a tab updates the signal and the view re-renders the checked state
		it('updates selectedTab and reflects the checked state in the view', () => {
			const tabInputs = fixture.debugElement.queryAll(By.css('input[name="settings-tab"]'));
			expect(component.selectedTab()).toBe(component.tabs[0].id);

			const targetIndex = 2;
			tabInputs[targetIndex].nativeElement.dispatchEvent(new Event('change'));
			fixture.detectChanges();

			expect(component.selectedTab()).toBe(component.tabs[targetIndex].id);
			expect(tabInputs[targetIndex].nativeElement.checked).toBe(true);
		});
	});

	describe('Settings interactions', () => {
		const checkboxByLabel = (labelKey: string): HTMLInputElement => {
			const label = fixture.debugElement
				.queryAll(By.css('label.check'))
				.find(l => (l.nativeElement.textContent as string).includes(labelKey));
			expect(label, `checkbox with label "${labelKey}"`).toBeTruthy();
			return label?.query(By.css('input[type="checkbox"]')).nativeElement as HTMLInputElement;
		};

		it('should have a method to set language', () => {
			// Instead of testing the click event, test the change handler directly
			appService.settings.lang.set('en');
			component.app.setLang = vi.fn();

			// Call the change handler directly (simulating what happens when radio is clicked)
			appService.settings.lang.set('auto');
			appService.setLang();

			expect(appService.settings.lang()).toBe('auto');
			expect(component.app.setLang).toHaveBeenCalled();
		});

		it('should have a method to set background', () => {
			// Instead of testing the click event, test the change handler directly
			const saveSpy = vi.spyOn(appService.settings, 'save');
			appService.settings.background.set('');

			// Set a background value directly (simulating what happens when radio is clicked)
			appService.settings.background.set('test-background');
			appService.settings.save();

			expect(appService.settings.background()).toBe('test-background');
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should have a method to set theme', () => {
			// Instead of testing the click event, test the change handler directly
			const saveSpy = vi.spyOn(appService.settings, 'save');
			appService.settings.theme.set('');

			// Set a theme value directly (simulating what happens when radio is clicked)
			appService.settings.theme.set('test-theme');
			appService.settings.save();

			expect(appService.settings.theme()).toBe('test-theme');
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should have a method to set tileset', () => {
			// Instead of testing the click event, test the change handler directly
			const saveSpy = vi.spyOn(appService.settings, 'save');
			appService.settings.tileset.set('');

			// Set a tileset value directly (simulating what happens when radio is clicked)
			appService.settings.tileset.set('test-tileset');
			appService.settings.save();

			expect(appService.settings.tileset()).toBe('test-tileset');
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should update app settings when 3D is toggled', () => {
			const saveSpy = vi.spyOn(appService.settings, 'save');
			const initialValue = appService.settings.tile3d();
			const threeDCheckbox = checkboxByLabel('TILES_3D');

			threeDCheckbox.click();
			fixture.detectChanges();

			expect(appService.settings.tile3d()).toBe(!initialValue);
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should update app settings when shadows are toggled', () => {
			const saveSpy = vi.spyOn(appService.settings, 'save');
			const initialValue = appService.settings.shadows();
			const shadowsCheckbox = checkboxByLabel('TILES_SHADOWS');

			shadowsCheckbox.click();
			fixture.detectChanges();

			expect(appService.settings.shadows()).toBe(!initialValue);
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should update app settings when contrast is toggled', () => {
			const saveSpy = vi.spyOn(appService.settings, 'save');
			const initialValue = appService.settings.contrast();
			const contrastCheckbox = checkboxByLabel('HIGHER_CONTRAST');

			contrastCheckbox.click();
			fixture.detectChanges();

			expect(appService.settings.contrast()).toBe(!initialValue);
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should update app settings when dark mode is toggled', () => {
			const saveSpy = vi.spyOn(appService.settings, 'save');
			const initialValue = appService.settings.dark();
			const darkCheckbox = checkboxByLabel('TILES_DARK');

			darkCheckbox.click();
			fixture.detectChanges();

			expect(appService.settings.dark()).toBe(!initialValue);
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should update app settings when tile animations are toggled', () => {
			const saveSpy = vi.spyOn(appService.settings, 'save');
			const initialValue = appService.settings.dailyAnimations();
			const animationsCheckbox = checkboxByLabel('TILE_ANIMATIONS');

			animationsCheckbox.click();
			fixture.detectChanges();

			expect(appService.settings.dailyAnimations()).toBe(!initialValue);
			expect(saveSpy).toHaveBeenCalled();
		});

		it('should uncheck and disable tile animations when reduced motion is active', () => {
			appService.settings.dailyAnimations.set(true);
			component.reducedMotion.set(true);
			fixture.detectChanges();
			const animationsCheckbox = checkboxByLabel('TILE_ANIMATIONS');

			expect(animationsCheckbox.checked).toBe(false);
			expect(animationsCheckbox.disabled).toBe(true);
			expect(appService.settings.dailyAnimations()).toBe(true);
		});
	});
});
