import { signal, type WritableSignal } from '@angular/core';

interface GestureIndicator {
	x: number;
	y: number;
	size: number;
	state: WritableSignal<'hidden' | 'visible'>;
	transform?: string;
	top: number;
	left: number;
	hideTimerId?: ReturnType<typeof setTimeout>;
	removeTimerId?: ReturnType<typeof setTimeout>;
}

export class Indicator {
	readonly gestureIndicators = signal<Array<GestureIndicator>>([]);

	hide(gestureIndicator?: { x: number; y: number }) {
		const indicator = gestureIndicator;
		if (!indicator) {
			return;
		}

		const fullIndicator = this.findIndicator(indicator);

		if (!fullIndicator) {
			return;
		}

		// Cancel any pending hide operations for this indicator
		this.cancelHideTimer(fullIndicator);

		// Schedule hide state change
		fullIndicator.hideTimerId = setTimeout(() => {
			fullIndicator.state.set('hidden');
			fullIndicator.hideTimerId = undefined;

			// Schedule removal
			fullIndicator.removeTimerId = setTimeout(() => {
				this.removeIndicator(fullIndicator);
				fullIndicator.removeTimerId = undefined;
			}, 250);
		}, 500);
	}

	private findIndicator(gestureIndicator: { x: number; y: number }): GestureIndicator | undefined {
		const list = this.gestureIndicators();
		const byPosition = (indicator: GestureIndicator) => indicator.x === gestureIndicator.x && indicator.y === gestureIndicator.y;
		return list.find(indicator => indicator === gestureIndicator) ?? list.find(element => byPosition(element));
	}

	private cancelHideTimer(indicator: GestureIndicator): void {
		if (indicator.hideTimerId !== undefined) {
			clearTimeout(indicator.hideTimerId);
			indicator.hideTimerId = undefined;
		}
		if (indicator.removeTimerId === undefined) {
			return;
		}
		clearTimeout(indicator.removeTimerId);
		indicator.removeTimerId = undefined;
	}

	removeIndicator(gestureIndicator: { x: number; y: number }) {
		const target = this.findIndicator(gestureIndicator);
		if (!target) {
			return;
		}
		this.cancelHideTimer(target);
		this.gestureIndicators.update(list => list.filter(indicator => indicator !== target));
	}

	setSize(nr: number, size: number): void {
		const indicator = this.gestureIndicators()[nr];
		if (!indicator) {
			return;
		}
		indicator.size = size;
		indicator.top = indicator.y - (size / 2);
		indicator.left = indicator.x - (size / 2);
		this.gestureIndicators.update(list => [...list]);
	}

	display(x: number, y: number, size: number): GestureIndicator | undefined {
		if (x > 0 && y > 0) {
			const gestureIndicator: GestureIndicator = {
				x,
				y,
				size,
				top: y - (size / 2),
				left: x - (size / 2),
				state: signal<'hidden' | 'visible'>('hidden')
			};
			this.gestureIndicators.update(list => [...list, gestureIndicator]);
			setTimeout(() => {
				gestureIndicator.state.set('visible');
			}, 100);
			return gestureIndicator;
		}
		return undefined;
	}
}
