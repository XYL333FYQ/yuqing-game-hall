export const CONSTS = {
	mY: 18, mX: 38, mZ: 7,
	tileWidth: 75,
	tileHeight: 100,
	levelOffset: 16
};

export const STATES = {
	idle: 0,
	run: 1,
	pause: 2
};

export const RESCUE_SHUFFLE_ATTEMPTS = 20;

export const GAME_MODE_EASY: GAME_MODE_ID = 'GAME_MODE_EASY';
export const GAME_MODE_STANDARD: GAME_MODE_ID = 'GAME_MODE_STANDARD';
export const GAME_MODE_EXPERT: GAME_MODE_ID = 'GAME_MODE_EXPERT';
// internal: a challenge sets its own rules, so it is never offered in GameModes and never picked by hand
export const GAME_MODE_CHALLENGE: GAME_MODE_ID = 'GAME_MODE_CHALLENGE';

export interface GameModeFeature {
	title: string;
	desc?: string;
}

export const GameModes: Array<{ id: GAME_MODE_ID; features: Array<GameModeFeature> }> = [
	{
		id: GAME_MODE_EASY,
		features: [
			{ title: 'SHUFFLE' },
			{ title: 'HINT' },
			{ title: 'UNDO' },
			{ title: 'RESCUE_SHUFFLE' },
			{ title: 'SHOW_MATCHING', desc: 'SHOW_MATCHING_DESC' }
		]
	},
	{
		id: GAME_MODE_STANDARD,
		features: [
			{ title: 'HINT' },
			{ title: 'UNDO' }
		]
	},
	{
		id: GAME_MODE_EXPERT,
		features: []
	}
];
export type GAME_MODE_ID = 'GAME_MODE_EASY' | 'GAME_MODE_STANDARD' | 'GAME_MODE_EXPERT' | 'GAME_MODE_CHALLENGE';
export const GAME_MODE_ID_DEFAULT: GAME_MODE_ID = 'GAME_MODE_STANDARD';

export const Themes: Array<{ id: string; name: string; colors: Array<string> }> = [
	{ id: 'ltgreen', name: 'THEME_SAGE', colors: ['#5a7b8b', '#446471', '#1e2d35', '#0f1e25', '#4686a5'] },
	{ id: 'dkgreen', name: 'THEME_FOREST', colors: ['#4d6673', '#2a3b46', '#405765', '#1e2e36', '#19262e'] },
	{ id: 'ltblue', name: 'THEME_SKY', colors: ['#7480b0', '#4b527c', '#2a2e4b', '#232742', '#34385a'] },
	{ id: 'ice', name: 'THEME_ICE', colors: ['#4f8fb6', '#9fd0e9', '#6aa7ca', '#8bc3dd', '#b3e5fc'] },
	{ id: 'dkblue', name: 'THEME_NAVY', colors: ['#2f49a3', '#0d2165', '#233694', '#2f44ad', '#001552'] },
	{ id: 'ocean', name: 'THEME_OCEAN', colors: ['#3b80ad', '#1d547a', '#31749f', '#134a6f', '#0a3d62'] },
	{ id: 'cyberpunk', name: 'THEME_CYBERPUNK', colors: ['#6a4a6a', '#3e193e', '#5e3a5e', '#6c496c', '#320032'] },
	{ id: 'desert', name: 'THEME_DESERT', colors: ['#a4863f', '#b8924d', '#a8843e', '#e3c68e', '#c9a961'] },
	{ id: 'brown', name: 'THEME_MAHOGANY', colors: ['#d15a5a', '#c34a4a', '#8c2323', '#7a1f1f', '#a52a2a'] },
	{ id: 'medieval', name: 'THEME_MEDIEVAL', colors: ['#8a623e', '#5a3b23', '#7b5534', '#2f1c10', '#3d2817'] },
	{ id: 'lava', name: 'THEME_LAVA', colors: ['#a85b56', '#7a332e', '#9a4f4a', '#46201c', '#5d1f1a'] },
	{ id: 'space', name: 'THEME_SPACE', colors: ['#435c7d', '#1f3046', '#38506d', '#162539', '#0d1b2a'] },
	{ id: 'black', name: 'THEME_ONYX', colors: ['#5c5c5c', '#2a2a2a', '#4a4a4a', '#5a5a5a', '#000000'] },
	{ id: 'white', name: 'THEME_PEARL', colors: ['#9e9e9e', '#d0d0d0', '#b5b5b5', '#a8a8a8', '#ffffff'] }
];

export const PATTERN_BACKGROUND = 'pattern-monster';

export type LICENCE = 'cca' | 'gpl' | 'free' | 'per' | 'pub' | 'mit';

export const Backgrounds: Array<{ img: string; name: string; type?: 'jpg' | 'png' | 'svg' | 'MAH'; repeat?: boolean; license?: LICENCE }> = [{ img: '', name: 'BACK_NONE' }];
