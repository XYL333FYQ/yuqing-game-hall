import { Clock } from './clock';
import { type Mock, describe, beforeEach, afterEach, it, expect, vi } from 'vitest';

describe('Clock', () => {
	let clock: Clock;
	let originalSetTimeout: typeof window.setTimeout;
	let originalClearTimeout: typeof window.clearTimeout;
	let mockSetTimeout: Mock;
	let mockClearTimeout: Mock;
	let now: number;

	beforeEach(() => {
		now = 1000;
		clock = new Clock(() => now);

		originalSetTimeout = window.setTimeout;
		originalClearTimeout = window.clearTimeout;
		mockSetTimeout = vi.fn().mockReturnValue(123); // Return a fake timer ID
		mockClearTimeout = vi.fn();
		window.setTimeout = mockSetTimeout as unknown as typeof window.setTimeout;
		window.clearTimeout = mockClearTimeout;
	});

	afterEach(() => {
		window.setTimeout = originalSetTimeout;
		window.clearTimeout = originalClearTimeout;
	});

	describe('initialization', () => {
		it('should create an instance', () => {
			expect(clock).toBeTruthy();
		});

		it('should initialize with zero elapsed time', () => {
			expect(clock.elapsed()).toBe(0);
		});
	});

	describe('reset', () => {
		it('should reset elapsed time to zero', () => {
			clock.elapsed.set(5000);
			clock.reset();
			expect(clock.elapsed()).toBe(0);
		});

		it('should clear the timer if running', () => {
			// Set up a running timer
			clock.run();
			expect(mockSetTimeout).toHaveBeenCalled();

			clock.reset();

			expect(mockClearTimeout).toHaveBeenCalledWith(123);
		});
	});

	describe('run', () => {
		it('should start the timer', () => {
			clock.run();

			expect(mockSetTimeout).toHaveBeenCalled();
			expect(mockSetTimeout.mock.calls[0][1]).toBe(1000); // Check timeout duration
		});

		it('should not start a new timer if already running', () => {
			clock.run();
			mockSetTimeout.mockClear();

			clock.run();

			expect(mockSetTimeout).not.toHaveBeenCalled();
		});
	});

	describe('pause', () => {
		it('should clear the timer', () => {
			clock.run();
			clock.pause();

			expect(mockClearTimeout).toHaveBeenCalledWith(123);
		});

		it('should update elapsed time', () => {
			clock.run();

			// Simulate time passing
			now = 3000;

			clock.pause();

			expect(clock.elapsed()).toBe(2000); // 3000 - 1000 = 2000
		});

		it('should do nothing if not running', () => {
			clock.pause();

			expect(mockClearTimeout).not.toHaveBeenCalled();
			expect(clock.elapsed()).toBe(0);
		});

		it('should not count anything twice when paused repeatedly', () => {
			clock.run();
			now = 3000;
			clock.pause();
			now = 9000;
			clock.pause();

			expect(clock.elapsed()).toBe(2000);
			expect(clock.current()).toBe(2000);
		});

		it('should not shrink when the time source jumps backwards', () => {
			clock.run();
			now = 200;

			expect(clock.current()).toBe(0);

			clock.pause();

			expect(clock.elapsed()).toBe(0);
		});
	});

	describe('current', () => {
		it('should count the time since the last tick, which elapsed has not booked yet', () => {
			clock.run();

			now = 1400;

			expect(clock.elapsed()).toBe(0);
			expect(clock.current()).toBe(400);
		});

		it('should not move while the clock is not running', () => {
			clock.elapsed.set(2000);

			now = 9000;

			expect(clock.current()).toBe(2000);
		});

		it('should stay on the same footing as elapsed across a tick', () => {
			clock.run();
			const stepCallback = mockSetTimeout.mock.calls[0][0];
			now = 2500;
			stepCallback();

			now = 2900;

			expect(clock.elapsed()).toBe(1500);
			expect(clock.current()).toBe(1900);
		});
	});

	describe('step', () => {
		it('should update elapsed time and set a new timer', () => {
			clock.run();

			// Save a reference to the callback function
			const stepCallback = mockSetTimeout.mock.calls[0][0];

			// Clear mocks to check only the step function calls
			mockSetTimeout.mockClear();

			// Simulate time passing
			now = 2500;

			// Call the step method directly through the timer callback
			stepCallback();

			// Check elapsed time was updated
			expect(clock.elapsed()).toBe(1500); // 2500 - 1000 = 1500

			// Check a new timer was set
			expect(mockSetTimeout).toHaveBeenCalled();
		});
	});
});
