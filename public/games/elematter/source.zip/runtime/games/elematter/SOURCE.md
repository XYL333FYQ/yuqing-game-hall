# 元素防线 / Elematter

原作：[ jackrugile/elematter-js13k ](https://github.com/jackrugile/elematter-js13k)

固定提交：`b7c4c0a9e06446a9afacbd605ea1efb0ae3433ae`

代码许可：MIT，完整文本见 [LICENSE](./LICENSE)。

本地改动：本地打包、中文菜单和规则提示，保留原玩法。 共享中文层及玩法面板为本项目 MIT 代码；没有把游戏逻辑并入大厅。

原作署名与第三方声明保留在原文件及源码包。

[对应源码与改动](./source.zip) 包含固定提交源码、当前运行脚本、中文层和构建说明。未修改的重复音频在 runtime/ 中提供；大型开发演示图和编译器二进制没有进入源码包。

通用音效组件 ZzFX（使用它的游戏），Copyright (c) 2019 Frank Force，MIT；完整第三方许可见 [/legal/THIRD_PARTY_NOTICES.md](/legal/THIRD_PARTY_NOTICES.md)。
