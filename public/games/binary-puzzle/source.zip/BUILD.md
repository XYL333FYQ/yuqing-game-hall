# 双色逻辑

Upstream: https://github.com/florisluiten/0hh1
Pinned commit: 25910e580d6ea6bc1dfbfd29b2637e47844a96f9
License: MIT; Apache-2.0 launcher, see runtime/games/binary-puzzle/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/binary-puzzle/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:
fonts/JosefinSans-Bold.ttf
fonts/Molle-Regular.ttf
fonts/fonts.css
