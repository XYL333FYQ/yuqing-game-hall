# 中国象棋

Upstream: https://github.com/xqbase/xqwlight
Pinned commit: 6221733f1f79b3acb44cce6f83dc6100443cb2c9
License: GPL-2.0-or-later, see runtime/games/chinese-chess/LICENSE.

runtime/ is the exact adapted static package. Run
python -m http.server 8080 --directory runtime
and open http://localhost:8080/games/chinese-chess/index.html .

upstream/ contains the preferred source at the recorded commit. Normal hall
builds serve committed runtimes without rebuilding third-party programs.
adaptations/ contains import-games.mjs, pinned build inputs and the source
packager. See adaptations/README.md for rebuilding the two compiled games;
prepare-builds.mjs selects Chinese by default for Minesweeper and replaces
obsolete node-sass for BreakLock. The original sources remain separate.
For other games the readable runtime is also the editable adapted source.
Chinese Chess originally uses GBK: import-games.mjs converts it to UTF-8.

Unused fonts/audio omitted from the archive:
JavaScript/sounds/capture.wav
JavaScript/sounds/capture2.wav
JavaScript/sounds/check.wav
JavaScript/sounds/check2.wav
JavaScript/sounds/click.wav
JavaScript/sounds/draw.wav
JavaScript/sounds/illegal.wav
JavaScript/sounds/loss.wav
JavaScript/sounds/move.wav
JavaScript/sounds/move2.wav
JavaScript/sounds/newgame.wav
JavaScript/sounds/win.wav
