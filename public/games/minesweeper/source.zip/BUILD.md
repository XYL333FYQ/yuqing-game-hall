# 经典扫雷

Upstream: https://github.com/junjie-xu-lab/minesweeper
Pinned commit: 979f135fd2e2f493fc6ea5fa8fd90d4eb251f78b
License: MIT, see runtime/games/minesweeper/LICENSE.

runtime/ is the exact adapted static package. Run
python -m http.server 8080 --directory runtime
and open http://localhost:8080/games/minesweeper/index.html .

upstream/ contains the preferred source at the recorded commit. Normal hall
builds serve committed runtimes without rebuilding third-party programs.
adaptations/ contains import-games.mjs, pinned build inputs and the source
packager. See adaptations/README.md for rebuilding the two compiled games;
prepare-builds.mjs selects Chinese by default for Minesweeper and replaces
obsolete node-sass for BreakLock. The original sources remain separate.
For other games the readable runtime is also the editable adapted source.
Chinese Chess originally uses GBK: import-games.mjs converts it to UTF-8.

Unused fonts/audio omitted from the archive:

