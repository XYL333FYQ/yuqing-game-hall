import test from 'node:test'
import assert from 'node:assert/strict'
import { createBoard, isWon, openArea, placeMines } from './engine.js'

test('first click and its surrounding cells are protected when space allows', () => {
  const board = placeMines(createBoard(9, 9), 10, 4, 4, () => 0.5)
  for (let row = 3; row <= 5; row += 1) {
    for (let col = 3; col <= 5; col += 1) assert.equal(board[row][col].isMine, false)
  }
  assert.equal(board.flat().filter((cell) => cell.isMine).length, 10)
})

test('opening an empty cell expands until numbered boundary', () => {
  const board = createBoard(3, 3)
  board[2][2].isMine = true
  board[1][1].adjacent = 1
  board[1][2].adjacent = 1
  board[2][1].adjacent = 1
  openArea(board, 0, 0)
  assert.equal(board[0][0].isOpen, true)
  assert.equal(board[1][1].isOpen, true)
  assert.equal(board[2][2].isOpen, false)
})

test('win requires all safe cells to be open', () => {
  const board = createBoard(2, 2)
  board[1][1].isMine = true
  board[0][0].isOpen = board[0][1].isOpen = board[1][0].isOpen = true
  assert.equal(isWon(board), true)
})
