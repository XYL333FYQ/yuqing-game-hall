export const DIFFICULTIES = {
  beginner: { rows: 9, cols: 9, mines: 10 },
  intermediate: { rows: 16, cols: 16, mines: 40 },
  expert: { rows: 16, cols: 30, mines: 99 },
}

export function createBoard(rows, cols) {
  return Array.from({ length: rows }, (_, row) =>
    Array.from({ length: cols }, (_, col) => ({ row, col, isMine: false, isOpen: false, isFlagged: false, adjacent: 0 })),
  )
}

export function placeMines(board, mines, safeRow, safeCol, random = Math.random) {
  const rows = board.length
  const cols = board[0].length
  const protectedCells = new Set()
  for (let r = safeRow - 1; r <= safeRow + 1; r += 1) {
    for (let c = safeCol - 1; c <= safeCol + 1; c += 1) {
      if (r >= 0 && r < rows && c >= 0 && c < cols) protectedCells.add(`${r}:${c}`)
    }
  }
  let candidates = board.flat().filter((cell) => !protectedCells.has(`${cell.row}:${cell.col}`))
  if (candidates.length < mines) candidates = board.flat().filter((cell) => cell.row !== safeRow || cell.col !== safeCol)
  for (let i = candidates.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1))
    ;[candidates[i], candidates[j]] = [candidates[j], candidates[i]]
  }
  candidates.slice(0, mines).forEach((cell) => { cell.isMine = true })
  board.flat().forEach((cell) => { cell.adjacent = neighbors(board, cell.row, cell.col).filter((item) => item.isMine).length })
  return board
}

export function neighbors(board, row, col) {
  const result = []
  for (let r = row - 1; r <= row + 1; r += 1) {
    for (let c = col - 1; c <= col + 1; c += 1) {
      if (r >= 0 && r < board.length && c >= 0 && c < board[0].length && (r !== row || c !== col)) result.push(board[r][c])
    }
  }
  return result
}

export function openArea(board, row, col) {
  const first = board[row][col]
  if (first.isFlagged || first.isOpen) return board
  const queue = [first]
  const visited = new Set()
  while (queue.length) {
    const cell = queue.shift()
    const key = `${cell.row}:${cell.col}`
    if (visited.has(key) || cell.isFlagged || cell.isMine) continue
    visited.add(key)
    cell.isOpen = true
    if (cell.adjacent === 0) neighbors(board, cell.row, cell.col).forEach((next) => { if (!next.isOpen && !next.isFlagged && !next.isMine) queue.push(next) })
  }
  return board
}

export function isWon(board) { return board.flat().every((cell) => cell.isMine || cell.isOpen) }
export function cloneBoard(board) { return board.map((row) => row.map((cell) => ({ ...cell }))) }
