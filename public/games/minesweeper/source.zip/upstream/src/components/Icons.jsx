export function Icon({ name, size = 20 }) {
  const paths = {
    flag: <><path d="M6 21V4"/><path d="M6 5h10l-2 4 2 4H6"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    trophy: <><path d="M8 4h8v5a4 4 0 0 1-8 0V4Z"/><path d="M8 6H5v2a3 3 0 0 0 3 3M16 6h3v2a3 3 0 0 1-3 3M12 13v4M8 20h8M10 17h4"/></>,
    refresh: <><path d="M20 7v5h-5"/><path d="M18 16a8 8 0 1 1 1-8l1 4"/></>,
    install: <><path d="M12 3v12"/><path d="m8 11 4 4 4-4"/><path d="M5 18v2h14v-2"/></>,
    pause: <><path d="M9 5v14M15 5v14"/></>,
    play: <path d="m9 6 9 6-9 6Z"/>,
    moon: <path d="M20 15a8 8 0 0 1-11-11 9 9 0 1 0 11 11Z"/>,
    sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></>,
    help: <><circle cx="12" cy="12" r="9"/><path d="M9.7 9a2.5 2.5 0 1 1 3.3 2.4c-.7.3-1 1-1 1.6M12 17h.01"/></>,
    close: <path d="m7 7 10 10M17 7 7 17"/>,
  }
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>
}
