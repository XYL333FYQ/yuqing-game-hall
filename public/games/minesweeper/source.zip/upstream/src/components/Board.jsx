import { Icon } from './Icons.jsx'

export default function Board({ board, status, onOpen, onFlag, onChord, t }) {
  const cols = board[0]?.length ?? 0
  return (
    <div className="board-scroll" aria-label={t.boardRegion}>
      <div className={`board ${status === 'paused' ? 'is-paused' : ''}`} style={{ '--cols': cols }} role="grid">
        {board.flat().map((cell) => {
          const showMine = cell.isMine && (cell.isOpen || status === 'lost')
          const className = ['cell', cell.isOpen ? 'open' : 'covered', cell.isFlagged ? 'flagged' : '', showMine ? 'mine' : ''].join(' ')
          return (
            <button className={className} key={`${cell.row}-${cell.col}`} role="gridcell"
              aria-label={t.cellLabel({ row: cell.row + 1, col: cell.col + 1, flagged: cell.isFlagged })}
              onClick={() => onOpen(cell.row, cell.col)} onDoubleClick={() => onChord(cell.row, cell.col)}
              onContextMenu={(event) => { event.preventDefault(); onFlag(cell.row, cell.col) }}>
              {cell.isFlagged && !cell.isOpen ? <span className="flag-symbol">⚑</span> : null}
              {showMine ? <span className="mine-symbol">✹</span> : null}
              {cell.isOpen && !cell.isMine && cell.adjacent > 0 ? <span className={`number n${cell.adjacent}`}>{cell.adjacent}</span> : null}
            </button>
          )
        })}
        {status === 'paused' ? <div className="pause-cover"><Icon name="pause" size={30}/><strong>{t.gamePaused}</strong><span>{t.resumeHint}</span></div> : null}
      </div>
    </div>
  )
}
