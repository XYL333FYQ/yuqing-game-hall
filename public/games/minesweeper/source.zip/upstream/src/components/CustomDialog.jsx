import { Icon } from './Icons.jsx'

const limits = { rows: [5, 30], cols: [5, 40], mines: [1, 999] }

export default function CustomDialog({ values, onChange, onClose, onStart, t }) {
  function update(key, next) {
    const [min, max] = limits[key]
    const value = Math.max(min, Math.min(max, Number(next) || min))
    const maxMines = key === 'rows' || key === 'cols'
      ? (key === 'rows' ? value : values.rows) * (key === 'cols' ? value : values.cols) - 1
      : values.rows * values.cols - 1
    onChange({ ...values, [key]: value, mines: Math.min(key === 'mines' ? value : values.mines, maxMines) })
  }
  return (
    <div className="dialog-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section className="dialog" role="dialog" aria-modal="true" aria-labelledby="custom-title">
        <div className="dialog-title"><div><span>{t.createBoard}</span><h2 id="custom-title">{t.customDifficulty}</h2></div><button className="icon-button" onClick={onClose} aria-label={t.close}><Icon name="close"/></button></div>
        <p>{t.customDescription}</p>
        <div className="custom-fields">
          {['rows', 'cols', 'mines'].map((key) => (
            <label key={key}><span>{t[key]}</span><div className="stepper"><button onClick={() => update(key, values[key] - 1)} aria-label={t.decrease}>−</button><input type="number" value={values[key]} min={limits[key][0]} max={key === 'mines' ? values.rows * values.cols - 1 : limits[key][1]} onChange={(event) => update(key, event.target.value)}/><button onClick={() => update(key, values[key] + 1)} aria-label={t.increase}>＋</button></div></label>
          ))}
        </div>
        <button className="primary-button dialog-start" onClick={onStart}>{t.startGame}</button>
      </section>
    </div>
  )
}
