# Minesweeper

A polished, installable, and offline-ready Minesweeper game built with React and Vite. Play instantly in the browser, install it as a desktop app, or run it locally—no account or backend required.

## Play Online

**[Launch Minesweeper](https://junjie-xu-lab.github.io/minesweeper/)**

The game supports both English and Simplified Chinese. It selects a language from your browser on the first visit, and you can switch languages at any time from the header. Your preference is saved locally.

On supported versions of Edge and Chrome, use the in-game **Install app** button to add Minesweeper to your desktop or Start menu. The installed app runs in its own window and works offline.

![Minesweeper desktop interface](docs/images/gameplay-desktop.png)

## Features

- English and Simplified Chinese interface with automatic language detection
- Beginner (9×9, 10 mines), Intermediate (16×16, 40 mines), and Expert (16×30, 99 mines)
- Custom board dimensions and mine counts
- First-click safety, including neighboring cells when board capacity allows
- Automatic empty-area expansion, right-click flags, and number chording
- Timer, remaining-mine counter, and per-difficulty local best times
- Pause/resume, restart, dark/light themes, and keyboard shortcuts
- Installable Progressive Web App with offline support and automatic updates
- Responsive desktop and mobile layouts with scrollable large boards
- Accessible labels for the board, controls, cells, and dialogs

## Controls

| Input | Action |
| --- | --- |
| Left click | Reveal a cell |
| Right click | Place or remove a flag |
| Double-click a revealed number | Reveal surrounding cells when the adjacent flag count matches |
| `P` or Space | Pause or resume |
| `R` | Start a new game |
| `?` | Open the gameplay guide |

## Local Development

Requirements: [Node.js](https://nodejs.org/) 18 or later.

```powershell
npm install
npm run dev
```

Open the URL printed by Vite, usually `http://localhost:5173`.

On Windows systems where PowerShell blocks `npm.ps1`, use `npm.cmd`:

```powershell
npm.cmd install
npm.cmd run dev
```

## Test and Build

```powershell
npm test
npm run build
npm run preview
```

The production bundle is written to `dist/`. It includes the web app manifest, generated Service Worker, icons, and offline precache.

## GitHub Pages Deployment

The repository includes [`.github/workflows/deploy.yml`](.github/workflows/deploy.yml). Every push to `main` runs the tests, creates a production build, and deploys it to GitHub Pages.

For a new fork or repository:

1. Open **Settings → Pages**.
2. Set **Build and deployment → Source** to **GitHub Actions**.
3. Push to `main` and follow the workflow in the **Actions** tab.
4. Open the deployed Pages URL and verify the game, language switcher, installation prompt, and offline startup.

## Project Structure

```text
.
├─ .github/workflows/       # Automated GitHub Pages deployment
├─ docs/                    # Screenshots and release checklist
├─ public/                  # PWA icons and favicon
├─ src/
│  ├─ components/           # Board, dialog, and icon components
│  ├─ game/                 # Game engine and automated tests
│  ├─ App.jsx               # Game state and interactions
│  ├─ i18n.js               # English and Chinese language resources
│  └─ styles.css            # Themes, layout, and responsive styles
├─ index.html
├─ package.json
└─ vite.config.js
```

## FAQ

### Why can the first click never hit a mine?

The game uses first-click protection. On standard board sizes, the selected cell and all eight neighboring cells are excluded from mine placement.

### Where are preferences and best times stored?

They are stored in the browser's `localStorage`. Clearing site data removes those records.

### Why does the Expert board scroll on a phone?

The board scrolls inside its own region so every cell remains large enough to read and tap accurately.

### Does the game require an internet connection?

The first visit requires a connection. After the PWA assets are cached, the installed app and previously loaded site can run offline.

## Release Checklist

See [`docs/GITHUB_CHECKLIST.md`](docs/GITHUB_CHECKLIST.md) for the publishing and verification checklist.

## Maintainer

[junjie-xu-lab](https://github.com/junjie-xu-lab)

## License

Licensed under the [MIT License](LICENSE).
