# GitHub Release Checklist

- [x] Add the desktop screenshot to `docs/images/` and embed it in the README
- [ ] Add a mobile screenshot
- [x] Confirm the repository name: `minesweeper`
- [x] Add the MIT License
- [x] Add English and Simplified Chinese game interfaces
- [x] Convert all repository documentation to English
- [x] Run `npm test` and `npm run build`
- [x] Add the GitHub Pages deployment workflow
- [x] Configure Pages to use GitHub Actions
- [x] Add the public Pages URL to the README
- [x] Verify both languages on desktop and mobile
- [ ] Verify the install prompt and offline startup in Edge or Chrome
- [ ] Create a release with screenshots, features, and the play link
- [ ] Confirm the repository contains no dependencies, credentials, tokens, or machine-specific paths

## Release Notes Draft

```markdown
## Minesweeper v1.1.0

Minesweeper is an installable, offline-ready browser game with English and Simplified Chinese interfaces.

### Highlights

- Beginner, Intermediate, Expert, and custom boards
- First-click safety, flags, number chording, timer, and local best times
- English and Simplified Chinese with automatic browser-language detection
- Dark and light themes
- Installable Progressive Web App with offline support
- Responsive desktop and mobile layouts

### Play

Open https://junjie-xu-lab.github.io/minesweeper/ or install the app from a supported browser.
```
