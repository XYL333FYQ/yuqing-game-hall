# 自由布阵塔防

Upstream: https://github.com/oldj/html5-tower-defense
Pinned commit: e3e009c7673121e98d6ff02c85fb442c774b6391
License: MIT, see runtime/games/classic-tower-defense/LICENSE.

runtime/ is the exact adapted static package. Run
python -m http.server 8080 --directory runtime
and open http://localhost:8080/games/classic-tower-defense/index.html .

upstream/ contains the preferred source at the recorded commit. Normal hall
builds serve committed runtimes without rebuilding third-party programs.
adaptations/ contains import-games.mjs, pinned build inputs and the source
packager. See adaptations/README.md for rebuilding the two compiled games;
prepare-builds.mjs selects Chinese by default for Minesweeper and replaces
obsolete node-sass for BreakLock. The original sources remain separate.
For other games the readable runtime is also the editable adapted source.
Chinese Chess originally uses GBK: import-games.mjs converts it to UTF-8.

Unused fonts/audio omitted from the archive:

