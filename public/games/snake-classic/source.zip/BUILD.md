# 贪吃蛇挑战

Upstream: https://github.com/patorjk/JavaScript-Snake
Pinned commit: 7c80eddde2de6af669e6ae5133ba8ae60a8d7fb9
License: MIT, see runtime/games/snake-classic/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/snake-classic/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:

