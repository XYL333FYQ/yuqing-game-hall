# 摩天楼建造

Upstream: https://github.com/iamkun/tower_game
Pinned commit: c6fa84afe179b661fa71cf7cc8788d0c47ca2875
License: MIT; Zepto MIT, see runtime/games/tower-building/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/tower-building/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:
assets/wenxue.eot
assets/wenxue.svg
assets/wenxue.ttf
assets/wenxue.woff
