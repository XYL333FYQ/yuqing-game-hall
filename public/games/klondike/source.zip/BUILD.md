# 经典纸牌接龙

Upstream: https://github.com/rjanjic/js-solitaire
Pinned commit: f67a187afd2cff31ed8d04929d544fa2f032f457
License: MIT, see runtime/games/klondike/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/klondike/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:

