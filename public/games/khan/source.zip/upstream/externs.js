/** @typedef {!Object} */
var localStorage;
