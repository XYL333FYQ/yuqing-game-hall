---
genres:
  - card-games
  - strategy
  - roguelike
# See github.com/js13kGames/hello-world for supported frontmatter
---

Use your deck of tiles to build a path covering all the lands spreading the good word while also pillaging some rewards as additions to your deck or sometimes even blessing you with some powerful abilities.

Played with mouse (or touch) only.