# 格子大陆 / Gridland

Upstream: https://github.com/doublespeakgames/gridland
Commit: 06af02c3af7062aead04a1e6f67b6e59f3e4b6a1
License: MPL-2.0 (upstream license retained)

runtime/ contains the exact readable, adapted HTML/CSS/JavaScript and all game
assets. Serve it with `python -m http.server 8080 --directory runtime` and open
http://localhost:8080/games/gridland/index.html . No platform or VPS is needed.

upstream/ contains the pinned preferred source, original build files and credit
notices. See its README and package.json for the original development workflow.
Generated/minified originals remain included, alongside the readable runtime.

For the four TypeScript adaptations, install this hall's pinned frontend tools
(Vite 8 / TypeScript), place the original source checkout at the recorded path,
then run `node games/expansion/build-adapted.mjs gridland <source-path>`.
The supplied overrides replace the corresponding original src files; Casual
Crusade instead removes the first redundant super(0, 0, 0, 0) in src/pile.ts.
Use publicDir:false when building: copying a development public/index.html can
overwrite the production entry. Daily hall builds serve the committed runtimes.

For other games, runtime/ is the editable adapted source: preserve the shared
localization scripts, relative paths and SOURCE.md; ADAPTATIONS.json describes
the changes. Original build scripts are optional for these static runtimes.

The omitted entries below are development demonstrations, compiler executables
or duplicate unchanged audio. Runtime audio is supplied in runtime/; complete
program source and the assets needed to run the adapted game remain included.
deploy/audio/blockdown.mp3
deploy/audio/blockdown.ogg
deploy/audio/blockup.mp3
deploy/audio/blockup.ogg
deploy/audio/blunt.mp3
deploy/audio/blunt.ogg
deploy/audio/bomb.mp3
deploy/audio/bomb.ogg
deploy/audio/charge.mp3
deploy/audio/charge.ogg
deploy/audio/click.mp3
deploy/audio/click.ogg
deploy/audio/dannihilate.mp3
deploy/audio/dannihilate.ogg
deploy/audio/dexplode.mp3
deploy/audio/dexplode.ogg
deploy/audio/die.mp3
deploy/audio/die.ogg
deploy/audio/dshoot.mp3
deploy/audio/dshoot.ogg
deploy/audio/equip.mp3
deploy/audio/equip.ogg
deploy/audio/fire.mp3
deploy/audio/fire.ogg
deploy/audio/fireexplode.mp3
deploy/audio/fireexplode.ogg
deploy/audio/freeze.mp3
deploy/audio/freeze.ogg
deploy/audio/haste.mp3
deploy/audio/haste.ogg
deploy/audio/heal.mp3
deploy/audio/heal.ogg
deploy/audio/ice.mp3
deploy/audio/ice.ogg
deploy/audio/land.mp3
deploy/audio/land.ogg
deploy/audio/levelup.mp3
deploy/audio/levelup.ogg
deploy/audio/lichspell.mp3
deploy/audio/lichspell.ogg
deploy/audio/match-test.mp3
deploy/audio/match-test.ogg
deploy/audio/open.mp3
deploy/audio/open.ogg
deploy/audio/phasechange.mp3
deploy/audio/phasechange.ogg
deploy/audio/reset.mp3
deploy/audio/reset.ogg
deploy/audio/roar.mp3
deploy/audio/roar.ogg
deploy/audio/shoot.mp3
deploy/audio/shoot.ogg
deploy/audio/slash.mp3
deploy/audio/slash.ogg
deploy/audio/teleport.mp3
deploy/audio/teleport.ogg
deploy/audio/theme-boss.mp3
deploy/audio/theme-boss.ogg
deploy/audio/theme-day-0.mp3
deploy/audio/theme-day-0.ogg
deploy/audio/theme-day-1.mp3
deploy/audio/theme-day-1.ogg
deploy/audio/theme-day-2.mp3
deploy/audio/theme-day-2.ogg
deploy/audio/theme-day-3.mp3
deploy/audio/theme-day-3.ogg
deploy/audio/theme-day.mp3
deploy/audio/theme-day.ogg
deploy/audio/theme-night.mp3
deploy/audio/theme-night.ogg
deploy/audio/tileclick.mp3
deploy/audio/tileclick.ogg
deploy/audio/tilexplode.mp3
deploy/audio/tilexplode.ogg
deploy/audio/wing.mp3
deploy/audio/wing.ogg
tools/compiler.jar
tools/js.jar
www/audio/blockdown.mp3
www/audio/blockdown.ogg
www/audio/blockup.mp3
www/audio/blockup.ogg
www/audio/blunt.mp3
www/audio/blunt.ogg
www/audio/bomb.mp3
www/audio/bomb.ogg
www/audio/charge.mp3
www/audio/charge.ogg
www/audio/click.mp3
www/audio/click.ogg
www/audio/dannihilate.mp3
www/audio/dannihilate.ogg
www/audio/dexplode.mp3
www/audio/dexplode.ogg
www/audio/die.mp3
www/audio/die.ogg
www/audio/dshoot.mp3
www/audio/dshoot.ogg
www/audio/equip.mp3
www/audio/equip.ogg
www/audio/fire.mp3
www/audio/fire.ogg
www/audio/fireexplode.mp3
www/audio/fireexplode.ogg
www/audio/freeze.mp3
www/audio/freeze.ogg
www/audio/haste.mp3
www/audio/haste.ogg
www/audio/heal.mp3
www/audio/heal.ogg
www/audio/ice.mp3
www/audio/ice.ogg
www/audio/land.mp3
www/audio/land.ogg
www/audio/levelup.mp3
www/audio/levelup.ogg
www/audio/lichspell.mp3
www/audio/lichspell.ogg
www/audio/match-test.mp3
www/audio/match-test.ogg
www/audio/open.mp3
www/audio/open.ogg
www/audio/phasechange.mp3
www/audio/phasechange.ogg
www/audio/reset.mp3
www/audio/reset.ogg
www/audio/roar.mp3
www/audio/roar.ogg
www/audio/shoot.mp3
www/audio/shoot.ogg
www/audio/slash.mp3
www/audio/slash.ogg
www/audio/teleport.mp3
www/audio/teleport.ogg
www/audio/theme-boss.mp3
www/audio/theme-boss.ogg
www/audio/theme-day-0.mp3
www/audio/theme-day-0.ogg
www/audio/theme-day-1.mp3
www/audio/theme-day-1.ogg
www/audio/theme-day-2.mp3
www/audio/theme-day-2.ogg
www/audio/theme-day-3.mp3
www/audio/theme-day-3.ogg
www/audio/theme-day.mp3
www/audio/theme-day.ogg
www/audio/theme-night.mp3
www/audio/theme-night.ogg
www/audio/tileclick.mp3
www/audio/tileclick.ogg
www/audio/tilexplode.mp3
www/audio/tilexplode.ogg
www/audio/wing.mp3
www/audio/wing.ogg
