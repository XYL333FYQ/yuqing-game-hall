# 舰队猎手

Upstream: https://github.com/Shahir-47/Battleship
Pinned commit: 7d38710ba34253d59d5d882f53ace682c23cce3b
License: MIT; normalize.css MIT, see runtime/games/battleship/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/battleship/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:

