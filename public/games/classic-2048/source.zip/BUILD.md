# 2048 合成

Upstream: https://github.com/gabrielecirulli/2048
Pinned commit: 478b6ec346e3787f589e4af751378d06ded4cbbc
License: MIT, see runtime/games/classic-2048/LICENSE.

runtime/ is the exact adapted static package. Run
python -m http.server 8080 --directory runtime
and open http://localhost:8080/games/classic-2048/index.html .

upstream/ contains the preferred source at the recorded commit. Normal hall
builds serve committed runtimes without rebuilding third-party programs.
adaptations/ contains import-games.mjs, pinned build inputs and the source
packager. See adaptations/README.md for rebuilding the two compiled games;
prepare-builds.mjs selects Chinese by default for Minesweeper and replaces
obsolete node-sass for BreakLock. The original sources remain separate.
For other games the readable runtime is also the editable adapted source.
Chinese Chess originally uses GBK: import-games.mjs converts it to UTF-8.

Unused fonts/audio omitted from the archive:
style/fonts/ClearSans-Bold-webfont.eot
style/fonts/ClearSans-Bold-webfont.svg
style/fonts/ClearSans-Bold-webfont.woff
style/fonts/ClearSans-Light-webfont.eot
style/fonts/ClearSans-Light-webfont.svg
style/fonts/ClearSans-Light-webfont.woff
style/fonts/ClearSans-Regular-webfont.eot
style/fonts/ClearSans-Regular-webfont.svg
style/fonts/ClearSans-Regular-webfont.woff
style/fonts/clear-sans.css
