!function () {
    "use strict";
    function t(t, e, s) { return t * (1 - s) + e * s; }
    function e(t) { return t * (2 - t); }
    function s(t) { return t < .5 ? 2 * t * t : 2 * t * (2 - t) - 1; }
    function c(t, e, s, c, n) { c = BigInt(c); for (let i = 0; i < s; ++i)
        for (let s = 0; s < e; ++s)
            n(s, i, Number(t % c)), t /= c; }
    class n {
        constructor(t = 0, e = 0) { this.x = t, this.y = e; }
        set(t, e) { return this.x = t, this.y = e, this; }
        copy(t) { return this.x = t.x, this.y = t.y, this; }
        add(t) { return this.x += t.x, this.y += t.y, this; }
        length() { return Math.hypot(this.x, this.y); }
        distanceSquared(t) { return (this.x - t.x) ** 2 + (this.y - t.y) ** 2; }
    }
    const i = new n, o = new n;
    class f extends n {
        constructor(t, e, s) { super(e, s), this.type = t, this.oldPosition = new n(e, s); }
    }
    class r {
        constructor(t) { (this.pieces = t).forEach((t => t.cluster = this)); }
    }
    class a {
        constructor(t, e) { this.width = t, this.height = e, this.pieces = {}, this.positions = Array.from({ length: e }, (() => Array.from({ length: t }, (() => [])))); }
        createPiece(t, e, s) { const c = new f(t, e, s); return (this.pieces[t] ??= []).push(c), this.positions[s][e].push(c), c; }
        discardPiece(t) { let e = this.pieces[t.type]; e.splice(e.indexOf(t), 1), e = this.positions[t.y][t.x], e.splice(e.indexOf(t), 1); }
        putPiece(t, e, s) { const c = this.positions[t.y][t.x]; c.splice(c.indexOf(t), 1), this.positions[s][e].push(t.set(e, s)); }
        getBorderingPieces(t, e) { return this.pieces[e]?.filter((e => 1 === e.distanceSquared(t))); }
        getGroup(t) { const e = new Set([t]), s = [t]; for (; s.length;) {
            const t = s.pop();
            this.getBorderingPieces(t, t.type).forEach((t => { e.has(t) || (e.add(t), s.push(t)); }));
        } return e; }
        buildClusters(t) { const e = new Set(this.pieces[t]); for (const t of e) {
            new r([...this.getGroup(t)]).pieces.forEach((t => e.delete(t)));
        } }
        load(t) { c(t, this.width, this.height, 7, ((t, e, s) => { 1 !== s && (0 !== s && --s, this.createPiece(s, t, e)); })); }
    }
    function h(t) { return 440 * 2 ** ((t - 69) / 12); }
    const u = 4294967295;
    function d(t) { return (2 * t.randomUint32() - u) / u; }
    class l {
        constructor(t, e, s) { this.channels = t, this.sampleRate = e, this.prng = s; }
        generateReverb(t, e, s, c, n = 0, i = -60) { const o = Math.round(c * this.sampleRate), f = Math.round(n * this.sampleRate), r = (10 ** (i / 10)) ** (1 / (o - 1)); const a = 1 / (f - 1), h = new AudioBuffer({ length: o, numberOfChannels: this.channels, sampleRate: this.sampleRate }); for (const t of function (t) { const e = []; for (let s = 0; s < t.numberOfChannels; ++s)
            e[s] = t.getChannelData(s); return e; }(h)) {
            for (let e = 0; e < o; ++e)
                t[e] = d(this.prng) * r ** e;
            for (let e = 0; e < f; ++e)
                t[e] *= a * e;
        } !function (t, e, s, c, n) { const i = new OfflineAudioContext(e.numberOfChannels, e.length, e.sampleRate), o = new BiquadFilterNode(i, { type: "lowpass", Q: 1e-4, frequency: s }); o.connect(i.destination), o.frequency.exponentialRampToValueAtTime(c, n); const f = new AudioBufferSourceNode(i, { buffer: e }); f.connect(o), f.start(), i.oncomplete = e => { t(e.renderedBuffer); }, i.startRendering(); }(t, h, e, s, c); }
    }
    const b = [[64, 0, .5, 40, 0, .25, 67, .04, .5, 71, .08, .5, 76, .12, .5, 47, .25, .5, 71, .5, 1.25, 52, .5, .75, 55, .75, 1], [59, 0, .25, 76, .25, .5, 55, .25, .5, 78, .5, .75, 52, .5, .75, 79, .75, 1, 47, .75, 1], [69, 0, .5, 45, 0, .25, 72, .04, .5, 76, .08, .5, 81, .12, .5, 52, .25, .5, 76, .5, 1.25, 57, .5, .75, 60, .75, 1], [64, 0, .25, 81, .25, .5, 60, .25, .5, 83, .5, .75, 57, .5, .75, 86, .75, 1, 52, .75, 1], [69, 0, .75, 50, 0, .25, 74, .04, .75, 78, .08, .75, 81, .12, .75, 57, .25, .5, 62, .5, .75, 79, .75, 1, 66, .75, 1], [78, 0, .25, 69, 0, .25, 79, .25, .375, 66, .25, .5, 78, .375, .625, 62, .5, .75, 74, .625, 1, 57, .75, 1], [59, 0, 1, 35, 0, .25, 63, .04, 1, 66, .08, 1, 71, .12, 1, 42, .25, .5, 47, .5, .75, 51, .75, 1], [63, 0, 1, 54, 0, .25, 66, .04, 1, 71, .08, 1, 75, .12, 1, 51, .25, .5, 47, .5, .75, 42, .75, 1], 0, 1, 2, 3, 4, 5, [64, 0, 2, 40, 0, .25, 67, .04, 2, 71, .08, 2, 76, .12, 2, 47, .25, .5, 52, .5, .75, 55, .75, 1], [64, 0, .25, 59, .25, .5, 55, .5, .75, 52, .75, 1], [64, 0, .125, 40, 0, .25, 71, .125, .25, 69, .25, .375, 47, .25, .5, 71, .375, .5, 74, .5, .625, 52, .5, .75, 71, .625, .75, 69, .75, .875, 55, .75, 1, 71, .875, 1], [64, 0, .125, 59, 0, .25, 71, .125, .25, 69, .25, .375, 55, .25, .5, 71, .375, .5, 74, .5, .625, 52, .5, .75, 71, .625, .75, 69, .75, .875, 47, .75, 1, 71, .875, 1], [66, 0, .125, 36, 0, .25, 67, .125, .25, 66, .25, .375, 43, .25, .5, 67, .375, .5, 71, .5, .625, 48, .5, .75, 67, .625, .75, 66, .75, .875, 52, .75, 1, 67, .875, 1], [66, 0, .125, 55, 0, .25, 67, .125, .25, 66, .25, .375, 52, .25, .5, 67, .375, .5, 71, .5, .625, 48, .5, .75, 67, .625, .75, 66, .75, .875, 43, .75, 1, 67, .875, 1], [62, 0, .125, 38, 0, .25, 69, .125, .25, 67, .25, .375, 45, .25, .5, 69, .375, .5, 74, .5, .625, 50, .5, .75, 69, .625, .75, 67, .75, .875, 54, .75, 1, 69, .875, 1], [62, 0, .125, 57, 0, .25, 69, .125, .25, 67, .25, .375, 54, .25, .5, 69, .375, .5, 74, .5, .625, 50, .5, .75, 69, .625, .75, 67, .75, .875, 45, .75, 1, 69, .875, 1], [63, 0, .125, 35, 0, .25, 71, .125, .25, 69, .25, .375, 42, .25, .5, 71, .375, .5, 75, .5, .625, 47, .5, .75, 71, .625, .75, 69, .75, .875, 51, .75, 1, 71, .875, 1], [63, 0, .125, 54, 0, .25, 71, .125, .25, 69, .25, .375, 51, .25, .5, 71, .375, .5, 75, .5, .625, 47, .5, .75, 71, .625, .75, 69, .75, .875, 42, .75, 1, 71, .875, 1], 16, 17, 18, 19, 20, 21, 22, [63, 0, .125, 47, 0, .25, 71, .125, .25, 69, .25, .375, 51, .25, .5, 71, .375, .5, 75, .5, .625, 54, .5, .75, 71, .625, .75, 75, .75, .875, 59, .75, 1, 78, .875, 1], [64, 0, .5, 40, 0, .125, 67, .04, .5, 71, .08, .5, 76, .12, .5, 47, .125, .25, 52, .25, .375, 55, .375, .5, 71, .5, 1.25, 67, .5, 1.25, 59, .5, .625, 55, .625, .75, 52, .75, .875, 47, .875, 1], [40, 0, .125, 52, .125, .25, 76, .25, .5, 71, .25, .5, 55, .25, .375, 59, .375, .5, 78, .5, .75, 71, .5, .75, 64, .5, .625, 59, .625, .75, 79, .75, 1, 71, .75, 1, 55, .75, .875, 52, .875, 1], [69, 0, .5, 45, 0, .125, 72, .04, .5, 76, .08, .5, 81, .12, .5, 52, .125, .25, 57, .25, .375, 60, .375, .5, 76, .5, 1.25, 72, .5, 1.25, 64, .5, .625, 60, .625, .75, 57, .75, .875, 52, .875, 1], [45, 0, .125, 57, .125, .25, 81, .25, .5, 76, .25, .5, 60, .25, .375, 64, .375, .5, 83, .5, .75, 76, .5, .75, 69, .5, .625, 64, .625, .75, 86, .75, 1, 78, .75, 1, 60, .75, .875, 57, .875, 1], [69, 0, .75, 50, 0, .125, 74, .04, .75, 78, .08, .75, 81, .12, .75, 54, .125, .25, 57, .25, .375, 62, .375, .5, 66, .5, .625, 62, .625, .75, 79, .75, 1, 57, .75, .875, 50, .875, 1], [78, 0, .25, 74, 0, .25, 38, 0, .125, 45, .125, .25, 79, .25, .375, 50, .25, .375, 78, .375, .625, 54, .375, .5, 57, .5, .625, 74, .625, 1, 54, .625, .75, 50, .75, .875, 45, .875, 1], [59, 0, 1, 35, 0, .125, 63, .04, 1, 66, .08, 1, 71, .12, 1, 42, .125, .25, 47, .25, .375, 51, .375, .5, 54, .5, .625, 51, .625, .75, 47, .75, .875, 42, .875, 1], [63, 0, 1, 47, 0, .125, 66, .04, 1, 71, .08, 1, 75, .12, 1, 51, .125, .25, 54, .25, .375, 59, .375, .5, 63, .5, .625, 59, .625, .75, 54, .75, .875, 51, .875, 1], 32, 33, 34, 35, 36, 37, [64, 0, 2, 40, 0, .125, 67, .04, 2, 71, .08, 2, 76, .12, 2, 47, .125, .25, 52, .25, .375, 55, .375, .5, 59, .5, .625, 55, .625, .75, 52, .75, .875, 47, .875, 1], [40, 0, .125, 52, .125, .25, 55, .25, .375, 59, .375, .5, 64, .5, .625, 67, .625, .75, 71, .75, .875, 76, .875, 1], [79, 0, 1, 76, 0, 1, 64, 0, .125, 67, .125, .25, 71, .25, .375, 67, .375, .5, 71, .5, 1], [78, 0, .5, 74, 0, .5, 62, 0, .25, 69, .25, .5, 81, .5, .75, 74, .5, 1, 86, .75, 1], [88, 0, 2, 84, 0, 2, 67, 0, 1.5, 60, 0, 1.5], [60, .5, .75, 67, .75, 1], [91, 0, 1, 88, 0, 1, 83, 0, 1, 79, 0, .25, 76, .25, .5, 71, .5, .75, 67, .75, 1], [81, 0, .3125, 62, 0, 1, 86, .04, .3125, 90, .08, .3125, 86, .3125, .625, 81, .625, .9375, 86, .9375, 1.25], [64, .25, 2, 71, .29, 2, 76, .33, 2, 79, .37, 2, 83, .41, 2, 88, .45, 2]];
    function w(t, e) { if (e > 54)
        return; const s = b[e].push ? b[e] : b[b[e]]; for (let e = 0; e < s.length; e += 3)
        t(s[e], s[e + 1], s[e + 2]); }
    const v = 120 / 70, S = new class {
        async initialize(t) { if (!this.initialized) {
            if (this.con ??= new AudioContext, "running" !== this.con.state) {
                try {
                    await this.con.resume();
                }
                catch (t) {
                    return;
                }
                if (this.initialized)
                    return;
            }
            t?.(this.con), this.initialized = 1;
        } }
    }, p = new class {
        constructor(t) { this.state = 0 | t; }
        randomUint32() { let t = this.state = this.state + 1831565813 | 0; return t = Math.imul(t ^ t >>> 15, 1 | t), t ^= t + Math.imul(t ^ t >>> 7, 61 | t), (t ^ t >>> 14) >>> 0; }
        random() { return this.randomUint32() / 2 ** 32; }
    }(960);
    let m, g;
    const M = t => e => { m = new GainNode(e, { gain: .3333 }); const s = new ConvolverNode(e), c = new GainNode(e, { gain: .5 }), n = new GainNode(e, { gain: .3333 }); m.connect(s), m.connect(c), s.connect(n), c.connect(e.destination), n.connect(e.destination); new l(2, e.sampleRate, p).generateReverb((c => { s.buffer = c, t ? (g = e.currentTime + .05, E(), setInterval(E, 999)) : L(0); }), 16e3, 1e3, 2 * v, 1e-5, -90); };
    function A(t) { m && (m.gain.value = t ? 0 : .3333); }
    function y(t, e, s) { e *= v, s *= v; const c = new OscillatorNode(S.con, { type: "square", frequency: h(t) }); (function (t, e) { const s = new GainNode(S.con, { gain: .5 }); return s.gain.setValueAtTime(.5, g + e), s.gain.exponentialRampToValueAtTime(1e-5, g + e + 2 * v), t.connect(s), s; })(c, e).connect(m), c.start(g + e), c.stop(g + s); }
    let C = -1;
    function E() { let t = S.con.currentTime - g + 4, e = (C + 1) * v; if (!(e > t))
        for (t += 4; e < t;) {
            const t = ++C;
            w(((e, s, c) => y(e, s + t, c + t)), t % 57), e += v;
        } }
    function L(t) { if (m)
        switch (t) {
            case 0:
                O(91, 0, .04);
                break;
            case 1:
                O(76, 0, .05), O(79, .05, .05), O(83, .1, .1);
                break;
            case 2:
                O(83, 0, .05), O(79, .05, .05), O(76, .1, .1);
                break;
            case 3: O(74, 0, .05), O(76, .05, .05), O(79, .1, .05), O(83, .15, .05), O(86, .2, .05), O(88, .25, .1);
        } }
    function O(t, e, s) { e += S.con.currentTime; const c = new OscillatorNode(S.con, { type: "square", frequency: h(t) }); c.connect(m), c.start(e), c.stop(e + s); }
    const k = [35, 36, 38, 39, 40, 42, 43, 45];
    function N() { if (!m)
        return; const t = S.con, e = t.currentTime, s = h(k[function (t, e) { const s = u - u % e; for (;;) {
        const c = t.randomUint32();
        if (c < s)
            return c % e;
    } }(p, k.length)]), c = new OscillatorNode(t, { type: "square", frequency: s }), n = new GainNode(t); c.connect(n), n.connect(m), c.frequency.setValueAtTime(s, e), n.gain.setValueAtTime(1, e), c.frequency.exponentialRampToValueAtTime(.5 * s, e + .2), n.gain.exponentialRampToValueAtTime(1e-5, e + .2), c.start(e), c.stop(e + .2); }
    const T = [, "0a05773e0b74b0371f02a6eb5dea9e6", "07057ffaad6f2661fea04ea", "0805ab78ef52943bf9d44806c", "0c05291e93482750939b387a1cf227159cfb5", "070812c8d3595b377e96ef4aaaf849f7c7ac2a", "0b054c3346f46f60b6eb689cf5911db8c7", "09052c0a0c3a11e2df55b5b4a46d1", "0a0a9a3d348ebb91b3fdd5392989e6e48280b767f7abd16628394fd76dca5f3a5f", "0a088b588dbd8b8d12a6b6cf115e3616491f022796b1c5531ed9", "0b0626c342fa69752fe1444f1eb4a23e4f81ad9c", "0d08146eed2200f8076ba28e6790f3a49381687d319acf2d2c396dd39189a032", "0e0755f2fd57b0666d3b250d1085faf6786f89fe1236509251103d1eec583b", "0a09820ef83d1bfe8c558601a28a2edb322fbc288148a11ba997cf0", "0c0d74b4615140b03be5ac9dc1e9ceca9f2e47a7408c85a25d406180ce4f33969ef77152c649f51ecf2f7146a986bceb938b45d4", "0c0bb3cb3b721d397d7bb165728c74eb52e34eaace95545b2eccf34ff567bd7852b3e4dc45f3d2b07ed3bbc", "120d48f5340829c0054829f082c37235cf198a27499414652d486f7667a38fe5180101bbf4c5295abe775669b1b0d0bbcff235c3588d8bd242522ad99cb5b95a06e1dc254739d9f8b73a582a4c", "110c1b657fe7d222eb4ae2a9873b36084d7e192d41c422acd2df1cce8a24ee15c983a4fe25d297b60a8cfa4b697255004e436d2398ef23ca5e1d303c871c4f71a539ef", "2210bb93abd355457213a83d4c3ccd6ecc6e9edc0f417c14e83fc99b589799e7f6a63b7bc350856c052eb27687ec04acb0d316cb09e9ebfbf9fce826e581013886de146c8a2bc3da08adb1012b698f23a2028d938e73732382eef6053b82f4c22265bb97c2985b27a8681686f76f01244ab0ea7aad7660c1ccc686b33c0203a9f303201f298a93c4ae25709da98e984cf38788e4e2e85697dffa5c53611b18aef86d00443542c8e0c6c63fb0de1ba18a66e0fd32", "0f09b3cd90ef3c126095fe29bd6f411d6bfa0433c5c188d98e721e934991fd4fab1dbdaf66c7c3a36c279cd"];
    function x(t, e, s = 0) { t.phase = e, t.phaseTtl = (t.oldTtl = s) - 1; }
    function P(t, e) { if (t.oldTtl = t.phaseTtl, t.phaseTtl > 0)
        return void --t.phaseTtl; const s = t.phase << 1, c = e[s]; if (!c)
        return; const n = t.phase; return x(t, c, e[1 | s]), n; }
    function R(e, s, c) { return 1 - t(e.oldTtl, e.phaseTtl, c) / s; }
    const q = 0x7c6667c0c67ad604e6e9cc1bffeb1011d39cc0e9ce730318c6780fe38fe04df39be0e9ce6e00df39bc0e9ce6e04f7fbcc11afffb07c6318c1359d7303b78c7c1e6319e04e7f9cc1e9ec7e00c6f1fc1f1bc7f03e739bc0e98e6e03e6f9bc13fce6en, V = 5, G = 6, I = 65;
    class D {
        constructor(t) { this.x = this.y = 0, this.plane = t; }
        setPosition(t) { const e = this.plane.getBoundingClientRect(); this.x = t.clientX - e.left, this.y = t.clientY - e.top; }
        addEventListeners(t) { t.addEventListener("mousedown", (t => { t.preventDefault(), this.held = 1, this.setPosition(t); })), t.addEventListener("mousemove", (t => { t.preventDefault(), this.setPosition(t); })), t.addEventListener("mouseup", (t => { t.preventDefault(), this.held = 0; })), t.addEventListener("mouseleave", (t => { this.held = 0; })), t.addEventListener("touchstart", (t => { t.preventDefault(), this.held = 1, this.setPosition(t.targetTouches[0]); })), t.addEventListener("touchmove", (t => { t.preventDefault(), this.setPosition(t.targetTouches[0]); })), t.addEventListener("touchend", (t => { t.preventDefault(), this.held = 0; })), t.addEventListener("touchcancel", (t => { this.held = 0; })); }
    }
    const B = { AoL: 1, AoU: 2, AoR: 3, AoD: 4, KA: 5, KW: 6, KD: 7, KS: 8, KR: 9, Sc: 10 };
    const F = new class {
        constructor(t, e, s, c = 2, n) { t ??= document.createElement("canvas"), this.canvas = t, this.con = t.getContext("2d"), this.height = s, this.width = e, t.height = c * s, t.width = c * e, this.con.scale(c, c), n?.(this.con, e, s); }
    }(document.querySelector("#c"), 960, 540), K = F.con;
    K.lineWidth = 1.5;
    const U = new class {
        constructor(t, e, s) { this.updateWrapper = () => { const t = visualViewport.width, e = visualViewport.height, s = t / e, c = this.width / this.height; let n = visualViewport.offsetLeft, i = visualViewport.offsetTop; c < s ? (this.scale = e / this.height, n += .5 * (t - this.scale * this.width)) : (this.scale = t / this.width, i += .5 * (e - this.scale * this.height)), this.wrapper.style.transform = `translate(${n}px, ${i}px) scale(${this.scale})`; }, this.wrapper = t, this.width = e, this.height = s, this.scale = 1; }
        addEventListeners() { if (!visualViewport)
            return 1; addEventListener("resize", this.updateWrapper), visualViewport.addEventListener("resize", this.updateWrapper), visualViewport.addEventListener("scroll", this.updateWrapper), this.updateWrapper(); }
        documentToViewport(t) { t.x /= this.scale, t.y /= this.scale; }
    }(document.querySelector("#a"), 960, 540);
    U.addEventListeners();
    const Z = new class {
        constructor() { this.state = []; }
        setState(t, e) { if (e && (t.altKey || t.ctrlKey || t.metaKey))
            return; const s = B[(c = t.code, (c[0] ?? "") + (c[3] ?? "") + (c[5] ?? ""))]; var c; s && (t.repeat || (this.state[s] = e), t.preventDefault()); }
        addEventListeners(t) { t.addEventListener("keydown", (t => this.setState(t, 1))), t.addEventListener("keyup", (t => this.setState(t))); }
    };
    Z.addEventListeners(document);
    const z = new class extends D {
        setPosition(t) { super.setPosition(t), U.documentToViewport(this); }
    }(F.canvas);
    function W(t) { return t < .5 ? 2 * t : 2 - 2 * t; }
    function $(t) { return t - Math.floor(t); }
    function H(t) { return (t /= 255) <= .0404482362771082 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4); }
    function J(t) { return Math.floor(255 * (t <= .00313066844250063 ? 12.92 * t : 1.055 * Math.pow(t, 1 / 2.4) - .055)).toString(16); }
    z.addEventListeners(document), document.addEventListener("contextmenu", (t => { t.preventDefault(); }));
    const j = H(255), Q = H(205), X = H(117), Y = H(239), _ = H(125), tt = H(87), et = H(167), st = H(240), ct = H(112), nt = H(56), it = H(183), ot = H(100);
    function ft(t, e, n, i, o = 0, f = 0) {
  const zh=window.YuqingChinese.translate(i);
  if(zh!==i){window.YuqingChinese.paintBitmap(K,zh,t,e,{size:n*G,align:"center",baseline:"middle",color:i==="ARROWS TO MOVE OR TAP ON SCREEN"?"#ffce79":"#21346c",maxWidth:Math.max(60,n*i.length*(V+1))});return;} t -= .5 * n * (i.length * (V + 1) - 1), e -= .5 * n * G; for (let r = 0, a = 0; a < i.length; ++a) {
        const h = i.charCodeAt(a) - I;
        if (h >= 0) {
            const i = o ? o * n * s(W($(f + .1 * a))) : 0;
            c(q >> BigInt(h * V * G), V, G, 2n, ((s, c, o) => o && K.rect(t + r + n * s, e + i + n * c, n, n)));
        }
        r += n * (V + 1);
    } }
    const rt = new Set([0]), at = new Set([2, 4]);
    function ht(t, e, s, c, n) { const i = e.x + s, o = e.y + c; if (i < 0 || o < 0 || i >= t.width || o >= t.height)
        return; if (t.positions[o][i].some((t => rt.has(t.type) && (!t.cluster || t.cluster !== e.cluster))))
        return; const f = (e.cluster && e.cluster !== n?.cluster ? e.cluster.pieces.filter((t => t !== e)) : []).concat(t.positions[o][i].filter((t => at.has(t.type) && (!t.cluster || t.cluster !== e.cluster)))), r = [[e, s, c]]; for (const n of f) {
        const i = ht(t, n, s, c, e);
        if (!i)
            return;
        r.push(...i);
    } const a = new Set; return r.filter((([t, ,]) => a.has(t) ? 0 : a.add(t))); }
    const ut = [1, 96, , , , , 2, , 2, , 6, 64, 2, ,], dt = { phase: 0, phaseTtl: 0, oldTtl: 0, levelIndex: 1, clear: {} }, lt = [1, 64, 1, 64], bt = { phase: 0, phaseTtl: 0, oldTtl: 0 };
    try {
        if (localStorage.superCastleIndex && localStorage.superCastleClear) {
            const t = +localStorage.superCastleIndex, e = JSON.parse(localStorage.superCastleClear);
            t && t < T.length && T[t] && 1 === e[1] && (dt.levelIndex = t, Object.assign(dt.clear, e));
        }
    }
    catch (t) { }
    class wt {
        constructor(t, e, s) { this.board = new a(t, e), this.external = s, this.active = new Set, this.t = new Set, this.i = new Set, this.cellSize = Math.min(960 / t, 540 / e), this.boardLeft = .5 * (960 - t * this.cellSize), this.boardTop = .5 * (540 - e * this.cellSize); }
        tryMove(t, e, s) { const c = ht(this.board, t, e, s); if (!c)
            return 1; let n = 0; for ([t, e, s] of c)
            this.board.putPiece(t, t.x + e, t.y + s), this.board.positions[t.y][t.x].some((t => 5 === t.type)) && (n = t.killed = 1), this.active.add(t); if (!this.board.pieces[1]?.filter((t => !t.killed)).length) {
            for ([t, e, s] of c)
                this.board.putPiece(t, t.x - e, t.y - s), t.killed = 0, this.active.delete(t);
            return 1;
        } n && L(2), this.o(this.i), x(dt, 3, 10), N(); }
        discardPiece(t) { this.board.discardPiece(t), 1 === t.type && (this.t.delete(t), this.i.delete(t)); }
        o(t) { this.board.pieces[1]?.forEach((e => { this.board.positions[e.y][e.x].some((t => 3 === t.type)) ? t.add(e) : t.delete(e); })); }
        connectDucklings(t) { const e = new Set; t.forEach((t => { this.board.getBorderingPieces(t, 2)?.forEach((t => { e.add(t.cluster); })); })), e.size && (e.forEach((t => { t.pieces.forEach((t => { this.discardPiece(t); const e = this.board.createPiece(1, t.x, t.y); this.active.add(e); })); })), new r(this.board.pieces[1]), this.o(this.i), x(dt, 4, 20), L(1)); }
        splitCluster(t) { const e = t.pieces[0].type, s = new Set(t.pieces.filter((t => !t.killed))), c = []; for (const t of s) {
            const e = [...this.board.getGroup(t)].filter((t => s.has(t)));
            e.length && (e.forEach((t => s.delete(t))), c.push(new r(e)));
        } if (1 === e && c.length > 1) {
            c.sort(((t, e) => e.pieces.length - t.pieces.length));
            for (let t = 1; t < c.length; ++t) {
                const e = [];
                c[t].pieces.forEach((t => { t.killed = 1, this.discardPiece(t); const s = this.board.createPiece(2, t.x, t.y); this.active.add(s), e.push(s); })), new r(e);
            }
            x(dt, 4, 20);
        } }
        checkWin() { const t = this.board.pieces[1]?.length, e = this.board.pieces[3]?.length; if (t === e && t === this.t.size && t === this.i.size)
            return dt.clear[dt.levelIndex] = 1, x(dt, 5, 64), L(3), 1; }
        render(e, c) { const n = 3 === dt.phase ? s(R(dt, 10, e)) : 4 === dt.phase ? s(R(dt, 20, e)) : 0, i = ["#ffcd75", "#" + J(t(et, j, n)) + J(t(st, Q, n)) + J(t(ct, X, n)), "#" + J(t(j, et, n)) + J(t(Q, st, n)) + J(t(X, ct, n)), "#a7f070"], o = ["#ef7d57", "#" + J(t(nt, Y, n)) + J(t(it, _, n)) + J(t(ot, tt, n)), "#" + J(t(Y, nt, n)) + J(t(_, it, n)) + J(t(tt, ot, n)), "#38b764"]; K.fillStyle = "#1a1c2c", K.fillRect(this.boardLeft, this.boardTop, this.board.width * this.cellSize, this.board.height * this.cellSize), K.beginPath(); const f = Math.max(this.board.width, this.board.height); for (let t = 1; t < f; ++t)
            t < this.board.width && (K.moveTo(this.boardLeft + t * this.cellSize, this.boardTop), K.lineTo(this.boardLeft + t * this.cellSize, this.boardTop + this.board.height * this.cellSize)), t < this.board.height && (K.moveTo(this.boardLeft, this.boardTop + t * this.cellSize), K.lineTo(this.boardLeft + this.board.width * this.cellSize, this.boardTop + t * this.cellSize)); K.strokeStyle = "#333c57", K.stroke(), this.outline && (K.strokeStyle = "#41a6f6", K.stroke(this.outline)), this.board.pieces[3]?.forEach((t => this.renderPiece(t, t.x, t.y, n, 0, i, o))), this.levelText(); for (let t = 0; t < this.board.height; ++t)
            for (let e = 0; e < this.board.width; ++e) {
                const s = $(c + .1 * (e - .85 * t));
                this.board.positions[t][e].forEach((c => 3 !== c.type && this.renderPiece(c, e, t, n, s, i, o)));
            } }
        levelText() { }
        renderPiece(c, n, i, o, f, r, a) { 3 === dt.phase && this.active.has(c) && (n += t(c.oldPosition.x - c.x, 0, o), i += t(c.oldPosition.y - c.y, 0, o)); let h = this.cellSize; if (n = n * h + this.boardLeft, i = i * h + this.boardTop, 0 === c.type)
            return K.fillStyle = "#000", K.fillRect(n, i, h, h), i += (.1 * s(W(f)) - .05) * h, K.beginPath(), K.moveTo(n + .2 * h, i + .2 * h), K.lineTo(n + .8 * h, i + .8 * h), K.moveTo(n + .2 * h, i + .8 * h), K.lineTo(n + .8 * h, i + .2 * h), K.strokeStyle = "#566c86", void K.stroke(); if (3 === c.type) {
            const t = h / 3;
            K.beginPath();
            for (let e = 0; e < 3; ++e) {
                const s = t * (e + .5);
                K.moveTo(n, i + s), K.lineTo(n + s, i), K.moveTo(n + h, i + h - s), K.lineTo(n + h - s, i + h);
            }
            return K.strokeStyle = "#a7f070", void K.stroke();
        } if (n -= .25, i -= .25, h += .5, c.killed) {
            const e = .5 * (this.cellSize - (h = t(h, 0, o)));
            n += e, i += e;
        } const u = .4 * h; switch (c.type) {
            case 1:
                const t = (this.t.has(c) ? 1 : 0) + (this.i.has(c) ? 2 : 0);
                vt(n, i, h, u, r[t], a[t], 0, 20), 3 === t ? (K.beginPath(), K.moveTo(n + .2 * h, i - u + .5 * h), K.lineTo(n + .4 * h, i - u + .7 * h), K.lineTo(n + .8 * h, i - u + .3 * h), K.strokeStyle = "#38b764", K.stroke()) : 0 === t && this.t.size && this.i.size && (K.beginPath(), K.moveTo(n + .2 * h, i - u + .2 * h), K.lineTo(n + .8 * h, i - u + .8 * h), K.moveTo(n + .2 * h, i - u + .8 * h), K.lineTo(n + .8 * h, i - u + .2 * h), K.strokeStyle = "#ef7d57", K.stroke()), 4 === dt.phase && this.active.has(c) && vt(n, i, h, u, "#94b0c2", "#566c86", h * o);
                break;
            case 2:
                vt(n, i, h, u, "#94b0c2", "#566c86", 0, 20), 4 === dt.phase && this.active.has(c) && vt(n, i, h, u, "#ffcd75", "#ef7d57", h * o);
                break;
            case 4:
                vt(n, i, h, u, "#41a6f6", "#3b5dc9", 0, 20), K.beginPath(), K.arc(n + .5 * h, i - u + .5 * h, .3 * h, 0, 2 * Math.PI), K.strokeStyle = "#3b5dc9", K.stroke();
                break;
            case 5:
                const s = (.9 * e(W(f)) + .1) * u;
                K.beginPath(), K.lineTo(n + .8 * h, i + .5 * h), K.arc(n + .5 * h, i + s + .5 * h, .3 * h, 0, Math.PI), K.lineTo(n + .2 * h, i + .5 * h), K.fillStyle = "#c4243020", K.fill(), K.beginPath(), K.lineTo(n + .8 * h, i - s + .5 * h), K.arc(n + .5 * h, i + .5 * h, .3 * h, 0, Math.PI), K.lineTo(n + .2 * h, i - s + .5 * h), K.fillStyle = "#c42430", K.fill(), K.beginPath(), K.arc(n + .5 * h, i - s + .5 * h, .3 * h, 0, 2 * Math.PI), K.fillStyle = "#f5555d", K.fill();
        } }
    }
    function vt(t, e, s, c, n, i, o, f) { f && (K.fillStyle = i + f, K.fillRect(t, e + s - .25, s, c + .25)), K.fillStyle = i, K.fillRect(t + o, e - c + s - .25, s - o, c + .25), K.fillStyle = n, K.fillRect(t + o, e - c, s - o, s); }
    class St extends wt {
        render(t, e) { super.render(t, e), K.save(), K.shadowColor = "#000", K.shadowOffsetX = K.shadowOffsetY = 3, K.beginPath(), ft(480, this.boardTop + 4.5 * this.cellSize, 4, "ARROWS TO MOVE OR TAP ON SCREEN", 1, e), K.fillStyle = "#ffcd75", K.fill(), K.restore(); }
    }
    class pt extends wt {
        checkWin() { const { x: t, y: e } = this.board.pieces[1][0]; let s; if (this.board.positions[e][t].some((t => 3 === t.type && (s = t))))
            return dt.levelIndex = .5 * (s.y - 2) * 6 + .5 * (s.x - 2) - 1, x(dt, 5, 64), L(3), 1; }
        render(t, e) { super.render(t, e), K.save(), K.shadowColor = "#000", K.shadowOffsetX = K.shadowOffsetY = 3, K.beginPath(), ft(480, this.boardTop + 8.5 * this.cellSize, 4, "CLICK HERE FOR MORE LEVELS", 1, e), K.fillStyle = "#73eff7", K.fill(), K.restore(); }
        levelText() { K.save(), K.shadowColor = "#000", K.shadowOffsetX = K.shadowOffsetY = 3, K.beginPath(); for (let t = 1; t < T.length - 2; ++t)
            dt.clear[t] || ft(this.boardLeft + (t % 6 * 2 + 2) * this.cellSize, this.boardTop + (2 * Math.floor(t / 6) + 2.5) * this.cellSize + 3, 6, String.fromCharCode(64 + t), 0, 0); K.fillStyle = "#f4f4f4", K.fill(), K.beginPath(); for (let t = 1; t < T.length - 2; ++t)
            dt.clear[t] && ft(this.boardLeft + (t % 6 * 2 + 2) * this.cellSize, this.boardTop + (2 * Math.floor(t / 6) + 2.5) * this.cellSize + 3, 6, String.fromCharCode(64 + t), 0, 0); K.fillStyle = "#a7f070", K.fill(), K.restore(); }
    }
    function mt(t, e) { const s = parseInt(t.slice(0, 2), 16), c = parseInt(t.slice(2, 4), 16), n = BigInt("0x" + t.slice(4)), i = new (e ? wt : 1 === dt.levelIndex ? St : dt.levelIndex === T.length - 1 ? pt : wt)(s, c, e); i.board.load(n); [1, 2, 4].forEach((t => i.board.buildClusters(t))); try {
        i.outline = function ({ board: t, cellSize: e, boardLeft: s, boardTop: c }) { const n = Array.from({ length: t.height + 1 }, ((e, s) => Array.from({ length: t.width + 1 }, ((e, c) => ({ edges: [], value: t.positions[s]?.[c]?.every((t => 0 !== t.type)) }))))), i = new Set, o = new Set, f = new Path2D; for (let e = 0; e < t.height; ++e)
            for (let s = 0; s < t.width; ++s) {
                if (!n[e][s].value)
                    continue;
                const t = s > 0 && n[e][s - 1].value ? null : new gt(s, e + 1, s, e), c = e > 0 && n[e - 1][s].value ? null : new gt(s, e, s + 1, e), f = n[e][s + 1].value ? null : new gt(s + 1, e, s + 1, e + 1), r = n[e + 1][s].value ? null : new gt(s + 1, e + 1, s, e + 1);
                t && c && (t.next = c, o.add(c)), c && f && (c.next = f, o.add(f)), f && r && (f.next = r, o.add(r)), r && t && (r.next = t, o.add(t)), t && (n[t.start.y][t.start.x].edges.push(t), i.add(t)), c && (n[c.start.y][c.start.x].edges.push(c), i.add(c)), f && (n[f.start.y][f.start.x].edges.push(f), i.add(f)), r && (n[r.start.y][r.start.x].edges.push(r), i.add(r));
            } function r(t) { const r = t.start; for (f.moveTo(t.start.x * e + s, t.start.y * e + c);;) {
            i.delete(t), o.delete(t);
            const a = n[t.start.y][t.start.x].edges;
            for (a.splice(a.indexOf(t), 1); !t.next && 1 === n[t.end.y][t.end.x].edges.length;) {
                const e = n[t.end.y][t.end.x].edges[0];
                if (e.dir.x !== t.dir.x || e.dir.y !== t.dir.y)
                    break;
                t.end.copy(e.end), t.next = e.next, i.delete(e), o.delete(e);
                const s = n[e.start.y][e.start.x].edges;
                s.splice(s.indexOf(e), 1);
            }
            if (t.end.x === r.x && t.end.y === r.y) {
                f.closePath();
                break;
            }
            if (f.lineTo(t.end.x * e + s, t.end.y * e + c), t.next)
                t = t.next;
            else {
                if (1 !== n[t.end.y][t.end.x].edges.length)
                    throw Error("Logic error");
                t = n[t.end.y][t.end.x].edges[0];
            }
        } } for (let t of o)
            r(t); for (const t of i)
            r(t); return f; }(i);
    }
    catch (t) { } return i; }
    class gt {
        constructor(t, e, s, c) { this.start = new n(t, e), this.end = new n(s, c), this.dir = new n(s - t, c - e), this.next = null; }
    }
    const Mt = i;
    const At = new Path2D("M20.18 23.93l18.55-6.67v11.08a7.65 7.65 0 0 0-3.82-1c-3.92 0-7.09 2.85-7.09 6.37 0 3.52 3.17 6.37 7.09 6.37 3.92 0 7.09-2.85 7.09-6.37V14.98c0-2.24 0-4.12-0.18-5.61a13.45 13.45 0 0 0-0.08-0.62c-0.17-1.02-0.47-1.98-1.05-2.77a4.49 4.49 0 0 0-1.35-1.24l-0.02-0.01c-1.54-0.92-3.28-0.86-5.06-0.44-1.73 0.4-3.87 1.2-6.5 2.19l-4.57 1.71c-1.23 0.46-2.27 0.85-3.09 1.26-0.87 0.43-1.62 0.94-2.19 1.71-0.56 0.76-0.8 1.58-0.9 2.46-0.1 0.84-0.1 1.85-0.1 3.05v15.59a7.65 7.65 0 0 0-3.82-1C9.17 31.26 6 34.11 6 37.63 6 41.15 9.17 44 13.09 44c3.92 0 7.09-2.85 7.09-6.37v-13.7Z"), yt = new Path2D("M6.93 6.93C4 9.86 4 14.57 4 24c0 9.43 0 14.14 2.93 17.07C9.86 44 14.57 44 24 44c9.43 0 14.14 0 17.07-2.93C44 38.14 44 33.43 44 24c0-9.43 0-14.14-2.93-17.07C38.14 4 33.43 4 24 4S9.86 4 6.93 6.93Zm11.59 9.02A1.5 1.5 0 1 0 16.48 13.74L11.98 17.9a1.5 1.5 0 0 0 0 2.2l4.5 4.16a1.5 1.5 0 1 0 2.04-2.21l-1.68-1.55h11.24a5.42 5.42 0 0 1 0 10.85H19a1.5 1.5 0 1 0 0 3h9.08a8.42 8.42 0 0 0 0-16.85h-11.24l1.68-1.55Z"), Ct = new Path2D("M13.74 39c1.86 1 4.09 1 8.54 1h5.28c7.75 0 11.63 0 14.03-2.34C44 35.31 44 31.54 44 24c0-7.54 0-11.31-2.41-13.66C39.18 8 35.31 8 27.56 8h-5.27c-4.45 0-6.68 0-8.54 1-1.86 1-3.04 2.84-5.41 6.52L6.98 17.64C4.99 20.73 4 22.28 4 24c0 1.72 0.99 3.27 2.98 6.36l1.36 2.12c2.36 3.68 3.54 5.51 5.4 6.52Zm8.32-21.06A1.5 1.5 0 0 0 19.94 20.06L23.88 24l-3.94 3.94a1.5 1.5 0 1 0 2.12 2.12L26 26.12l3.94 3.94a1.5 1.5 0 0 0 2.12-2.12L28.12 24l3.94-3.94a1.5 1.5 0 0 0-2.12-2.12L26 21.88l-3.94-3.94Z");
    const Et = Math.cos(Math.PI / 6), Lt = .5;
    function Ot(t, e, s, c = 0) { const n = (t - e) * Et + 480, i = (t + e) * Lt - s + 270; 0 === c ? K.lineTo(n, i) : K.moveTo(n, i); }
    function kt(t, e, s, c) { Ot(t - c, e - c, s + c, 1), Ot(t + c, e - c, s + c), Ot(t + c, e + c, s + c), Ot(t - c, e + c, s + c); }
    function Nt(t, e, s, c) { Ot(t + c, e - c, s - c, 1), Ot(t + c, e + c, s - c), Ot(t + c, e + c, s + c), Ot(t + c, e - c, s + c); }
    function Tt(t, e, s, c) { Ot(t + c, e + c, s - c, 1), Ot(t - c, e + c, s - c), Ot(t - c, e + c, s + c), Ot(t + c, e + c, s + c); }
    const xt = [], Pt = [], Rt = [], qt = [];
    function Vt(t) { const e = 30 * t * .47; let s = 0; for (let c = 0; c < qt.length; ++c) {
        const n = qt[c], i = e - (1 - t) * c;
        if (!(i <= 0)) {
            K.beginPath();
            for (let t = s; t < s + n; ++t)
                kt(xt[t], Pt[t], Rt[t], i);
            K.fillStyle = "#94b0c2", K.fill(), K.beginPath();
            for (let t = s; t < s + n; ++t)
                Nt(xt[t], Pt[t], Rt[t], i);
            K.fillStyle = "#566c86", K.fill(), K.beginPath();
            for (let t = s; t < s + n; ++t)
                Tt(xt[t], Pt[t], Rt[t], i);
            K.fillStyle = "#333c57", K.fill(), s += n;
        }
    } }
    function Gt(c, n) { const i = R(dt, 1 === dt.phase ? 96 : 64, c); if (c = s(i), K.fillStyle = "#ef7d57", K.fillRect(0, .5 * (1 - c) * 540, 960, 540 * c), Vt(c), K.beginPath(), ft(480, t(-20, 135, e(i)), 6, "SUPER CASTLE GAME", 1.5, n), K.shadowColor = "#1a1c2c", K.shadowOffsetX = K.shadowOffsetY = 3, K.fillStyle = "#ffcd75", K.fill(), 1 === dt.phase) {
        const s = t(630, 405, e(i));
        K.beginPath(), K.rect(60, s - 80, 300, 160), K.rect(600, s - 80, 300, 160), K.fillStyle = "#ffcd75", K.fill(), K.beginPath(), ft(210, s, 6, "START", 1, n), ft(750, s - 27, 6, "START", 1, n), ft(750, s + 27, 4, "MUSIC OFF", 1, n), K.shadowColor = "#c42430", K.fillStyle = "#f5555d", K.fill();
    } K.shadowColor = "#0000", K.shadowOffsetX = K.shadowOffsetY = 0; }
    let It;
    !function () { const t = new Set; for (let e = 7; e--;)
        for (let s = 7; s--;) {
            let c = 0;
            for (let n = 7; n--;) {
                if (e > 0 && e < 6 && s > 0 && s < 6)
                    continue;
                if (Math.hypot(e - 7, s - 3, n - 1) < 2)
                    continue;
                if (n > 2 && n < 5 && (2 === e || 4 === e))
                    continue;
                if (n > 5 && 1 & e | 1 & s)
                    continue;
                const i = 960 * (e - s) + (e + s - n - n);
                t.has(i) || (t.add(i), xt.unshift(30 * e), Pt.unshift(30 * s), Rt.unshift(30 * n), ++c);
            }
            c && qt.unshift(c);
        } }();
    try {
        It = mt(location.hash.slice(1), 1), dt.levelIndex = T.length - 2;
    }
    catch (t) {
        It = mt(T[dt.levelIndex]);
    }
    function Dt() { if (It.external)
        try {
            It = mt(location.hash.slice(1), 1), dt.levelIndex = T.length - 2;
        }
        catch (t) {
            It = mt(T[dt.levelIndex]);
        }
    else
        It = mt(T[dt.levelIndex]); }
    function Bt() { if (Z.state[9])
        return Dt(); const t = Z.state[1] || Z.state[5], e = Z.state[2] || Z.state[6], s = Z.state[3] || Z.state[7], c = Z.state[4] || Z.state[8]; if ((t ? !s : s) || (e ? !c : c)) {
        const n = It.board.pieces[1] ?? [];
        if (!n.length)
            return;
        const i = (s ? 1 : 0) - (t ? 1 : 0), o = (c ? 1 : 0) - (e ? 1 : 0);
        if (i && (n.sort(((t, e) => i * (e.x - t.x))), !It.tryMove(n[0], i, 0)))
            return;
        if (o && (n.sort(((t, e) => o * (e.y - t.y))), !It.tryMove(n[0], 0, o)))
            return;
    } if (z.held) {
        if (z.x >= 796 && z.x < 960 && z.y < 48) {
            if (!dt.pointerHeld) {
                if (dt.pointerHeld = 1, z.x >= 908) {
                    if (dt.levelIndex !== T.length - 1 || It.external)
                        return dt.levelIndex = T.length - 2, x(dt, 5, 64), void L(3);
                    Dt();
                }
                else
                    z.x >= 852 ? Dt() : A(dt.audioMuted = !dt.audioMuted);
                L(0);
            }
            return;
        }
        if (dt.levelIndex === T.length - 1 && z.x >= It.boardLeft + 2 * It.cellSize && z.x < 960 - (It.boardLeft + 2 * It.cellSize) && z.y >= It.boardTop + 8 * It.cellSize)
            return void (dt.pointerHeld || (dt.pointerHeld = 1, z.held = 0, A(dt.audioMuted = 1), open("https://github.com/mvasilkov/super2023/tree/master/levels#levels", "levels")));
        const t = It.board.pieces[1] ?? [];
        if (!t.length)
            return;
        let e, s;
        i.set((z.x - It.boardLeft) / It.cellSize - .5, (z.y - It.boardTop) / It.cellSize - .5), o.set(t.reduce(((t, e) => t + e.x), 0) / t.length, t.reduce(((t, e) => t + e.y), 0) / t.length);
        const c = Math.abs(e = i.x - o.x), n = Math.abs(s = i.y - o.y);
        if (c < n) {
            if (n < .5)
                return;
            s = s < 0 ? -1 : 1, t.sort(((t, e) => s * (e.y - t.y))), It.tryMove(t[0], 0, s);
        }
        else {
            if (c < .5)
                return;
            e = e < 0 ? -1 : 1, t.sort(((t, s) => e * (s.x - t.x))), It.tryMove(t[0], e, 0);
        }
    }
    else
        dt.pointerHeld = 0; const n = function () { try {
        for (const t of navigator.getGamepads())
            if (t)
                return Mt.b = t.buttons[1].pressed, Mt.set(t.axes[0] < -.25 ? -1 : t.axes[0] > .25 ? 1 : 0, t.axes[1] < -.25 ? -1 : t.axes[1] > .25 ? 1 : 0);
    }
    catch (t) { } }(); if (n) {
        if (n.b)
            return Dt();
        const t = It.board.pieces[1] ?? [];
        if (!t.length)
            return;
        if (n.x && (t.sort(((t, e) => n.x * (e.x - t.x))), !It.tryMove(t[0], n.x, 0)))
            return;
        if (n.y && (t.sort(((t, e) => n.y * (e.y - t.y))), !It.tryMove(t[0], 0, n.y)))
            return;
    } }
    !function (t, e, s = 20) { let c, n = 0; function i(o) { requestAnimationFrame(i), n += o - c, c = o; let f = 4; for (; n > 0;)
        n -= s, --f >= 0 && t(s); e(n / s + 1); } requestAnimationFrame((function (t) { requestAnimationFrame(i), c = t; })); }((function () { const t = P(dt, ut); switch (dt.phase) {
        case 2:
            if (3 === t || 4 === t) {
                const t = [], e = new Set;
                for (const s of It.active)
                    s.killed ? (It.discardPiece(s), s.cluster && e.add(s.cluster)) : (s.oldPosition.copy(s), 1 === s.type && t.push(s));
                It.active.clear(), e.forEach((t => { It.splitCluster(t); })), It.o(It.t), It.connectDucklings(t.filter((t => !t.killed)));
            }
            2 === dt.phase && (It.checkWin() || Bt());
            break;
        case 6: 5 === t && (It = mt(T[++dt.levelIndex]), localStorage.superCastleIndex = dt.levelIndex, localStorage.superCastleClear = JSON.stringify(dt.clear));
    } P(bt, lt); }), (function (t) { const e = R(bt, 64, t); K.fillStyle = "#000", K.fillRect(0, 0, 960, 540), 1 !== dt.phase ? (It.render(t, e), K.save(), K.translate(800, 0), K.fillStyle = dt.audioMuted ? "#ffcd7580" : "#ffcd75", K.fill(At), K.translate(56, 0), K.fillStyle = "#ffcd75", K.fill(yt, "evenodd"), K.translate(56, 0), K.fill(Ct, "evenodd"), K.restore(), 5 === dt.phase ? Gt(t, e) : 6 === dt.phase && function (t, e) { t = s(R(dt, 64, t)), K.save(), K.beginPath(), K.rect(.5 * t * 960, 0, 960 * (1 - t), 540), K.fillStyle = "#ef7d57", K.fill(), K.clip(), Vt(1), K.beginPath(), ft(480, 135, 6, "SUPER CASTLE GAME", 1.5, e), K.shadowColor = "#000", K.shadowOffsetX = K.shadowOffsetY = 3, K.fillStyle = "#ffcd75", K.fill(), K.restore(); }(t, e)) : Gt(t, e); })), document.addEventListener("mousedown", (() => { S.initialized || (S.initialize(M(z.x < 480)), x(dt, 6, 64)); }), { once: !0 }), document.addEventListener("touchend", (() => { S.initialized || (S.initialize(M(z.x < 480)), x(dt, 6, 64)); }), { once: !0 });
}();
