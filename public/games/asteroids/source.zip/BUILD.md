# 陨石突围

Upstream: https://github.com/dmcinnes/HTML5-Asteroids
Pinned commit: 930301cbda83ed3b120f64b801d937d077ee2da0
License: MIT, see runtime/games/asteroids/LICENSE.

runtime/ is the exact adapted static package. Run
python -m http.server 8080 --directory runtime
and open http://localhost:8080/games/asteroids/index.html .

upstream/ contains the preferred source at the recorded commit. Normal hall
builds serve committed runtimes without rebuilding third-party programs.
adaptations/ contains import-games.mjs, pinned build inputs and the source
packager. See adaptations/README.md for rebuilding the two compiled games;
prepare-builds.mjs selects Chinese by default for Minesweeper and replaces
obsolete node-sass for BreakLock. The original sources remain separate.
For other games the readable runtime is also the editable adapted source.
Chinese Chess originally uses GBK: import-games.mjs converts it to UTF-8.

Unused fonts/audio omitted from the archive:
39459__THE_bizniss__laser.wav
51467__smcameron__missile_explosion.wav
vector_battle_regular.typeface.js
