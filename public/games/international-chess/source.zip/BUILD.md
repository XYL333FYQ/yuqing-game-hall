# 国际象棋

Upstream: https://github.com/kbjorklu/chess
Pinned commit: 61c19eaa8afbb54a73870c2be883023b06a455bc
License: MIT; jQuery and jQuery UI MIT, see runtime/games/international-chess/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/international-chess/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:

