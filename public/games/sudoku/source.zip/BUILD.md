# 九宫数独

Upstream: https://github.com/andreynering/sudoku
Pinned commit: f8a58fcdcf15d1594850a3021d74f17795b0a4bf
License: MIT; bundled dependencies retain notices, see runtime/games/sudoku/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/sudoku/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:

