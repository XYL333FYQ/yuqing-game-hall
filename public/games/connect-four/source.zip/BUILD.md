# 四子连线

Upstream: https://github.com/bryanbraun/connect-four
Pinned commit: ee62db41dc9b32a5e5ebf20b876809c9c3e0db6b
License: MIT, see runtime/games/connect-four/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/connect-four/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:

