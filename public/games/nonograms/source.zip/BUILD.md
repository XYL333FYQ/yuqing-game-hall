# 数织画谜

Upstream: https://github.com/jodua/nonograms
Pinned commit: b71ca9c8d8a7c1568d64c32b8162613d92a22712
License: MIT; dependencies see licenses, see runtime/games/nonograms/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/nonograms/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:

