# 五彩连珠

Upstream: https://github.com/arnisritins/Color-Lines
Pinned commit: a51ce95e0144c473253bc985c3d113c12e227bfc
License: MIT, see runtime/games/color-lines/LICENSE and accompanying notices.

runtime/ contains the shipped adapted static game. Serve it with:
python -m http.server 8080 --directory runtime
Open /games/color-lines/index.html .

upstream/ contains editable source from the pinned commit. adapted-source/
contains the modified preferred source of compiled games. adaptations/ contains
the import, build and package scripts and pinned build inputs. See its README.md
for reproducible regeneration; normal hall builds use committed runtime files.

Unused assets omitted:

