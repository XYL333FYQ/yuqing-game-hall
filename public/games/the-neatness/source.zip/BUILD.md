# 线索迷境 / The Neatness

Upstream: https://github.com/mvasilkov/neatness2022
Commit: 23ee28bfbda813c2d9b55e21105c6e35d2ae586c
License: GPL-3.0-only (upstream license retained)

runtime/ contains the exact readable, adapted HTML/CSS/JavaScript and all game
assets. Serve it with `python -m http.server 8080 --directory runtime` and open
http://localhost:8080/games/the-neatness/index.html . No platform or VPS is needed.

upstream/ contains the pinned preferred source, original build files and credit
notices. See its README and package.json for the original development workflow.
Generated/minified originals remain included, alongside the readable runtime.

For the four TypeScript adaptations, install this hall's pinned frontend tools
(Vite 8 / TypeScript), place the original source checkout at the recorded path,
then run `node games/expansion/build-adapted.mjs the-neatness <source-path>`.
The supplied overrides replace the corresponding original src files; Casual
Crusade instead removes the first redundant super(0, 0, 0, 0) in src/pile.ts.
Use publicDir:false when building: copying a development public/index.html can
overwrite the production entry. Daily hall builds serve the committed runtimes.

For other games, runtime/ is the editable adapted source: preserve the shared
localization scripts, relative paths and SOURCE.md; ADAPTATIONS.json describes
the changes. Original build scripts are optional for these static runtimes.

The omitted entries below are development demonstrations, compiler executables
or duplicate unchanged audio. Runtime audio is supplied in runtime/; complete
program source and the assets needed to run the adapted game remain included.

