/* This file is part of The Neatness (js13kGames–2022)
 * GitHub https://github.com/mvasilkov/neatness2022
 * Copyright (c) 2022 Mark Vasilkov
 * Licensed under the GNU General Public License version 3
 * See https://www.gnu.org/licenses/gpl-3.0.en.html
 */
export const tiles = [
    0b1111110000000000001110111000000000000,
    0b1100011000000000011000011000000000000,
    0b1100011001111100111110011000111110001,
    0b1100111011000110011000011001100011011,
    0b1111100011111110011000011001111111011,
    0b1101110011000000011000011001100000011,
    0b1100111001111100011000111100111110001,
]
export const width = 37
