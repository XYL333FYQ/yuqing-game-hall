/** Comparison function type */
export type CompareFunction<T> = (a: Readonly<T>, b: Readonly<T>) => number;
/** Queue class that retrieves values in priority order (lowest first). */
export declare class PriorityQueue<T> {
    private values;
    length: number;
    readonly compareFn: CompareFunction<T>;
    constructor(compareFn: CompareFunction<T>, initialValues?: readonly T[]);
    /** Put a value into the queue. */
    put(value: T): void;
    /** Remove and return the head of the queue. */
    get(): T | undefined;
    private bubbleUp;
    private bubbleDown;
}
/** Return a new array containing values in ascending order. */
export declare function heapsort<T>(compareFn: CompareFunction<T>, values: readonly T[]): T[];
