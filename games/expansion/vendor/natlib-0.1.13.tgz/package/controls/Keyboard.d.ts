import { type ExtendedBool } from '../prelude.js';
/** Supported keyboard inputs */
export declare const enum Input {
    LEFT = 1,
    UP = 2,
    RIGHT = 3,
    DOWN = 4,
    LEFT_A = 5,
    UP_W = 6,
    RIGHT_D = 7,
    DOWN_S = 8,
    SPACE = 9
}
/** Keyboard controls class */
export declare class Keyboard {
    readonly state: ExtendedBool[];
    constructor();
    /** Update the keyboard state. */
    setState(event: KeyboardEvent, pressed?: ExtendedBool): void;
    /** Initialize the event handlers. */
    addEventListeners(target: GlobalEventHandlers): void;
}
