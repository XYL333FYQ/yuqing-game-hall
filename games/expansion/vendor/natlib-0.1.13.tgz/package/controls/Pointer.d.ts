import { type ExtendedBool } from '../prelude.js';
import type { IVec2 } from '../Vec2';
/** Pointer controls class */
export declare class Pointer implements IVec2 {
    x: number;
    y: number;
    held: ExtendedBool;
    readonly plane: Element;
    constructor(plane: Element);
    /** Set the pointer position relative to the plane. */
    setPosition(event: MouseEvent | Touch): void;
    /** Initialize the event handlers. */
    addEventListeners(target: GlobalEventHandlers): void;
}
