/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Pointer controls class */
export class Pointer {
  constructor(plane) {
    this.x = this.y = 0;
    this.plane = plane;
  }
  /** Set the pointer position relative to the plane. */
  setPosition(event) {
    const r = this.plane.getBoundingClientRect();
    this.x = event.clientX - r.left;
    this.y = event.clientY - r.top;
  }
  /** Initialize the event handlers. */
  addEventListeners(target) {
    // Mouse events
    target.addEventListener('mousedown', event => {
      event.preventDefault();
      this.held = 1 /* ShortBool.TRUE */;
      this.setPosition(event);
    });
    target.addEventListener('mousemove', event => {
      event.preventDefault();
      this.setPosition(event);
    });
    target.addEventListener('mouseup', event => {
      event.preventDefault();
      this.held = 0 /* ShortBool.FALSE */;
    });

    target.addEventListener('mouseleave', _event => {
      // Default action is none, so no event.preventDefault()
      this.held = 0 /* ShortBool.FALSE */;
    });
    // Touch events
    target.addEventListener('touchstart', event => {
      event.preventDefault();
      this.held = 1 /* ShortBool.TRUE */;
      this.setPosition(event.targetTouches[0]);
    });
    target.addEventListener('touchmove', event => {
      event.preventDefault();
      this.setPosition(event.targetTouches[0]);
    });
    target.addEventListener('touchend', event => {
      event.preventDefault();
      this.held = 0 /* ShortBool.FALSE */;
    });

    target.addEventListener('touchcancel', _event => {
      // Default action is none, so no event.preventDefault()
      this.held = 0 /* ShortBool.FALSE */;
    });
  }
}