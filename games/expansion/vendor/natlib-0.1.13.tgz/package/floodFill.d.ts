import { type ExtendedBool } from './prelude.js';
/** Update predicate for flood fill */
export type ShouldUpdate = (x: number, y: number) => ExtendedBool;
/** Update function for flood fill */
export type UpdateFunction = (x: number, y: number) => void;
/** Scanline flood fill starting at `(x, y)` in a buffer `width` by `height`.
 * Update values using `updateFunction()` if `shouldUpdate()` returns `true`. */
export declare function floodFill(width: number, height: number, x: number, y: number, shouldUpdate: ShouldUpdate, updateFunction: UpdateFunction): void;
