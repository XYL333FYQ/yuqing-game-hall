/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { register0 } from './runtime.js';
const result = register0;
/** Digital differential analyzer (DDA) */
export function dda(start, direction, done) {
  // Scaling factor
  const Δx = Math.abs(1 / direction.x);
  const Δy = Math.abs(1 / direction.y);
  // Current tile
  let xtile = Math.floor(start.x);
  let ytile = Math.floor(start.y);
  // Ray length
  let xlength, ylength;
  // Ray direction (coarse)
  let xdir, ydir;
  if (direction.x < 0) {
    xlength = (start.x - xtile) * Δx;
    xdir = -1;
  } else {
    xlength = (xtile + 1 - start.x) * Δx;
    xdir = 1;
  }
  if (direction.y < 0) {
    ylength = (start.y - ytile) * Δy;
    ydir = -1;
  } else {
    ylength = (ytile + 1 - start.y) * Δy;
    ydir = 1;
  }
  while (true) {
    // Extend the shorter ray
    if (result.hitVertical = xlength < ylength) {
      result.hitDistance = xlength;
      xlength += Δx;
      xtile += xdir;
    } else {
      result.hitDistance = ylength;
      ylength += Δy;
      ytile += ydir;
    }
    if (done(xtile, ytile, result.hitDistance)) {
      return result.setMultiplyScalar(direction, result.hitDistance).add(start);
    }
  }
}