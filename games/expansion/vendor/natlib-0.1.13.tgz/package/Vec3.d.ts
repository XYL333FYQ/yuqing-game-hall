/** 3D vector data structure */
export interface IVec3 {
    x: number;
    y: number;
    z: number;
}
/** 3D vector class */
export declare class Vec3 implements IVec3 {
    x: number;
    y: number;
    z: number;
    constructor(x?: number, y?: number, z?: number);
    /** Set the components of this vector. */
    set(x: number, y: number, z: number): this;
    /** Copy the components of a vector to this vector. */
    copy(other: Readonly<IVec3>): this;
    /** Add a vector to this vector. */
    add(other: Readonly<IVec3>): this;
    /** Subtract a vector from this vector. */
    subtract(other: Readonly<IVec3>): this;
    /** Multiply this vector by a scalar. */
    scale(n: number): this;
    /** Set this vector to a scalar multiple of a vector. */
    setMultiplyScalar(other: Readonly<IVec3>, n: number): this;
    /** Get the length of this vector. */
    length(): number;
    /** Convert this vector to a unit vector. */
    normalize(): this;
    /** Get the dot product of two vectors. */
    dot(other: Readonly<IVec3>): number;
}
