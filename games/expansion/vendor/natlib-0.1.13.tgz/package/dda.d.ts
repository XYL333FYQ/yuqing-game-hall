import type { ExtendedBool } from './prelude';
import type { IVec2, Vec2 } from './Vec2';
/** DDA tile intersection type */
export type DdaIntersection = Vec2 & {
    /** View plane distance */
    hitDistance?: number;
    /** Intersection is on a vertical side of a tile. */
    hitVertical?: boolean;
};
/** Return true to end the DDA loop. */
export type DdaCallback = (x: number, y: number, hitDistance: number) => ExtendedBool;
/** Digital differential analyzer (DDA) */
export declare function dda(start: Readonly<IVec2>, direction: Readonly<IVec2>, done: DdaCallback): DdaIntersection;
