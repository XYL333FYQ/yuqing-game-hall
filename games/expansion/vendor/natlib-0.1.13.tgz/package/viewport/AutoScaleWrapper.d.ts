import { type ExtendedBool } from '../prelude.js';
import type { IVec2 } from '../Vec2';
/** Wrapper class that fills the viewport by scaling its contents. */
export declare class AutoScaleWrapper {
    readonly wrapper: HTMLElement;
    readonly width: number;
    readonly height: number;
    scale: number;
    constructor(wrapper: HTMLElement, width: number, height: number);
    /** Update wrapper to fill the viewport. */
    updateWrapper: () => void;
    /** Initialize the event handlers. Return TRUE on failure. */
    addEventListeners(): ExtendedBool;
    /** Translate a point from document coordinates to viewport coordinates. */
    documentToViewport(point: IVec2): void;
}
