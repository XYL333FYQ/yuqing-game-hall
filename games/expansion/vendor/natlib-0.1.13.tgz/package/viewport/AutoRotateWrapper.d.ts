import type { IVec2 } from '../Vec2';
import { AutoScaleWrapper } from './AutoScaleWrapper.js';
/** Wrapper class that fills the viewport by scaling and rotating its contents. */
export declare class AutoRotateWrapper extends AutoScaleWrapper {
    rotate: -1 | 0 | 1;
    constructor(wrapper: HTMLElement, width: number, height: number);
    /** Update wrapper to fill the viewport. */
    updateWrapper: () => void;
    /** Translate a point from document coordinates to viewport coordinates. */
    documentToViewport(point: IVec2): void;
}
