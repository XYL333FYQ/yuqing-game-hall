import type { PositiveInteger } from './prelude';
/** Sliding window function */
export declare function slidingWindow<T, U extends number>(array: T[], size: PositiveInteger<U>): Generator<T[], void, unknown>;
/** Permutations function */
export declare function permutations<T>(array: T[]): Generator<T[], void>;
