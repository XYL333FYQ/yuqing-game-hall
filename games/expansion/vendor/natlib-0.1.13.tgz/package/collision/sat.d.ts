import { type ExtendedBool } from '../prelude.js';
import type { Body } from '../verlet/Body';
/** Collision detection function using the Separating Axis Theorem (SAT) */
export declare function findCollision(b0: Body, b1: Body): ExtendedBool;
/** Resolve the last collision found by `findCollision()`. */
export declare function resolveCollision(b0: Body, b1: Body): void;
