/** Rendering function type */
export type RenderingFunction = (con: CanvasRenderingContext2D, width: number, height: number) => void;
/** Canvas handle class */
export declare class CanvasHandle {
    readonly canvas: HTMLCanvasElement;
    readonly con: CanvasRenderingContext2D;
    readonly height: number;
    readonly width: number;
    constructor(canvas: HTMLCanvasElement | null, width: number, height: number, supersampling?: number, ini?: RenderingFunction);
}
