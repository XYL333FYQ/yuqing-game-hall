/** Set the canvas text style and size, e.g. 'bold 48'. */
export declare function setTextStyle(con: CanvasRenderingContext2D, style: string | number): void;
/** Return a path encapsulating the text. */
export declare function textCapsule(con: CanvasRenderingContext2D, x: number, y: number, style: string | number, text: string, padding: number, borderRadius: number): Path2D;
