/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Scanline flood fill starting at `(x, y)` in a buffer `width` by `height`.
 * Update values using `updateFunction()` if `shouldUpdate()` returns `true`. */
export function floodFill(width, height, x, y, shouldUpdate, updateFunction) {
  const stack = [[x, x, y, 3 /* FillDirection.BOTH */]];

  while (stack.length !== 0) {
    let [x0, x1, y, direction] = stack.pop();
    // Expand the scanline to the left
    let u0 = x0;
    while (u0 >= 0 && shouldUpdate(u0, y)) {
      --u0;
    }
    if (++u0 < x0 - 1) {
      direction = 3 /* FillDirection.BOTH */;
    }
    // Expand the scanline to the right
    let u1 = x1;
    while (u1 < width && shouldUpdate(u1, y)) {
      ++u1;
    }
    if (--u1 > x1 + 1) {
      direction = 3 /* FillDirection.BOTH */;
    }
    // Fill the scanline. Reuse the x and x0 variables.
    let stripe;
    for (x = u0; x <= u1; ++x) {
      if (shouldUpdate(x, y)) {
        updateFunction(x, y);
        if (!stripe) {
          stripe = 1 /* ShortBool.TRUE */;
          x0 = x;
        }
      } else {
        if (stripe) {
          stripe = 0 /* ShortBool.FALSE */;
          push(x0, x - 1, y, direction);
        }
      }
    }
    if (stripe) push(x0, u1, y, direction);
  }
  /** Push scanlines onto the stack. */
  function push(x0, x1, y, direction) {
    if (direction & 1 /* FillDirection.UP */ && y > 0) {
      stack.push([x0, x1, y - 1, 1 /* FillDirection.UP */]);
    }

    if (direction & 2 /* FillDirection.DOWN */ && y < height - 1) {
      stack.push([x0, x1, y + 1, 2 /* FillDirection.DOWN */]);
    }
  }
}