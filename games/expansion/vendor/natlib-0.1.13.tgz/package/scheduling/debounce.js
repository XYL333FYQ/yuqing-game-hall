/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Create a debounced function that delays the given function
 * by a given `wait` time in milliseconds. If the function is
 * called again before the timeout expires, the previous call
 * will be aborted. */
export function debounce(defun, wait) {
  let pending;
  let lastCalled;
  return function (...a) {
    lastCalled = Date.now();
    if (pending) return;
    pending = 1 /* ShortBool.TRUE */;
    setTimeout(function wrapped() {
      const pauseDuration = Date.now() - lastCalled;
      if (pauseDuration < wait) {
        setTimeout(wrapped, wait - pauseDuration);
      } else {
        pending = 0 /* ShortBool.FALSE */;
        defun(...a);
      }
    }, wait);
  };
}