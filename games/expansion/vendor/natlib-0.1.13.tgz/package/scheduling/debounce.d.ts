/** Debounced function type */
export type DebouncedFunction<T extends unknown[]> = (...a: T) => void;
/** Create a debounced function that delays the given function
 * by a given `wait` time in milliseconds. If the function is
 * called again before the timeout expires, the previous call
 * will be aborted. */
export declare function debounce<T extends unknown[]>(defun: DebouncedFunction<T>, wait: number): DebouncedFunction<T>;
