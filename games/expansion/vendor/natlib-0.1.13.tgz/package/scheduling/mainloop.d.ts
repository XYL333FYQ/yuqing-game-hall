/** Callback function type */
export type LoopCallback = (t: number) => void;
/** Main loop using a fixed step of `T` milliseconds.
 * `render()` receives `t` in the range (0, 1] for interpolation. */
export declare function startMainloop(update: LoopCallback, render: LoopCallback, T?: number): void;
