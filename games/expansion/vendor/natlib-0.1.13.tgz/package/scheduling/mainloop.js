/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Main loop using a fixed step of `T` milliseconds.
 * `render()` receives `t` in the range (0, 1] for interpolation. */
export function startMainloop(update, render, T = 20) {
  let before;
  let t = 0;
  requestAnimationFrame(function (now) {
    requestAnimationFrame(loop);
    before = now;
  });
  function loop(now) {
    requestAnimationFrame(loop);
    t += now - before;
    before = now;
    // Most updates per render
    let n = 4;
    while (t > 0) {
      t -= T;
      if (--n >= 0) update(T);
    }
    render(t / T + 1);
  }
}