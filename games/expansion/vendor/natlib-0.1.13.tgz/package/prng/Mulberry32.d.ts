import type { uint32_t } from '../prelude';
import type { IPrng, IPrng32 } from './prng';
/** Mulberry32 PRNG class */
export declare class Mulberry32 implements IPrng32, IPrng {
    state: uint32_t;
    constructor(seed: uint32_t);
    /** Return a pseudorandom uint32. */
    randomUint32(): uint32_t;
    /** Return a pseudorandom number in the range [0, 1). */
    random(): number;
}
