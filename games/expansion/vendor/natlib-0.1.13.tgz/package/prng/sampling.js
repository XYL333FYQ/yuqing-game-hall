/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { UINT32_MAX } from '../prelude.js';
import { register4 } from '../runtime.js';
/** Return a pseudorandom number in the range [-1, 1]. */
export function randomClosedUnit1Ball(prng) {
  return (2 * prng.randomUint32() - UINT32_MAX) / UINT32_MAX;
}
/** Return a pseudorandom number in the range (-1, 1). */
export function randomOpenUnit1Ball(prng) {
  return (2 * prng.randomUint32() - UINT32_MAX) / (UINT32_MAX + 1);
}
/** Get a pseudorandom point on the unit sphere. */
export function uniformSampleSphere(prng) {
  // Algorithm by George Marsaglia (1972)
  let u, v, n;
  do {
    u = randomOpenUnit1Ball(prng);
    v = randomOpenUnit1Ball(prng);
    n = u ** 2 + v ** 2;
  } while (n >= 1);
  const a = 2 * (1 - n) ** 0.5;
  return register4.set(a * u, a * v, 1 - 2 * n);
}
/** Get a pseudorandom point on the unit hemisphere. */
export function uniformSampleHemisphere(prng, normal) {
  if (uniformSampleSphere(prng).dot(normal) < 0) {
    return register4.scale(-1);
  }
  return register4;
}