import { type uint32_t } from '../prelude.js';
/** PRNG (floating point) interface */
export interface IPrng {
    random(): number;
}
/** PRNG (32-bit integer) interface */
export interface IPrng32 {
    randomUint32(): uint32_t;
}
/** Return a pseudorandom uint32 in the range [0, n). */
export declare function randomUint32LessThan(prng: IPrng32, n: uint32_t): uint32_t;
/** Fisher–Yates shuffle, aka Knuth shuffle. */
export declare function shuffle<T>(prng: IPrng32, array: T[]): T[];
