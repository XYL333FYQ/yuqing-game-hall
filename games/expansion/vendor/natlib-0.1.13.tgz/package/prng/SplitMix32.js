/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** SplitMix32 PRNG class */
export class SplitMix32 {
  constructor(seed) {
    this.state = seed | 0;
  }
  /** Return a pseudorandom uint32. */
  randomUint32() {
    let z = this.state = this.state + 0x9e3779b9 | 0;
    z = Math.imul(z ^ z >>> 16, 0x85ebca6b);
    z = Math.imul(z ^ z >>> 13, 0xc2b2ae35);
    return (z ^ z >>> 16) >>> 0;
  }
  /** Return a pseudorandom number in the range [0, 1). */
  random() {
    return this.randomUint32() / 2 ** 32;
  }
}