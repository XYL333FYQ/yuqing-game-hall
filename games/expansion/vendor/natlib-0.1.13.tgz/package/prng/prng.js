/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { UINT32_MAX } from '../prelude.js';
/** Return a pseudorandom uint32 in the range [0, n). */
export function randomUint32LessThan(prng, n) {
  const discard = UINT32_MAX - UINT32_MAX % n;
  while (true) {
    const a = prng.randomUint32();
    if (a < discard) return a % n;
  }
}
/** Fisher–Yates shuffle, aka Knuth shuffle. */
export function shuffle(prng, array) {
  let n = array.length;
  while (n) {
    const a = randomUint32LessThan(prng, n);
    --n;
    const t = array[n];
    array[n] = array[a];
    array[a] = t;
  }
  return array;
}