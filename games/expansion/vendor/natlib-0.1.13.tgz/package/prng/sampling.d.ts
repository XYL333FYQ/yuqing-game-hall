import type { IVec3, Vec3 } from '../Vec3';
import type { IPrng32 } from './prng';
/** Return a pseudorandom number in the range [-1, 1]. */
export declare function randomClosedUnit1Ball(prng: IPrng32): number;
/** Return a pseudorandom number in the range (-1, 1). */
export declare function randomOpenUnit1Ball(prng: IPrng32): number;
/** Get a pseudorandom point on the unit sphere. */
export declare function uniformSampleSphere(prng: IPrng32): Vec3;
/** Get a pseudorandom point on the unit hemisphere. */
export declare function uniformSampleHemisphere(prng: IPrng32, normal: Readonly<IVec3>): Vec3;
