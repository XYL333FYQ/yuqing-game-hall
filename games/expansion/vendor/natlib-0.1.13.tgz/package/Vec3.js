/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** 3D vector class */
export class Vec3 {
  constructor(x = 0, y = 0, z = 0) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  /** Set the components of this vector. */
  set(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }
  /** Copy the components of a vector to this vector. */
  copy(other) {
    this.x = other.x;
    this.y = other.y;
    this.z = other.z;
    return this;
  }
  /** Add a vector to this vector. */
  add(other) {
    this.x += other.x;
    this.y += other.y;
    this.z += other.z;
    return this;
  }
  /** Subtract a vector from this vector. */
  subtract(other) {
    this.x -= other.x;
    this.y -= other.y;
    this.z -= other.z;
    return this;
  }
  /** Multiply this vector by a scalar. */
  scale(n) {
    this.x *= n;
    this.y *= n;
    this.z *= n;
    return this;
  }
  /** Set this vector to a scalar multiple of a vector. */
  setMultiplyScalar(other, n) {
    this.x = other.x * n;
    this.y = other.y * n;
    this.z = other.z * n;
    return this;
  }
  /** Get the length of this vector. */
  length() {
    return Math.hypot(this.x, this.y, this.z);
  }
  /** Convert this vector to a unit vector. */
  normalize() {
    const len = this.length();
    if (len !== 0) {
      this.x /= len;
      this.y /= len;
      this.z /= len;
    }
    return this;
  }
  /** Get the dot product of two vectors. */
  dot(other) {
    return this.x * other.x + this.y * other.y + this.z * other.z;
  }
}