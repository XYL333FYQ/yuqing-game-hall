/** Linear interpolation */
export declare function lerp(a: number, b: number, t: number): number;
/** Hermite interpolation (3rd order) */
export declare function smoothstep(t: number): number;
/** Hermite interpolation (5th order) */
export declare function smootherstep(t: number): number;
/** Easing function type */
export type EasingFunction = (t: number) => number;
/** Convert an ease-in (accelerate) function to an ease-out
 * (decelerate) function. */
export declare function easeOut(fn: EasingFunction): EasingFunction;
/** Convert an ease-in (accelerate) function to an ease-in-out
 * (accelerate then decelerate) function. */
export declare function easeInOut(fn: EasingFunction): EasingFunction;
/** Quadratic ease-in function, position equals the square of `t`. */
export declare function easeInQuad(t: number): number;
/** Quadratic ease-out function */
export declare function easeOutQuad(t: number): number;
/** Quadratic ease-in-out function */
export declare function easeInOutQuad(t: number): number;
/** Cubic ease-in function, position equals the cube of `t`. */
export declare function easeInCubic(t: number): number;
/** Cubic ease-out function */
export declare function easeOutCubic(t: number): number;
/** Cubic ease-in-out function */
export declare function easeInOutCubic(t: number): number;
/** Sinusoidal ease-in function */
export declare function easeInSine(t: number): number;
/** Sinusoidal ease-out function */
export declare function easeOutSine(t: number): number;
/** Sinusoidal ease-in-out function */
export declare function easeInOutSine(t: number): number;
