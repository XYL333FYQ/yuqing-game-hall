/** Function of this type is invoked by decodeBitmap for each pixel. */
export type ReadFunction = (x: number, y: number, value: number) => void;
/** Decode a bitmap stored as an array of integers. */
export declare function decodeBitmap(lines: number[], width: number, bpp: number, readFunction: ReadFunction): void;
/** Decode a bitmap stored as a BigInt value. */
export declare function decodeBitmapBigInt(value: bigint, width: number, height: number, cardinality: number | bigint, readFunction: ReadFunction): void;
