/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { decodeBitmapBigInt } from '../bitmap.js';
/** Print the given text using the fixed-width bitmap font. */
export function print(text, font, width, height, cardinality, startCodePoint, readFunction, letterSpacing = 1) {
  cardinality = BigInt(cardinality);
  const stride = cardinality ** BigInt(width * height);
  for (let caret = 0, n = 0; n < text.length; ++n) {
    const skip = text.charCodeAt(n) - startCodePoint;
    if (skip >= 0) {
      decodeBitmapBigInt(font / stride ** BigInt(skip), width, height, cardinality, (x, y, value) => readFunction(caret + x, y, value));
    }
    caret += width + letterSpacing;
  }
}
/** Print the given text using the fixed-width bitmap font with 1-bit color depth. */
export function print1bpp(text, font, width, height, startCodePoint, readFunction, letterSpacing = 1) {
  for (let caret = 0, n = 0; n < text.length; ++n) {
    const skip = text.charCodeAt(n) - startCodePoint;
    if (skip >= 0) {
      decodeBitmapBigInt(font >> BigInt(skip * width * height), width, height, 2n, (x, y, value) => readFunction(caret + x, y, value));
    }
    caret += width + letterSpacing;
  }
}