import { type ReadFunction } from '../bitmap.js';
/** Print the given text using the fixed-width bitmap font. */
export declare function print(text: string, font: bigint, width: number, height: number, cardinality: number | bigint, startCodePoint: number, readFunction: ReadFunction, letterSpacing?: number): void;
/** Print the given text using the fixed-width bitmap font with 1-bit color depth. */
export declare function print1bpp(text: string, font: bigint, width: number, height: number, startCodePoint: number, readFunction: ReadFunction, letterSpacing?: number): void;
