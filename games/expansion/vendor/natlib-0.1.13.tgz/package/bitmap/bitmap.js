/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Decode a bitmap stored as an array of integers. */
export function decodeBitmap(lines, width, bpp, readFunction) {
  const shift = 1 << bpp;
  for (let y = 0; y < lines.length; ++y) {
    for (let x = 0; x < width; ++x) {
      const value = lines[y] / shift ** x & shift - 1;
      readFunction(x, y, value);
    }
  }
}
/** Decode a bitmap stored as a BigInt value. */
export function decodeBitmapBigInt(value, width, height, cardinality, readFunction) {
  cardinality = BigInt(cardinality);
  for (let y = 0; y < height; ++y) {
    for (let x = 0; x < width; ++x) {
      readFunction(x, y, Number(value % cardinality));
      value /= cardinality;
    }
  }
}