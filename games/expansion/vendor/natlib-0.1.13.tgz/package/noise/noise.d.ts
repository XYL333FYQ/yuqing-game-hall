import type { uint8_t } from '../prelude';
import { type IPrng32 } from '../prng/prng.js';
/** 3D noise interface */
export interface INoise3 {
    noise3(x: number, y: number, z: number): number;
}
/** Build a random permutation table. */
export declare function buildPermutationTable(prng: IPrng32): uint8_t[];
