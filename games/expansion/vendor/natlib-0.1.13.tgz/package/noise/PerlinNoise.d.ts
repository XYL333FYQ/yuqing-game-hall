import type { uint8_t } from '../prelude';
import type { INoise3 } from './noise';
/** Perlin noise class */
export declare class PerlinNoise implements INoise3 {
    /** Permutation table */
    readonly p: readonly uint8_t[];
    constructor(p: readonly uint8_t[]);
    /** 3D Perlin noise */
    noise3(x: number, y: number, z: number): number;
}
