/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { shuffle } from '../prng/prng.js';
/** Build a random permutation table. */
export function buildPermutationTable(prng) {
  const a = Array.from({
    length: 256
  }, (_unused, n) => n);
  return shuffle(prng, a).concat(a);
}