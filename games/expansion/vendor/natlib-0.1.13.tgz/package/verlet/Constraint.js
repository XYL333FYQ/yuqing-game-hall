/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { register0 } from '../runtime.js';
/** Constraint class (Verlet integration) */
export class Constraint {
  constructor(body, v0, v1, edge, stiffness = 1) {
    this.body = body;
    this.v0 = v0;
    this.v1 = v1;
    this.lengthSquared = (this.p0 = v0.position).distanceSquared(this.p1 = v1.position);
    this.edge = edge;
    this.stiffness = stiffness;
    if (!this.lengthSquared) throw Error('Overlapping vertices');
    body.constraints.push(this);
    if (edge) body.edges.push(this);
    body.scene.constraints.push(this);
  }
  /** Solve the constraint. */
  solve() {
    // Algorithm by Thomas Jakobsen (2001)
    register0.setSubtract(this.p0, this.p1).scale(
    // Approximate the square root function.
    (this.lengthSquared / (register0.dot(register0) + this.lengthSquared) - 0.5) * this.stiffness);
    this.p0.add(register0);
    this.p1.subtract(register0);
  }
}