import type { Pointer } from '../controls/Pointer';
import type { Scene } from './Scene';
import type { Vertex } from './Vertex';
type MetaScene = new (...a: any) => Scene;
/** Enable scene's vertices to be controlled by the pointer. */
export declare function WithPointerControls<T extends MetaScene>(Parent: T, pointer: Pointer, r: number, stiffness?: number): {
    new (...a: any): {
        controlledVertex?: Vertex | null | undefined;
        /** Update the scene. */
        update(): void;
        readonly vertices: Vertex[];
        readonly constraints: import("./Constraint.js").Constraint[];
        readonly bodies: import("./Body.js").Body[];
        height: number;
        width: number;
        iterationCount: number;
    };
} & T;
export {};
