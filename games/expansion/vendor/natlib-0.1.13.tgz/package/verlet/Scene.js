/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Scene class (Verlet integration) */
export class Scene {
  constructor(width, height, iterationCount) {
    this.vertices = [];
    this.constraints = [];
    this.bodies = [];
    this.height = height;
    this.width = width;
    this.iterationCount = iterationCount;
  }
  /** Update the scene. */
  update() {
    // Verlet integration
    this.vertices.forEach(v => v.integrate());
    // Solve constraints
    for (let n = 0; n < this.iterationCount; ++n) {
      this.constraints.forEach(c => c.solve());
    }
  }
}