/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { findCollision } from '../collision/sat.js';
import { register0 } from '../runtime.js';
import { getClosestVertex } from './Body.js';
import { PointerBody } from './objects/PointerBody.js';
/** Enable scene's vertices to be controlled by the pointer. */
export function WithPointerControls(Parent, pointer, r, stiffness = 1) {
  const pb = new PointerBody(r);
  return class PointerScene extends Parent {
    /** Update the scene. */
    update() {
      // Set the controlled vertex.
      if (pointer.held) {
        if (!this.controlledVertex) {
          pb.setPosition(pointer);
          this.bodies.some(b => findCollision(b, pb) && (this.controlledVertex = b.vertices[getClosestVertex(b, pointer)]));
        }
      } else {
        this.controlledVertex = null;
      }
      super.update();
      // Set the controlled vertex position.
      this.controlledVertex?.position.add(register0.setSubtract(pointer, this.controlledVertex.position).scale(stiffness));
    }
  };
}