import { Vec2 } from '../Vec2.js';
import type { Body } from './Body';
/** Vertex class (Verlet integration) */
export declare class Vertex {
    readonly body: Body;
    readonly position: Vec2;
    readonly oldPosition: Vec2;
    readonly interpolated: Vec2;
    gravity: number;
    viscosity: number;
    constructor(body: Body, x: number, y: number, gravity?: number, viscosity?: number);
    /** Verlet integration */
    integrate(): void;
    /** Interpolate the vertex position. */
    interpolate(t: number): void;
}
