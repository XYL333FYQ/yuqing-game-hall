import type { Body } from './Body';
type MetaBody = new (...a: any) => Body;
/** Interpolated paint interface */
export interface IPaint {
    paint(con: CanvasRenderingContext2D, t: number): void;
}
/** Make a body paintable on canvas. Used for debugging. */
export declare function WithPaintMethod<T extends MetaBody>(Parent: T, color?: string, edgeColor?: string): {
    new (...a: any): {
        /** Paint the body. */
        paint(con: CanvasRenderingContext2D, t: number): void;
        readonly scene: import("./Scene").Scene;
        readonly vertices: import("./Vertex").Vertex[];
        readonly constraints: import("./Constraint").Constraint[];
        readonly positions: import("../Vec2").Vec2[];
        readonly edges: import("./Constraint").Constraint[];
        mass: number;
        groundFriction: number;
        readonly center: import("../Vec2").Vec2;
        readonly halfExtents: import("../Vec2").Vec2;
        intervalLeft: number;
        intervalRight: number;
        leftIndex: number;
        rightIndex: number;
        updateBoundingBox(): void;
        projectInterval(direction: Readonly<import("../Vec2").IVec2>): void;
    };
} & T;
export {};
