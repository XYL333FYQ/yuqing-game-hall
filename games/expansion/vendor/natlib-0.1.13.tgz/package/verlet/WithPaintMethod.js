/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Make a body paintable on canvas. Used for debugging. */
export function WithPaintMethod(Parent, color = '#29adff', edgeColor = '#ff004d') {
  return class PaintBody extends Parent {
    /** Paint the body. */
    paint(con, t) {
      this.vertices.forEach(v => v.interpolate(t));
      // Paint constraints that aren't edges
      con.beginPath();
      this.constraints.forEach(c => {
        if (c.edge) return;
        con.moveTo(c.v0.interpolated.x, c.v0.interpolated.y);
        con.lineTo(c.v1.interpolated.x, c.v1.interpolated.y);
      });
      con.strokeStyle = color;
      con.stroke();
      // Paint edges
      con.beginPath();
      this.edges.forEach(c => {
        con.moveTo(c.v0.interpolated.x, c.v0.interpolated.y);
        con.lineTo(c.v1.interpolated.x, c.v1.interpolated.y);
      });
      con.strokeStyle = edgeColor;
      con.stroke();
    }
  };
}