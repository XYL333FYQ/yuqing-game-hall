import { Vec2, type IVec2 } from '../Vec2.js';
import type { Constraint } from './Constraint';
import type { Scene } from './Scene';
import type { Vertex } from './Vertex';
/** Physical body class (Verlet integration) */
export declare class Body {
    readonly scene: Scene;
    readonly vertices: Vertex[];
    readonly constraints: Constraint[];
    /** Positions of vertices */
    readonly positions: Vec2[];
    /** Edges are constraints that define the object's boundary. */
    readonly edges: Constraint[];
    mass: number;
    groundFriction: number;
    readonly center: Vec2;
    readonly halfExtents: Vec2;
    intervalLeft: number;
    intervalRight: number;
    leftIndex: number;
    rightIndex: number;
    constructor(scene: Scene, mass?: number, groundFriction?: number);
    /** Update the bounding box (AABB). */
    updateBoundingBox(): void;
    /** Project the body onto a unit vector. */
    projectInterval(direction: Readonly<IVec2>): void;
}
/** Find a vertex closest to the reference point.
 * Standalone function to enable tree shaking. */
export declare function getClosestVertex({ positions }: Body, point: Readonly<IVec2>): number;
