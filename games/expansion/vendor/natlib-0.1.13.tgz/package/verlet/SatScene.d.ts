import { Scene } from './Scene.js';
/** Scene class using SAT collision detection (Verlet integration) */
export declare class SatScene extends Scene {
    friction: number;
    constructor(width: number, height: number, iterationCount: number, friction?: number);
    /** Update the scene. */
    update(): void;
}
