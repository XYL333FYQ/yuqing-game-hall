import type { Body } from './Body';
import type { Constraint } from './Constraint';
import type { Vertex } from './Vertex';
/** Scene class (Verlet integration) */
export declare class Scene {
    readonly vertices: Vertex[];
    readonly constraints: Constraint[];
    readonly bodies: Body[];
    height: number;
    width: number;
    iterationCount: number;
    constructor(width: number, height: number, iterationCount: number);
    /** Update the scene. */
    update(): void;
}
