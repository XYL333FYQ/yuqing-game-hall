import type { IVec2 } from '../../Vec2';
import { Body } from '../Body.js';
/** Pointer body class for collision detection */
export declare class PointerBody extends Body {
    readonly r: number;
    constructor(r: number);
    /** Project the body onto a unit vector. */
    projectInterval(direction: Readonly<IVec2>): void;
    /** Set the pointer position. */
    setPosition(position: Readonly<IVec2>): void;
}
