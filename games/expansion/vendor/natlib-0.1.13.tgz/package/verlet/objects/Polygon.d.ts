import { Body } from '../Body.js';
import type { Scene } from '../Scene';
/** Convex regular n-gon class (Verlet integration) */
export declare class Polygon extends Body {
    constructor(scene: Scene, N: number, x: number, y: number, r: number, rotate?: number, gravity?: number, viscosity?: number, stiffness?: number, mass?: number, groundFriction?: number);
}
