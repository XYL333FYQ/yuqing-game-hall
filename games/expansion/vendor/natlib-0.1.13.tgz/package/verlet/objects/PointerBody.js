/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { Body } from '../Body.js';
import { Scene } from '../Scene.js';
/** Pointer body class for collision detection */
export class PointerBody extends Body {
  constructor(r) {
    const detached = new Scene(r, r, 0);
    super(detached);
    this.halfExtents.set(this.r = r, r);
  }
  /** Project the body onto a unit vector. */
  projectInterval(direction) {
    const distanceInDirection = this.center.dot(direction);
    this.intervalLeft = distanceInDirection - this.r;
    this.intervalRight = distanceInDirection + this.r;
  }
  /** Set the pointer position. */
  setPosition(position) {
    this.center.copy(position);
  }
}