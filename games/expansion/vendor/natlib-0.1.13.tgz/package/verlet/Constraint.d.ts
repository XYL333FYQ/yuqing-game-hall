import type { ExtendedBool } from '../prelude';
import type { Vec2 } from '../Vec2';
import type { Body } from './Body';
import type { Vertex } from './Vertex';
/** Constraint class (Verlet integration) */
export declare class Constraint {
    readonly body: Body;
    readonly v0: Vertex;
    readonly v1: Vertex;
    /** Position of v0 */
    readonly p0: Vec2;
    /** Position of v1 */
    readonly p1: Vec2;
    lengthSquared: number;
    edge: ExtendedBool;
    stiffness: number;
    constructor(body: Body, v0: Vertex, v1: Vertex, edge: ExtendedBool, stiffness?: number);
    /** Solve the constraint. */
    solve(): void;
}
