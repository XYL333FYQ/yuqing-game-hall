/** Get the PCM data associated with the AudioBuffer. */
export declare function getPCM(buf: AudioBuffer): Float32Array[];
/** Convert MIDI note to frequency. */
export declare function convertMidiToFrequency(n: number): number;
/** Convert frequency to MIDI note. */
export declare function convertFrequencyToMidi(n: number): number;
