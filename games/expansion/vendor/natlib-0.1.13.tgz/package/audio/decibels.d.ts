/** Convert decibels to power ratio. */
export declare function convertDecibelsToPowerRatio(decibels: number): number;
/** Convert decibels to amplitude ratio. */
export declare function convertDecibelsToAmplitudeRatio(decibels: number): number;
/** Convert power ratio to decibels. */
export declare function convertPowerRatioToDecibels(linear: number): number;
/** Convert amplitude ratio to decibels. */
export declare function convertAmplitudeRatioToDecibels(linear: number): number;
/** Fast decibels to power ratio. */
export declare function convertDecibelsToPowerRatioFast(decibels: number): number;
/** Fast decibels to amplitude ratio. */
export declare function convertDecibelsToAmplitudeRatioFast(decibels: number): number;
