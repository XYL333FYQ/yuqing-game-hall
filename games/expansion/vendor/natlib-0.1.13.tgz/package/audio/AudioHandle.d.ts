import { type ExtendedBool } from '../prelude.js';
/** Audio initialization function type */
export type AudioInitializationFunction = (con: AudioContext) => void;
/** Audio handle class */
export declare class AudioHandle {
    con?: AudioContext;
    initialized: ExtendedBool;
    /** Initialize the audio context */
    initialize(ini?: AudioInitializationFunction): Promise<void>;
}
