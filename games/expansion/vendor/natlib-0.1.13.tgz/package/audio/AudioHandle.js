/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Audio handle class */
export class AudioHandle {
  /** Initialize the audio context */
  async initialize(ini) {
    if (this.initialized) return;
    this.con ??= new AudioContext();
    if (this.con.state !== 'running') {
      try {
        await this.con.resume();
      } catch (err) {
        return;
      }
      // Multiple initialize() calls can eventually get here.
      if (this.initialized) return;
    }
    ini?.(this.con); // Can't be async
    this.initialized = 1 /* ShortBool.TRUE */;
  }
}