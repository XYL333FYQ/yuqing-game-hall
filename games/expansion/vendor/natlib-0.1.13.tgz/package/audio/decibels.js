/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

/** Convert decibels to power ratio. */
export function convertDecibelsToPowerRatio(decibels) {
  return 10 ** (decibels / 10);
}
/** Convert decibels to amplitude ratio. */
export function convertDecibelsToAmplitudeRatio(decibels) {
  return 10 ** (decibels / 20);
}
/** Convert power ratio to decibels. */
export function convertPowerRatioToDecibels(linear) {
  return 10 * Math.log10(linear);
}
/** Convert amplitude ratio to decibels. */
export function convertAmplitudeRatioToDecibels(linear) {
  return 20 * Math.log10(linear);
}
/** Fast decibels to power ratio. */
export function convertDecibelsToPowerRatioFast(decibels) {
  return Math.exp(Math.LN10 / 10 * decibels);
}
/** Fast decibels to amplitude ratio. */
export function convertDecibelsToAmplitudeRatioFast(decibels) {
  return Math.exp(Math.LN10 / 20 * decibels);
}