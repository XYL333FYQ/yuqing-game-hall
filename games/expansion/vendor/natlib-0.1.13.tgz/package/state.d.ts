/** Phase and TTL fields */
export interface IState {
    phase: number;
    phaseTtl: number;
    oldTtl: number;
}
/** Map the current phase to the next phase and its TTL.
 * The next phase is stored at index `2 * currentPhase`,
 * and the TTL at index `2 * currentPhase + 1`. */
export type NextPhaseMap = {
    [n: number]: number | undefined;
};
/** Set the current phase and TTL. */
export declare function enterPhase(state: IState, phase: number, ttl?: number): void;
/** Update the current phase and TTL.
 * If the phase has changed, return the previous phase. */
export declare function updatePhase(state: IState, nextPhaseMap: Readonly<NextPhaseMap>): number | undefined;
/** Interpolate the current phase progress. */
export declare function interpolatePhase(state: Readonly<IState>, ttl: number, t: number): number;
