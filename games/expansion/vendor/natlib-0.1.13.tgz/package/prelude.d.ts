export type uint8_t = number;
export type uint16_t = number;
export type uint32_t = number;
export declare const UINT8_MAX = 255;
export declare const UINT16_MAX = 65535;
export declare const UINT32_MAX = 4294967295;
export type PositiveInteger<T extends number> = `${T}` extends '0' | `-${any}` | `${any}.${any}` ? never : T;
export type NonnegativeInteger<T extends number> = `${T}` extends `-${any}` | `${any}.${any}` ? never : T;
export type ExtendedBool = boolean | 0 | 1 | undefined;
export declare const enum ShortBool {
    FALSE = 0,
    TRUE = 1
}
export type MethodsReturningType<T, R> = {
    [K in keyof T]: T[K] extends (...a: any) => R ? K : never;
}[keyof T];
