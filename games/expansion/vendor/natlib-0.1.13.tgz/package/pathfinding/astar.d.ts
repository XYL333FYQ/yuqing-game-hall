import { Vec2 } from '../Vec2.js';
/** 2D location class internal to astar */
declare class Location extends Vec2 {
    readonly x: number;
    readonly y: number;
    readonly key: number;
    priority: number;
    constructor(x: number, y: number);
    /** Manhattan distance on a square grid */
    distanceManhattan(other: Readonly<Location>): number;
}
/** This is a tuple to avoid constructing short-lived `Vec2` objects. */
export type Coordinates = ConstructorParameters<typeof Location>;
/** Return an iterable of adjacent coordinates. */
export type GetAdjacent = (x: number, y: number) => Iterable<Coordinates>;
/** This function is invoked for each step of the path. */
export type WalkFunction = (x: number, y: number) => void;
/** `A*` path finding on a square grid */
export declare function astar(x0: number, y0: number, x1: number, y1: number, getAdjacent: GetAdjacent, walkFunction: WalkFunction): void;
export {};
