/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { PriorityQueue } from '../collections/PriorityQueue.js';
import { Vec2 } from '../Vec2.js';
/** 2D location class internal to astar */
class Location extends Vec2 {
  constructor(x, y) {
    super(x, y);
    this.key = this.y << 16 | this.x;
    this.priority = 0;
  }
  /** Manhattan distance on a square grid */
  distanceManhattan(other) {
    return Math.abs(this.x - other.x) + Math.abs(this.y - other.y);
  }
}
/** `A*` path finding on a square grid */
export function astar(x0, y0, x1, y1, getAdjacent, walkFunction) {
  const start = new Location(x0, y0);
  let end = new Location(x1, y1);
  const frontier = new PriorityQueue((a, b) => a.priority - b.priority,
  // Sort ascending
  [start]);
  const previous = {};
  const score = {
    [start.key]: 0
  };
  while (frontier.length !== 0) {
    const current = frontier.get();
    if (current.key === end.key) break; // Found the path
    for (const coordinates of getAdjacent(current.x, current.y)) {
      const next = new Location(...coordinates);
      const nextScore = score[current.key] + 1;
      if (score[next.key] === undefined || nextScore < score[next.key]) {
        previous[next.key] = current;
        score[next.key] = nextScore;
        next.priority = nextScore + end.distanceManhattan(next);
        frontier.put(next);
      }
    }
  }
  // Walk the path
  while (previous[end.key] !== undefined) {
    walkFunction(end.x, end.y);
    end = previous[end.key];
  }
}