/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { Vec3 } from '../Vec3.js';
/** Hit properties class (Path tracing) */
export class HitProperties {
  constructor() {
    this.origin = new Vec3();
    this.direction = new Vec3();
    this.point = new Vec3();
    this.normal = new Vec3();
  }
}