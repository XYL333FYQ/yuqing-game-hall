/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { uniformSampleHemisphere } from '../../prng/sampling.js';
import { Vec3 } from '../../Vec3.js';
/** Material class (Path tracing) */
export class Material {
  constructor(prng, albedo, emission) {
    this.prng = prng;
    this.albedo = new Vec3();
    this.emission = new Vec3();
    if (albedo) this.albedo.copy(albedo);
    if (emission) this.emission.copy(emission);
  }
  /** Get the ray direction after hitting an object. */
  scatter({
    normal
  }) {
    return uniformSampleHemisphere(this.prng, normal);
  }
}