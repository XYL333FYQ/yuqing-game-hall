import type { IPrng32 } from '../../prng/prng';
import type { IVec3, Vec3 } from '../../Vec3';
import type { HitProperties, IMaterial } from '../pathtracing';
import { Material } from './Material.js';
/** Material subclass featuring specular reflection */
export declare class Metal extends Material implements IMaterial {
    roughness: number;
    constructor(prng: IPrng32, albedo?: Readonly<IVec3>, roughness?: number);
    scatter({ direction, normal }: Pick<HitProperties, 'direction' | 'normal'>): Vec3;
}
