import type { IPrng32 } from '../../prng/prng';
import { Vec3, type IVec3 } from '../../Vec3.js';
import type { HitProperties, IMaterial } from '../pathtracing';
/** Material class (Path tracing) */
export declare class Material implements IMaterial {
    prng: IPrng32;
    albedo: Vec3;
    emission: Vec3;
    constructor(prng: IPrng32, albedo?: Readonly<IVec3>, emission?: Readonly<IVec3>);
    /** Get the ray direction after hitting an object. */
    scatter({ normal }: Pick<HitProperties, 'normal'>): Vec3;
}
