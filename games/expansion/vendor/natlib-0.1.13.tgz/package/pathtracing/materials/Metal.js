/** This file is part of natlib.
 * https://github.com/mvasilkov/natlib
 * @license MIT | Copyright (c) 2022, 2023 Mark Vasilkov
 */
'use strict';

import { register5 } from '../../runtime.js';
import { Material } from './Material.js';
/** Material subclass featuring specular reflection */
export class Metal extends Material {
  constructor(prng, albedo, roughness = 0) {
    super(prng, albedo);
    this.roughness = roughness;
  }
  scatter({
    direction,
    normal
  }) {
    // Specular
    register5.setMultiplyScalar(normal, -2 * direction.dot(normal)).add(direction);
    if (this.roughness > 0) {
      // Diffuse
      return register5.add(super.scatter({
        normal
      }).scale(this.roughness));
    }
    return register5;
  }
}