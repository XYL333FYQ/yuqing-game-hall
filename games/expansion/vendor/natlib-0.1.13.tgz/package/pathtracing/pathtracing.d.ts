import { Vec3 } from '../Vec3.js';
/** Hit properties class (Path tracing) */
export declare class HitProperties {
    readonly origin: Vec3;
    readonly direction: Vec3;
    t: number;
    readonly point: Vec3;
    readonly normal: Vec3;
    constructor();
}
/** Material interface (Path tracing) */
export interface IMaterial {
    scatter(hitProperties: HitProperties): Vec3;
}
/** Interface for path traced objects */
export interface ITraceable {
    intersect(hitProperties: HitProperties): void;
}
