/** 2D vector data structure */
export interface IVec2 {
    x: number;
    y: number;
}
/** 2D vector class */
export declare class Vec2 implements IVec2 {
    x: number;
    y: number;
    constructor(x?: number, y?: number);
    /** Set the components of this vector. */
    set(x: number, y: number): this;
    /** Copy the components of a vector to this vector. */
    copy(other: Readonly<IVec2>): this;
    /** Add a vector to this vector. */
    add(other: Readonly<IVec2>): this;
    /** Subtract a vector from this vector. */
    subtract(other: Readonly<IVec2>): this;
    /** Set this vector to `a` − `b`. */
    setSubtract(a: Readonly<IVec2>, b: Readonly<IVec2>): this;
    /** Set this vector to a perpendicular to the vector `ab`. */
    setPerpendicular(a: Readonly<IVec2>, b: Readonly<IVec2>): this;
    /** Multiply this vector by a scalar. */
    scale(n: number): this;
    /** Set this vector to a scalar multiple of a vector. */
    setMultiplyScalar(other: Readonly<IVec2>, n: number): this;
    /** Get the length of this vector. */
    length(): number;
    /** Convert this vector to a unit vector. */
    normalize(): this;
    /** Get the dot product of two vectors. */
    dot(other: Readonly<IVec2>): number;
    /** Get the squared distance between two vectors. */
    distanceSquared(other: Readonly<IVec2>): number;
}
